package ec.edu.uce.dominio;
import ec.edu.uce.util.ExcepcionMifo;
/**
 * Representa una empresa en el sistema, administrando usuarios, categorías y cursos de educación financiera.
 */
public class Empresa {
    /**
     * Representa una empresa que tiene una lista de usuarios asociados.
     * Relación de asociación (1 a muchos): Esta clase contiene un arreglo de usuarios,
     * indicando que una empresa puede tener múltiples usuarios asociados.
     */
    private Usuario[] usuarios;
    // Cantidad de usuarios registrados
    private int numUsuarios;
    /**
     * Arreglo estático para almacenar categorías.
     * Relación de asociación (1 a muchos): Una empresa puede tener múltiples categorías.
     */
    private static Categoria[] categorias;
    // Cantidad de categorías registradas
    private static int numCategorias;

    // Contador para generar códigos únicos de usuario
    private int usuarioCodigoContador;

    // Contador para generar códigos únicos de categoría
    private int categoriaCodigoContador;

    // Contador para generar códigos únicos de educación financiera
    private int educacionCodigoContador;

    /**
     * Arreglo para almacenar cursos de educación financiera asociados a la empresa.
     *
     * Representa una relación de asociación entre Empresa y EducacionFinanciera,
     * donde una empresa puede estar asociada con múltiples cursos (1 a muchos).
     */
    private EducacionFinanciera[] educacionesFinancieras;
    /**
     * Cantidad de cursos de educación financiera registrados en la empresa.
     */
    private int numEducacionesFinancieras;

    // Constructor por defecto
    public Empresa() {
        this(0, 0, 0);
    }
    /**
     * Constructor con parámetros para inicializar la empresa con tamaños de arreglos dados.
     * Forma parte de la sobrecarga de constructores.
     * @param numUsuarios número inicial para el arreglo de usuarios.
     * @param numCategorias número inicial para el arreglo de categorías.
     * @param numEducacionesFinancieras número inicial para el arreglo de cursos.
     */
    public Empresa(int numUsuarios, int numCategorias, int numEducacionesFinancieras) {
        this.usuarioCodigoContador = 0;
        this.categoriaCodigoContador = 0;
        this.educacionCodigoContador = 0;
        this.educacionesFinancieras = new EducacionFinanciera[10]; // Inicialización en constructor
        this.numEducacionesFinancieras = 0;
        this.usuarios = new Usuario[numUsuarios];
        this.numUsuarios = 0;
        categorias = new Categoria[numCategorias];
        Empresa.numCategorias = 0;
        this.educacionesFinancieras = new EducacionFinanciera[numEducacionesFinancieras];
        this.numEducacionesFinancieras = 0;
    }

    // Genera un nuevo código único de usuario
    public int crearCodigoUsuario() {
        return ++this.usuarioCodigoContador;
    }
    /**
     * Crea un usuario con un código único y lo almacena en la empresa.
     * La empresa crea y almacena usuarios, estableciendo así una relación de asociación.
     * Se utiliza un arreglo Usuario[], lo que implica que puede haber múltiples usuarios dentro de una empresa,
     * reflejando una multiplicidad de 1 a muchos.
     * @param nombre     nombre del usuario a crear
     * @param contrasena contraseña del usuario
     * @param correo     correo electrónico del usuario
     * @return el usuario creado y almacenado
     */
    public String crearUsuarioConCodigo(String nombre, String contrasena, String correo) {
        int codigo = this.crearCodigoUsuario();
        if (this.numUsuarios == this.usuarios.length) {
            Usuario[] aux = new Usuario[this.usuarios.length + 1];
            System.arraycopy(this.usuarios, 0, aux, 0, this.usuarios.length);
            this.usuarios = aux;
        }
        this.usuarios[this.numUsuarios] = new Usuario(nombre, contrasena, correo,0 , codigo);
        this.numUsuarios++;
        return "Código: " + codigo + "\nNombre: " + nombre + "\nContraseña: " + contrasena + "\nCorreo: " + correo;

    }

    // Genera un código único para una categoría
    public double crearCodigoCategoria() {
        return (double)(++this.categoriaCodigoContador);
    }

    // Crea una categoría con un código único
    public String crearCategoriaConCodigo(String nombreCategoria) {
        double codigo = this.crearCodigoCategoria();
        if (numCategorias == categorias.length) {
            Categoria[] aux = new Categoria[categorias.length + 1];
            System.arraycopy(categorias, 0, aux, 0, categorias.length);
            categorias = aux;
        }

        categorias[numCategorias] = new Categoria(nombreCategoria);
        ++numCategorias;
        return "Código: " + codigo + "\nNombre Categoría: " + nombreCategoria;
    }
    /**
     * Agrega una categoría ya creada al arreglo de categorías de la empresa.
     * Esto representa una relación de asociación entre Empresa y Categoria,
     * donde Empresa mantiene referencias a múltiples categorías.
     * @param categoria Categoría que se va a asociar con la empresa.
     */
    public void crearCategoria(Categoria categoria) {
        if (numCategorias == categorias.length) {
            Categoria[] aux = new Categoria[categorias.length + 1];
            System.arraycopy(categorias, 0, aux, 0, categorias.length);
            categorias = aux;
        }
        categorias[numCategorias++] = categoria;
    }
    /**
     * Busca una categoría asociada a la empresa por su nombre.
     * Este método accede a las categorías que la empresa tiene asociadas,
     * lo que reafirma la relación de asociación entre Empresa y Categoria.
     * @param nombre Nombre de la categoría a buscar.
     * @return La categoría asociada con el nombre dado.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si no se encuentra la categoría.
     */
    public Categoria buscarCategoriaPorNombre(String nombre) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        for (int i = 0; i < numCategorias; i++) {
            if (categorias[i] != null && categorias[i].getNombreCategoria().equalsIgnoreCase(nombre)) {
                return categorias[i];
            }
        }
        throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La categoría no existe: " + nombre);
    }

    // Genera un código único para educación financiera
    public double crearCodigoEducacionFinanciera() {
        return (double)(++this.educacionCodigoContador);
    }

    /**
     * Crea un curso de educación financiera y lo asocia con la empresa.
     *
     * Este método refleja la asociación entre Empresa y EducacionFinanciera,
     * agregando un nuevo curso al arreglo interno de la empresa.
     *
     * @param titulo Título del curso.
     * @param descripcion descripción del curso.
     * @return Cadena con los detalles del curso creado.
     */
    public String crearEducacionFinancieraConCodigo(String titulo, String descripcion) {
        double codigo = this.crearCodigoEducacionFinanciera();

        if (this.numEducacionesFinancieras == this.educacionesFinancieras.length) {
            EducacionFinanciera[] aux = new EducacionFinanciera[this.educacionesFinancieras.length + 1];
            System.arraycopy(this.educacionesFinancieras, 0, aux, 0, this.educacionesFinancieras.length);
            this.educacionesFinancieras = aux;
        }
        // Aquí creamos el curso con título y descripción, usando un constructor simplificado
        EducacionFinanciera nuevoCurso = new EducacionFinanciera();
        nuevoCurso.setTitulo(titulo);
        nuevoCurso.setDescripcion(descripcion);
        // Puedes agregar aquí más atributos si quieres, ejemplo: fechaInicio, categoria, etc.

        this.educacionesFinancieras[this.numEducacionesFinancieras] = nuevoCurso;
        this.numEducacionesFinancieras++;

        return "Código: " + codigo + "\nTítulo: " + titulo + "\nDescripción: " + descripcion;
    }

    // Consulta todos los usuarios registrados
    public String consultarUsuario() {
        StringBuilder texto = new StringBuilder();
        for(Usuario usuario : this.usuarios) {
            if (usuario != null) {
                texto.append(usuario).append("\n");
            }
        }
        return texto.toString();
    }

    // Busca un usuario por índice en la lista
    public Usuario buscarUsuario(int indice) throws ExcepcionMifo.UsuarioNoEncontradoExcepcion {
        if (indice >= 0 && indice < this.numUsuarios) {
            return this.usuarios[indice];
        } else {
            throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("Usuario no encontrado con índice: " + indice);
        }
    }
    /**
     * Devuelve una representación en cadena de la empresa,
     * incluyendo la cantidad de usuarios, categorías y cursos de educación financiera registrados.
     * También muestra el detalle básico de cada usuario, categoría y curso.
     *
     * @return Cadena con información de la empresa.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Empresa:\n");
        sb.append("Número de usuarios: ").append(numUsuarios).append("\n");
        sb.append("Usuarios:\n");
        for (int i = 0; i < numUsuarios; i++) {
            sb.append("\t").append(usuarios[i]).append("\n");
        }
        sb.append("Número de categorías: ").append(numCategorias).append("\n");
        sb.append("Categorías:\n");
        for (int i = 0; i < numCategorias; i++) {
            sb.append("\t").append(categorias[i]).append("\n");
        }
        sb.append("Número de cursos de educación financiera: ").append(numEducacionesFinancieras).append("\n");
        sb.append("Cursos:\n");
        for (int i = 0; i < numEducacionesFinancieras; i++) {
            sb.append("\t").append(educacionesFinancieras[i]).append("\n");
        }
        return sb.toString();
    }

}