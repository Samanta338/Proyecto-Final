package ec.edu.uce.dominio;
import ec.edu.uce.util.ExcepcionMifo;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * La clase Gasto hereda de la clase abstracta Movimiento.
 * Esto significa que Gasto es un tipo específico de Movimiento,
 * por eso extiende sus atributos y métodos, y puede añadir sus propios detalles.
 */
public class Gasto extends Movimiento {
    /**
     * Atributo exclusivo de Gasto que representa la categoría del gasto.
     */
    private Categoria categoria;
    /**
     * Constructor por defecto.
     * Inicializa un gasto con categoría "Alimentación" y valores por defecto en los atributos heredados.
     * No recibe parámetros, asigna valores base.
     */
    public Gasto() {
        this.categoria = new Categoria("Alimentación");
    }
    // Sobrecarga de constructores con distintas combinaciones de parámetros

    /**
     * Constructor principal.
     * Inicializa un gasto con todos sus atributos: descripción, monto, fecha y categoría.
     * Se usa cuando se quiere especificar toda la información del gasto.
     *
     * @param descripcion Descripción del gasto.
     * @param monto Monto del gasto.
     * @param fecha Fecha del gasto.
     * @param categoria Categoría del gasto.
     */
    public Gasto(String descripcion, double monto, Date fecha, Categoria categoria) {
        super(descripcion, monto, fecha,categoria);
        this.categoria = categoria;
    }
    /**
     * Constructor que inicializa un gasto con descripción, monto y categoría.
     * La fecha se establece con valor predeterminado en la clase base.
     * Útil cuando la fecha no es relevante o se toma la fecha actual por defecto.
     *
     * @param descripcion Descripción del gasto.
     * @param monto Monto del gasto.
     * @param categoria Categoría del gasto.
     */
    public Gasto(String descripcion, double monto, Categoria categoria) {
        super(descripcion, monto,categoria);
        this.categoria = categoria;
    }
    /**
     * Constructor que inicializa un gasto con solo descripción y categoría.
     * El monto y la fecha se asignan con valores por defecto (0.0 y fecha actual).
     * Útil para registrar un gasto inicial o sin monto definido aún.
     *
     * @param descripcion Descripción del gasto.
     * @param categoria Categoría del gasto.
     */
    public Gasto(String descripcion, Categoria categoria) {
        super(descripcion,categoria);
        this.categoria = categoria;
    }
    /**
     * Constructor que inicializa un gasto con descripción, monto y fecha.
     * La categoría se asigna por defecto a "Alimentación".
     * Útil cuando no se especifica categoría pero sí fecha.
     *
     * @param descripcion Descripción del gasto.
     * @param monto Monto del gasto.
     * @param fecha Fecha del gasto.
     */
    public Gasto(String descripcion, double monto, Date fecha) {
        this(descripcion, monto, fecha, new Categoria("Alimentación"));
    }
    /**
     * Constructor que inicializa un gasto con descripción y monto.
     * La fecha se asigna con la fecha actual y la categoría por defecto a "Alimentación".
     * Útil para gastos simples donde solo se conoce descripción y monto.
     *
     * @param descripcion Descripción del gasto.
     * @param monto Monto del gasto.
     */
    public Gasto(String descripcion, double monto) {
        this(descripcion, monto, new Date(), new Categoria("Alimentación"));
    }
    /**
     * Constructor que inicializa un gasto solo con la descripción.
     * El monto se asigna a 0.0, la fecha a la actual y la categoría a "Alimentación".
     * Útil para crear un gasto con información mínima inicial.
     *
     * @param descripcion Descripción del gasto.
     */
    public Gasto(String descripcion) {
        this(descripcion, 0.0, new Date(), new Categoria("Alimentación"));
    }

    public Categoria getCategoria() {
        return this.categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public boolean validarDuplicado(Movimiento otroMovimiento) {
        return otroMovimiento instanceof Gasto && this.equals(otroMovimiento);
    }

    public boolean registrar() {
        if (this.getMonto() <= 0.0) {
            try {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El monto del gasto debe ser mayor que cero.");
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion ex) {
                Logger.getLogger(Gasto.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }
        } else {
            System.out.println("Gasto registrado: \nDescripción: " + this.getDescripcion()
                    + "\nMonto: " + this.getMonto()
                    + "\nFecha: " + this.getFecha()
                    + "\nCategoría: " + this.categoria.getNombreCategoria());
            return true;
        }
    }
    /**
     * Devuelve una representación en cadena del gasto,
     * incluyendo la información heredada de Movimiento y la categoría específica.
     *
     * @return Cadena con la descripción del gasto y su categoría.
     */
    public String toString() {
        return "Gasto:\n" + super.toString() + "\nCategoría: " + this.categoria.getNombreCategoria();
    }
    /**
     * Realiza el gasto validando el monto.
     * Lanza excepciones si el monto es inválido o si hay saldo insuficiente.
     *
     * @throws ExcepcionMifo.SaldoInsuficienteExcepcion si el saldo es insuficiente.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el monto es menor o igual a cero.
     */

    public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (this.getMonto() <= 0.0) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El monto del gasto debe ser mayor que cero.");
        } else {
            System.out.println("Realizando gasto: \nDescripción: " + this.getDescripcion()
                    + "\nMonto: " + this.getMonto()
                    + "\nFecha: " + this.getFecha()
                    + "\nCategoría: " + this.categoria.getNombreCategoria());
        }
    }
}
