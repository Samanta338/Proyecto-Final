package ec.edu.uce.dominio;
import ec.edu.uce.util.ExcepcionMifo;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * Clase Ingreso que hereda de Movimiento.
 *
 * Herencia:
 * - La clase Ingreso extiende (extends) la clase abstracta Movimiento,
 *   por lo tanto hereda sus atributos y métodos.
 * - Ingreso añade un atributo específico "categoria" que no existe en Movimiento.
 * - Implementa los métodos abstractos definidos en Movimiento: registrar(), validarDuplicado(), realizar().
 */
public class Ingreso extends Movimiento {
    // Atributo propio de Ingreso, no está en Movimiento
    private Categoria categoria;
    /**
     * Constructor por defecto.
     * Inicializa un ingreso con categoría "Otro" y valores por defecto en los atributos heredados.
     * No recibe parámetros, asigna valores base.
     */
    public Ingreso() {
        this.categoria = new Categoria("Otro");
    }

    /**
     * Constructor principal.
     * Inicializa un ingreso con todos sus atributos: descripción, monto, fecha y categoría.
     * Se usa cuando se quiere especificar toda la información del ingreso.
     *
     * @param descripcion Descripción del ingreso.
     * @param monto Monto del ingreso.
     * @param fecha Fecha del ingreso.
     * @param categoria Categoría del ingreso.
     */
    public Ingreso(String descripcion, double monto, Date fecha, Categoria categoria) {
        super(descripcion, monto, fecha, categoria); // invoca al constructor de la clase base para inicializar los atributos heredados. e implementa registrar(), validarDuplicado(), y realizar(), que estaban definidos como abstractos en Movimiento.
        this.categoria = categoria;
    }

    /**
     * Constructor que inicializa un ingreso con descripción, monto y categoría.
     * La fecha se establece con valor predeterminado en la clase base.
     * Útil cuando la fecha no es relevante o se toma la fecha actual por defecto.
     *
     * @param descripcion Descripción del ingreso.
     * @param monto Monto del ingreso.
     * @param categoria Categoría del ingreso.
     */
    public Ingreso(String descripcion, double monto, Categoria categoria) {
        super(descripcion, monto, categoria);
        this.categoria = categoria;
    }

    /**
     * Constructor que inicializa un ingreso con solo descripción y categoría.
     * El monto y la fecha se asignan con valores por defecto (0.0 y fecha actual).
     * Útil para registrar un ingreso inicial o sin monto definido aún.
     *
     * @param descripcion Descripción del ingreso.
     * @param categoria Categoría del ingreso.
     */
    public Ingreso(String descripcion, Categoria categoria) {
        super(descripcion,categoria);
        this.categoria = categoria;
    }
    /**
     * Constructor que inicializa un ingreso con descripción, monto y fecha.
     * La categoría se asigna por defecto a "Otro".
     * Útil cuando no se especifica categoría pero sí fecha.
     *
     * @param descripcion Descripción del ingreso.
     * @param monto Monto del ingreso.
     * @param fecha Fecha del ingreso.
     */

    public Ingreso(String descripcion, double monto, Date fecha) {
        this(descripcion, monto, fecha, new Categoria("Otro"));
    }
    /**
     * Constructor que inicializa un ingreso con descripción y monto.
     * La fecha se asigna con la fecha actual y la categoría por defecto a "Otro".
     * Útil para ingresos simples donde solo se conoce descripción y monto.
     *
     * @param descripcion Descripción del ingreso.
     * @param monto Monto del ingreso.
     */
    public Ingreso(String descripcion, double monto) {
        this(descripcion, monto, new Date(), new Categoria("Otro"));
    }

    /**
     * Constructor que inicializa un ingreso solo con la descripción.
     * El monto se asigna a 0.0, la fecha a la actual y la categoría a "Otro".
     * Útil para crear un ingreso con información mínima inicial.
     *
     * @param descripcion Descripción del ingreso.
     */
    public Ingreso(String descripcion) {
        this(descripcion, 0.0, new Date(), new Categoria("Otro"));
    }

    public Categoria getCategoria() {
        return this.categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
    /**
     * Valida si el otro movimiento es un ingreso duplicado.
     * @param otroMovimiento Movimiento a comparar.
     * @return true si el otro movimiento es instancia de Ingreso y es igual a este.
     */
    public boolean validarDuplicado(Movimiento otroMovimiento) {
        return otroMovimiento instanceof Ingreso && this.equals(otroMovimiento);
    }
    /**
     * Registra el ingreso validando que el monto sea mayor que cero.
     * En caso contrario, lanza y captura una excepción específica.
     * @return true si el ingreso se registra correctamente, false si hay error.
     */
    public boolean registrar() {
        if (this.getMonto() <= 0.0) {
            try {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El monto del ingreso debe ser mayor que cero.");
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion ex) {
                Logger.getLogger(Ingreso.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }
        } else {
            System.out.println("Ingreso registrado: \nDescripción: " + this.getDescripcion()
                    + "\nMonto: " + this.getMonto()
                    + "\nFecha: " + this.getFecha()
                    + "\nCategoría: " + this.categoria.getNombreCategoria());
            return true;
        }
    }

    /**
     * Representa el ingreso en formato String, incluyendo categoría.
     * @return Cadena con la información del ingreso.
     */
    public String toString() {
        return "Ingreso:\n" + super.toString() + "\nCategoría: " + this.categoria.getNombreCategoria();
    }
    /**
     * Realiza el ingreso validando que el monto sea mayor que cero.
     * @throws ExcepcionMifo.SaldoInsuficienteExcepcion si no hay saldo suficiente.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el monto es inválido.
     */
    public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (this.getMonto() <= 0.0) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El monto del ingreso debe ser mayor que cero.");
        } else {
            System.out.println("Realizando ingreso: \nDescripción: " + this.getDescripcion()
                    + "\nMonto: " + this.getMonto()
                    + "\nFecha: " + this.getFecha()
                    + "\nCategoría: " + this.categoria.getNombreCategoria());
        }
    }
}
