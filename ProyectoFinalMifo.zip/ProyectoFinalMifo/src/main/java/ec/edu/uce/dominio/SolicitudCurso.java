package ec.edu.uce.dominio;

import java.util.Date;

/**
 * Clase que representa una solicitud de curso de educación financiera.
 * Cada solicitud está asociada a un usuario.
 */
public class SolicitudCurso {
    private EducacionFinanciera educacionFinanciera;
    private String nombreCurso;
    private String categoria;
    private String descripcion;
    private int duracionSemanas;
    private String nivel;
    private String modalidad;
    private Date fechaSolicitud;

    /**
     * Asociación con Usuario.
     * Relación: Muchas solicitudes pueden pertenecer a un solo Usuario.
     */
    private Usuario usuario;

    public SolicitudCurso() {
    }

    /**
     * Constructor completo para crear un curso.
     */
    public SolicitudCurso(String nombreCurso, String categoria, String descripcion, int duracionSemanas, String nivel, String modalidad) {
        this.nombreCurso = nombreCurso;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.duracionSemanas = duracionSemanas;
        this.nivel = nivel;
        this.modalidad = modalidad;
        this.fechaSolicitud = new Date(); // Fecha actual por defecto
    }
    /**
     * Sobrecarga del constructor que solo recibe nombre y categoría.
     */
    public SolicitudCurso(String nombreCurso, String categoria) {
        this.nombreCurso = nombreCurso;
        this.categoria = categoria;
        this.fechaSolicitud = new Date();
    }
    // Getters y setters
    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getDuracionSemanas() {
        return duracionSemanas;
    }

    public void setDuracionSemanas(int duracionSemanas) {
        this.duracionSemanas = duracionSemanas;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    public Date getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Date fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setEducacionFinanciera(EducacionFinanciera educacionFinanciera) {
        this.educacionFinanciera = educacionFinanciera;
    }

    public EducacionFinanciera getEducacionFinanciera() {
        return educacionFinanciera;
    }
    /**
     * Representación en cadena del objeto SolicitudCurso.
     * Método sobrescrito {@code toString()} para mostrar información legible
     * del curso solicitado.
     *
     * @return Cadena con detalles del curso.
     */
    @Override
    public String toString() {
        return "Curso: " + nombreCurso +
                "\nCategoría: " + categoria +
                "\nDescripción: " + descripcion +
                "\nDuración: " + duracionSemanas + " semanas" +
                "\nNivel: " + nivel +
                "\nModalidad: " + modalidad +
                "\nFecha de Solicitud: " + (fechaSolicitud != null ? fechaSolicitud.toString() : "No registrada");
    }
}
