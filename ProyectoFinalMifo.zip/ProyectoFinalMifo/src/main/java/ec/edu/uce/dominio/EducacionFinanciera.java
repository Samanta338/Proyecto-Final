package ec.edu.uce.dominio;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 * Representa un curso de educación financiera.
 * Contiene información sobre el título, descripción, duración,
 * nivel de dificultad, modalidad, categoría y fecha de inicio.
 * Esta clase mantiene una relación de asociación con SolicitudCurso:
 * 1 EducacionFinanciera puede tener 0 o más SolicitudCurso (1 a 0..n).
 */
public class EducacionFinanciera implements Serializable {
    private static final long serialVersionUID = 1L;
    private String titulo;
    private String descripcion;
    private int duracionSemanas;
    private String nivel;
    private String modalidad;
    private Categoria categoria;
    private Date fechaInicio;
    // Relación 1 a 0..n: una educación financiera puede tener muchas solicitudes.
    private List<SolicitudCurso> solicitudes;
    /**
     * Constructor por defecto con valores predeterminados.
     * Forma parte de la sobrecarga de constructores en esta clase.
     */
    public EducacionFinanciera() {
        this("Sin título", "Sin descripción", 0, "Desconocido", "Desconocido", new Categoria(), new Date());
    }
    /**
     * Constructor con parámetros para inicializar el curso.
     * Forma parte de la sobrecarga de constructores en esta clase.
     * @param titulo Título del curso.
     * @param descripcion Descripción del curso.
     * @param duracionSemanas Duración en semanas.
     * @param nivel Nivel de dificultad.
     * @param modalidad Modalidad del curso.
     * @param categoria Categoría asociada.
     * @param fechaInicio Fecha de inicio.
     */
    public EducacionFinanciera(String titulo, String descripcion, int duracionSemanas, String nivel,
                               String modalidad, Categoria categoria, Date fechaInicio) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.duracionSemanas = duracionSemanas;
        this.nivel = nivel;
        this.modalidad = modalidad;
        this.categoria = categoria;
        this.fechaInicio = fechaInicio;
        this.solicitudes = new ArrayList<>();
    }

    // Getters y setters para los atributos

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public int getDuracionSemanas() { return duracionSemanas; }
    public void setDuracionSemanas(int duracionSemanas) { this.duracionSemanas = duracionSemanas; }

    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }

    public String getModalidad() { return modalidad; }
    public void setModalidad(String modalidad) { this.modalidad = modalidad; }

    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }

    public Date getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(Date fechaInicio) { this.fechaInicio = fechaInicio; }

    /**
     * Obtiene la lista de solicitudes asociadas a este curso.
     * @return Lista de solicitudes.
     */
    public List<SolicitudCurso> getSolicitudes() {
        return solicitudes;
    }

    /**
     * Agrega una solicitud al curso.
     * Establece la referencia bidireccional (opcional).
     * @param solicitud Solicitud a agregar.
     */
    public void agregarSolicitud(SolicitudCurso solicitud) {
        if (solicitud != null) {
            solicitudes.add(solicitud);
            solicitud.setEducacionFinanciera(this);  // Asocia la solicitud a este curso
        }
    }

    /**
     * Elimina una solicitud del curso.
     * @param solicitud Solicitud a eliminar.
     */
    public void eliminarSolicitud(SolicitudCurso solicitud) {
        if (solicitud != null && solicitudes.contains(solicitud)) {
            solicitudes.remove(solicitud);
            solicitud.setEducacionFinanciera(null);
        }
    }

    /**
     * Sobrescribe el método equals() de Object para comparar dos cursos.
     * Dos cursos se consideran iguales si todos sus atributos son iguales.
     * @param o Objeto a comparar.
     * @return true si son iguales, false en caso contrario.
     */

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EducacionFinanciera)) return false;

        EducacionFinanciera that = (EducacionFinanciera) o;
        return duracionSemanas == that.duracionSemanas &&
                titulo.equals(that.titulo) &&
                descripcion.equals(that.descripcion) &&
                nivel.equals(that.nivel) &&
                modalidad.equals(that.modalidad) &&
                categoria.equals(that.categoria) &&
                fechaInicio.equals(that.fechaInicio);
    }
    /**
     * Sobrescribe el método toString() de Object para dar una representación en texto del curso.
     * @return Cadena con los detalles del curso.
     */
    @Override
    public String toString() {
        return "Curso de Educación Financiera:\n" +
                "Título: " + titulo + "\n" +
                "Descripción: " + descripcion + "\n" +
                "Duración (semanas): " + duracionSemanas + "\n" +
                "Nivel: " + nivel + "\n" +
                "Modalidad: " + modalidad + "\n" +
                "Categoría: " + categoria + "\n" +
                "Fecha de inicio: " + fechaInicio + "\n" +
                "Solicitudes asociadas: " + solicitudes.size();
    }
}
