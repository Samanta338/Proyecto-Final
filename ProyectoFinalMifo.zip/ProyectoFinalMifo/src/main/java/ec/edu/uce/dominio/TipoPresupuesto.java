package ec.edu.uce.dominio;
public enum TipoPresupuesto {
        ANUAL,
        SEMANAL,
        MENSUAL;
}

