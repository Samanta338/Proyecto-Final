package ec.edu.uce;
import ec.edu.uce.dominio.SolicitudCurso;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class SubMenuGestionarEducacionFinanciera {
    private List<SolicitudCurso> cursos = new ArrayList<>();
    private Scanner entrada = new Scanner(System.in);

    public void menuGestionarEducacionFinanciera() {
        boolean continuar = true;
        while (continuar) {
            System.out.println();
            System.out.println("  ----------------------------------------------  ");
            System.out.println(" |       Gestionar Educación Financiera          |");
            System.out.println("  ----------------------------------------------  ");
            System.out.println(" |  1. Crear Educación Financiera                |");
            System.out.println(" |  2. Editar Educación Financiera               |");
            System.out.println(" |  3. Eliminar Educación Financiera             |");
            System.out.println(" |  4. Consultar Educación Financiera            |");
            System.out.println(" |  5. Salir del sistema                         |");
            System.out.println("  ----------------------------------------------  ");
            System.out.println();
            System.out.print("Por favor, selecciona una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                    crearCurso();
                    break;
                case "2":
                    editarCurso();
                    break;
                case "3":
                    eliminarCurso();
                    break;
                case "4":
                    menuConsultaCursos();
                    break;
                case "5":
                    continuar = false;
                    System.out.println("\nSaliendo del sistema. ¡Gracias por usar la plataforma MIFO!");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
            System.out.println();
        }
    }

    private void crearCurso() {
        System.out.println("\n----- Crear Curso -----");

        String nombre = solicitarCadenaNoVacia("Nombre del curso: ");
        String categoria = solicitarCadenaNoVacia("Categoría: ");
        String descripcion = solicitarCadenaNoVacia("Descripción: ");
        int duracion = solicitarEnteroPositivo("Duración en semanas: ");
        String nivel = solicitarCadenaNoVacia("Nivel: ");
        String modalidad = solicitarCadenaNoVacia("Modalidad: ");

        SolicitudCurso curso = new SolicitudCurso(nombre, categoria, descripcion, duracion, nivel, modalidad);
        cursos.add(curso);

        System.out.println("Curso creado exitosamente.");
    }

    private void editarCurso() {
        System.out.println("\n----- Editar Curso -----");
        String nombre = solicitarCadenaNoVacia("Ingrese el nombre del curso a editar: ");

        SolicitudCurso cursoEditar = null;
        for (SolicitudCurso curso : cursos) {
            if (curso.getNombreCurso().equalsIgnoreCase(nombre)) {
                cursoEditar = curso;
                break;
            }
        }

        if (cursoEditar == null) {
            System.out.println("Curso no encontrado.");
            return;
        }

        String nuevoNombre = solicitarCadenaOpcional("Nuevo nombre (enter para dejar igual): ");
        if (!nuevoNombre.isEmpty()) cursoEditar.setNombreCurso(nuevoNombre);

        String nuevaCategoria = solicitarCadenaOpcional("Nueva categoría (enter para dejar igual): ");
        if (!nuevaCategoria.isEmpty()) cursoEditar.setCategoria(nuevaCategoria);

        String nuevaDescripcion = solicitarCadenaOpcional("Nueva descripción (enter para dejar igual): ");
        if (!nuevaDescripcion.isEmpty()) cursoEditar.setDescripcion(nuevaDescripcion);

        String duracionStr = solicitarCadenaOpcional("Nueva duración en semanas (enter para dejar igual): ");
        if (!duracionStr.isEmpty()) {
            try {
                int duracion = Integer.parseInt(duracionStr);
                if (duracion > 0) {
                    cursoEditar.setDuracionSemanas(duracion);
                } else {
                    System.out.println("Duración inválida, no se actualizó.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Formato inválido, no se actualizó duración.");
            }
        }

        String nuevoNivel = solicitarCadenaOpcional("Nuevo nivel (enter para dejar igual): ");
        if (!nuevoNivel.isEmpty()) cursoEditar.setNivel(nuevoNivel);

        String nuevaModalidad = solicitarCadenaOpcional("Nueva modalidad (enter para dejar igual): ");
        if (!nuevaModalidad.isEmpty()) cursoEditar.setModalidad(nuevaModalidad);

        System.out.println("Curso actualizado correctamente.");
    }

    private void eliminarCurso() {
        System.out.println("\n----- Eliminar Curso -----");
        String nombre = solicitarCadenaNoVacia("Ingrese el nombre del curso a eliminar: ");

        SolicitudCurso cursoEliminar = null;
        for (SolicitudCurso curso : cursos) {
            if (curso.getNombreCurso().equalsIgnoreCase(nombre)) {
                cursoEliminar = curso;
                break;
            }
        }

        if (cursoEliminar != null) {
            cursos.remove(cursoEliminar);
            System.out.println("Curso eliminado correctamente.");
        } else {
            System.out.println("Curso no encontrado.");
        }
    }

    private void menuConsultaCursos() {
        boolean regresar = false;
        while (!regresar) {
            System.out.println();
            System.out.println("  -----------------------------------------------  ");
            System.out.println(" |        Consultar Educación Financiera          |");
            System.out.println("  -----------------------------------------------  ");
            System.out.println(" |  1. Ver cursos disponibles                     |");
            System.out.println(" |  2. Buscar cursos por categoría                |");
            System.out.println(" |  3. Ver detalle de un curso                    |");
            System.out.println(" |  4. Inscribirse a un curso                     |");
            System.out.println(" |  5. Volver al menú anterior                    |");
            System.out.println("  -----------------------------------------------  ");
            System.out.println();
            System.out.print("Seleccione una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                    verCursosDisponibles();
                    break;
                case "2":
                    buscarCursosPorCategoria();
                    break;
                case "3":
                    verDetalleCurso();
                    break;
                case "4":
                    inscribirseCurso();
                    break;
                case "5":
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
            System.out.println();
        }
    }

    private void verCursosDisponibles() {
        System.out.println("\n----- Cursos Disponibles -----");
        if (cursos.isEmpty()) {
            System.out.println("No hay cursos registrados.");
        } else {
            for (SolicitudCurso curso : cursos) {
                System.out.println("- " + curso.getNombreCurso());
            }
        }
    }

    private void buscarCursosPorCategoria() {
        String categoria = solicitarCadenaNoVacia("Ingrese la categoría a buscar: ");
        boolean encontrado = false;
        for (SolicitudCurso curso : cursos) {
            if (curso.getCategoria().equalsIgnoreCase(categoria)) {
                System.out.println(curso);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron cursos en esa categoría.");
        }
    }

    private void verDetalleCurso() {
        String nombre = solicitarCadenaNoVacia("Ingrese el nombre del curso para ver el detalle: ");
        for (SolicitudCurso curso : cursos) {
            if (curso.getNombreCurso().equalsIgnoreCase(nombre)) {
                System.out.println("\n----- Detalle del Curso -----");
                System.out.println(curso);
                return;
            }
        }
        System.out.println("Curso no encontrado.");
    }

    private void inscribirseCurso() {
        String nombre = solicitarCadenaNoVacia("Ingrese el nombre del curso al que desea inscribirse: ");
        for (SolicitudCurso curso : cursos) {
            if (curso.getNombreCurso().equalsIgnoreCase(nombre)) {
                System.out.println("¡Inscripción exitosa al curso: " + curso.getNombreCurso() + "!");
                return;
            }
        }
        System.out.println("Curso no encontrado.");
    }

    // Métodos auxiliares para validaciones y entradas

    private String solicitarCadenaNoVacia(String mensaje) {
        String input;
        do {
            System.out.print(mensaje);
            input = entrada.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("Entrada no puede estar vacía. Intente de nuevo.");
            }
        } while (input.isEmpty());
        return input;
    }

    private String solicitarCadenaOpcional(String mensaje) {
        System.out.print(mensaje);
        return entrada.nextLine().trim();
    }

    private int solicitarEnteroPositivo(String mensaje) {
        int valor = -1;
        do {
            System.out.print(mensaje);
            String input = entrada.nextLine().trim();
            try {
                valor = Integer.parseInt(input);
                if (valor <= 0) {
                    System.out.println("Por favor ingrese un número entero positivo.");
                    valor = -1;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }
        } while (valor <= 0);
        return valor;
    }

    public static void main(String[] args) {
        SubMenuGestionarEducacionFinanciera menu = new SubMenuGestionarEducacionFinanciera();
        menu.menuGestionarEducacionFinanciera();
    }
}
