//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package ec.edu.uce.dominio;

import ec.edu.uce.util.ExcepcionMifo;
import java.util.Date;

public abstract class Movimiento {
    protected String descripcion;
    protected double monto;
    protected Date fecha;
    // Cada objeto Movimiento tiene una referencia a un objeto Categoria.
    protected Categoria categoria;
    /**
     * Constructor por defecto.
     * Inicializa un Movimiento con:
     * - descripción: "Sin descripcion"
     * - monto: 0.0
     * - fecha: fecha actual
     * - categoría: "Otro" (por defecto)
     */
    public Movimiento() {

        this("Sin descripcion", (double)0.0F, new Date(), new Categoria("Otro"));
    }
    // Constructor donde asignamos todos los datos, incluida la categoría

    /**
     * Constructor principal que inicializa todos los atributos.
     * Se usa para crear un Movimiento con todos los datos completos.
     *
     * @param descripcion Descripción del movimiento.
     * @param monto Monto del movimiento.
     * @param fecha Fecha del movimiento.
     * @param categoria Categoría asociada al movimiento.
     */
    public Movimiento(String descripcion, double monto, Date fecha,  Categoria categoria) {
        this.descripcion = descripcion;
        this.monto = monto;
        this.fecha = fecha;
        this.categoria = categoria;
    }
    /**
     * Constructor que recibe descripción, monto y categoría.
     * La fecha se asigna con la fecha actual por defecto.
     *
     * @param descripcion Descripción del movimiento.
     * @param monto Monto del movimiento.
     * @param categoria Categoría asociada al movimiento.
     */
    public Movimiento(String descripcion, double monto, Categoria categoria) {
        this(descripcion, monto, new Date(), categoria);
    }

    /**
     * Constructor que recibe descripción y categoría.
     * El monto se inicializa en 0.0 y la fecha en la actual.
     *
     * @param descripcion Descripción del movimiento.
     * @param categoria Categoría asociada al movimiento.
     */
    public Movimiento(String descripcion, Categoria categoria) {
        this(descripcion, (double)0.0F, new Date(),  categoria);
    }

    public String getDescripcion() {
        return this.descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getMonto() {
        return this.monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Date getFecha() {
        return this.fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }


    @Override
    public boolean equals(Object object) {
        boolean resp = false;
        if (object != null && object instanceof Movimiento otroMovimiento) {
            if (Double.compare(this.monto, otroMovimiento.monto) == 0
                    && this.fecha.equals(otroMovimiento.fecha)
                    && ((this.categoria == null && otroMovimiento.categoria == null) ||
                    (this.categoria != null && this.categoria.equals(otroMovimiento.categoria)))) {
                resp = true;
            }
        }
        return resp;
    }
    /**
     * Devuelve una representación en cadena de texto del objeto Movimiento.
     *
     * Este método sobrescribe  el método toString()} de la clase
     * para proporcionar una descripción legible de los atributos del movimiento,
     * incluyendo la descripción, monto, fecha y categoría asociada.
     *
     * @return una cadena con los detalles del movimiento formateados.
     */
    @Override
    public String toString() {
        return "\nDescripcion= " + descripcion
                + "\nMonto= " + monto
                + "\nFecha= " + fecha
                + "\nCategoria= " + (categoria != null ? categoria.getNombreCategoria() : "Sin categoria");
    }
    public abstract boolean registrar();

    public abstract boolean validarDuplicado(Movimiento var1);

    public abstract void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion;
}
