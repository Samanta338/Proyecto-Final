package ec.edu.uce.dominio;
public enum TipoMovimiento {
    INGRESO,
    GASTO
}