package ec.edu.uce.dominio;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;
class EducacionFinancieraTest {

    /**
     * Prueba el constructor por defecto de la clase EducacionFinanciera.
     * Se espera que se inicialice con valores predeterminados.
     */
    @Test
    void testConstructorPorDefecto() {
        EducacionFinanciera curso = new EducacionFinanciera();

        System.out.println("Probando constructor por defecto...");
        System.out.println("Título esperado: Sin título | Actual: " + curso.getTitulo());
        System.out.println("Descripción esperada: Sin descripción | Actual: " + curso.getDescripcion());
        System.out.println("Duración esperada: 0 semanas | Actual: " + curso.getDuracionSemanas());

        assertNotNull(curso);
        assertEquals("Sin título", curso.getTitulo());
        assertEquals("Sin descripción", curso.getDescripcion());
        assertEquals(0, curso.getDuracionSemanas());
    }

    /**
     * Prueba el constructor con parámetros de la clase {@link EducacionFinanciera}.
     * Se verifica que los atributos sean correctamente asignados.
     */
    @Test
    void testConstructorCompleto() {
        Categoria categoria = new Categoria("Finanzas Personales");
        Date fechaInicio = new Date();
        EducacionFinanciera curso = new EducacionFinanciera("Ahorro Inteligente", "Curso sobre ahorro",
                6, "Intermedio", "Virtual", categoria, fechaInicio);

        System.out.println("Probando constructor completo...");
        System.out.println("Título esperado: Ahorro Inteligente | Actual: " + curso.getTitulo());
        System.out.println("Descripción esperada: Curso sobre ahorro | Actual: " + curso.getDescripcion());
        System.out.println("Duración esperada: 6 semanas | Actual: " + curso.getDuracionSemanas());
        System.out.println("Nivel esperado: Intermedio | Actual: " + curso.getNivel());
        System.out.println("Modalidad esperada: Virtual | Actual: " + curso.getModalidad());

        assertEquals("Ahorro Inteligente", curso.getTitulo());
        assertEquals("Curso sobre ahorro", curso.getDescripcion());
        assertEquals(6, curso.getDuracionSemanas());
        assertEquals("Intermedio", curso.getNivel());
        assertEquals("Virtual", curso.getModalidad());
        assertEquals(categoria, curso.getCategoria());
        assertEquals(fechaInicio, curso.getFechaInicio());
    }

    /**
     * Prueba los métodos setters de la clase {@link EducacionFinanciera}.
     * Se verifica que los valores puedan ser modificados correctamente.
     */
    @Test
    void testSetters() {
        EducacionFinanciera curso = new EducacionFinanciera();
        curso.setTitulo("Gestión Financiera");
        curso.setDescripcion("Curso avanzado de finanzas");
        curso.setDuracionSemanas(8);
        curso.setNivel("Avanzado");
        curso.setModalidad("Presencial");

        System.out.println("Probando setters...");
        System.out.println("Nuevo título: " + curso.getTitulo());
        System.out.println("Nueva descripción: " + curso.getDescripcion());
        System.out.println("Nueva duración: " + curso.getDuracionSemanas() + " semanas");
        System.out.println("Nuevo nivel: " + curso.getNivel());
        System.out.println("Nueva modalidad: " + curso.getModalidad());

        assertEquals("Gestión Financiera", curso.getTitulo());
        assertEquals("Curso avanzado de finanzas", curso.getDescripcion());
        assertEquals(8, curso.getDuracionSemanas());
        assertEquals("Avanzado", curso.getNivel());
        assertEquals("Presencial", curso.getModalidad());
    }

    /**
     * Prueba el método {@link EducacionFinanciera#agregarSolicitud(SolicitudCurso)}.
     * Se verifica que las solicitudes sean correctamente asociadas al curso.
     */
    @Test
    void testAgregarSolicitud() {
        EducacionFinanciera curso = new EducacionFinanciera();
        SolicitudCurso solicitud = new SolicitudCurso();
        curso.agregarSolicitud(solicitud);

        System.out.println("Probando agregarSolicitud...");
        System.out.println("Tamaño esperado de la lista de solicitudes: 1 | Actual: " + curso.getSolicitudes().size());

        assertEquals(1, curso.getSolicitudes().size());
        assertEquals(curso, solicitud.getEducacionFinanciera());
    }

    /**
     * Prueba el método {@link EducacionFinanciera#eliminarSolicitud(SolicitudCurso)}.
     * Se verifica que las solicitudes puedan ser eliminadas correctamente.
     */
    @Test
    void testEliminarSolicitud() {
        EducacionFinanciera curso = new EducacionFinanciera();
        SolicitudCurso solicitud = new SolicitudCurso();
        curso.agregarSolicitud(solicitud);
        curso.eliminarSolicitud(solicitud);

        System.out.println("Probando eliminarSolicitud...");
        System.out.println("Tamaño esperado de la lista de solicitudes después de eliminar: 0 | Actual: " + curso.getSolicitudes().size());

        assertEquals(0, curso.getSolicitudes().size());
        assertNull(solicitud.getEducacionFinanciera());
    }

    /**
     * Prueba el método {@link EducacionFinanciera#toString()}.
     * Se espera que la representación en cadena tenga el formato correcto.
     */
    @Test
    void testToString() {
        EducacionFinanciera curso = new EducacionFinanciera("Inversión Responsable", "Curso sobre inversiones",
                4, "Principiante", "Online", new Categoria("Inversiones"), new Date());

        String resultado = curso.toString();

        System.out.println("Probando toString...");
        System.out.println("Salida esperada: Contiene 'Título: Inversión Responsable' y 'Descripción: Curso sobre inversiones'");
        System.out.println("Salida actual:\n" + resultado);

        assertTrue(resultado.contains("Título: Inversión Responsable"));
        assertTrue(resultado.contains("Descripción: Curso sobre inversiones"));
    }
}