package ec.edu.uce;
class SubMenuGestionarObjetivosFinancierosTest {
    public static void main(String[] args)  {
        SubMenuGestionarObjetivosFinancieros subMenu = new SubMenuGestionarObjetivosFinancieros();
        subMenu.menuGestionarObjetivosFinancieros();
    }
}