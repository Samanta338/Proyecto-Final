package ec.edu.uce.dominio;
import java.util.Date;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class SolicitudCursoTest {
        /**
         * Prueba el constructor por defecto de {@link SolicitudCurso}.
         * Se espera que la solicitud se inicialice correctamente sin valores asignados.
         */
        @Test
        void testConstructorPorDefecto() {
            SolicitudCurso solicitud = new SolicitudCurso();
            assertNotNull(solicitud);
            assertNull(solicitud.getNombreCurso());
            assertNull(solicitud.getCategoria());
            assertNull(solicitud.getDescripcion());
        }

        /**
         * Prueba el constructor con nombre y categoría de {@link SolicitudCurso}.
         * Se espera que los valores sean correctamente asignados.
         */
        @Test
        void testConstructorNombreCategoria() {
            SolicitudCurso solicitud = new SolicitudCurso("Finanzas Básicas", "Economía");
            assertEquals("Finanzas Básicas", solicitud.getNombreCurso());
            assertEquals("Economía", solicitud.getCategoria());
            assertNotNull(solicitud.getFechaSolicitud());
        }

        /**
         * Prueba el constructor completo de {@link SolicitudCurso}.
         * Se verifica que los atributos sean correctamente asignados.
         */
        @Test
        void testConstructorCompleto() {
            Date fechaSolicitud = new Date();
            SolicitudCurso solicitud = new SolicitudCurso("Gestión de Inversiones", "Finanzas", "Curso sobre inversión",
                    4, "Avanzado", "Online");

            assertEquals("Gestión de Inversiones", solicitud.getNombreCurso());
            assertEquals("Finanzas", solicitud.getCategoria());
            assertEquals("Curso sobre inversión", solicitud.getDescripcion());
            assertEquals(4, solicitud.getDuracionSemanas());
            assertEquals("Avanzado", solicitud.getNivel());
            assertEquals("Online", solicitud.getModalidad());
            assertNotNull(solicitud.getFechaSolicitud());
        }

        /**
         * Prueba los métodos setters de {@link SolicitudCurso}.
         * Se espera que los valores puedan ser modificados correctamente.
         */
        @Test
        void testSetters() {
            SolicitudCurso solicitud = new SolicitudCurso();
            solicitud.setNombreCurso("Marketing Financiero");
            solicitud.setCategoria("Negocios");
            solicitud.setDescripcion("Curso avanzado de estrategias financieras");
            solicitud.setDuracionSemanas(6);
            solicitud.setNivel("Intermedio");
            solicitud.setModalidad("Presencial");
            Date nuevaFecha = new Date();
            solicitud.setFechaSolicitud(nuevaFecha);

            assertEquals("Marketing Financiero", solicitud.getNombreCurso());
            assertEquals("Negocios", solicitud.getCategoria());
            assertEquals("Curso avanzado de estrategias financieras", solicitud.getDescripcion());
            assertEquals(6, solicitud.getDuracionSemanas());
            assertEquals("Intermedio", solicitud.getNivel());
            assertEquals("Presencial", solicitud.getModalidad());
            assertEquals(nuevaFecha, solicitud.getFechaSolicitud());
        }

        /**
         * Prueba la asociación de {@link SolicitudCurso} con {@link EducacionFinanciera}.
         * Se espera que la solicitud pueda vincularse con un curso de educación financiera.
         */
        @Test
        void testAsociarEducacionFinanciera() {
            EducacionFinanciera curso = new EducacionFinanciera();
            SolicitudCurso solicitud = new SolicitudCurso();
            solicitud.setEducacionFinanciera(curso);

            assertEquals(curso, solicitud.getEducacionFinanciera());
        }

        /**
         * Prueba la asociación de {@link SolicitudCurso} con {@link Usuario}.
         * Se espera que la solicitud pueda vincularse con un usuario específico.
         */
        @Test
        void testAsociarUsuario() {
            Usuario usuario = new Usuario("Juan Pérez", "password123", "juan@example.com", 0, 1);
            SolicitudCurso solicitud = new SolicitudCurso();
            solicitud.setUsuario(usuario);

            assertEquals(usuario, solicitud.getUsuario());
        }

        /**
         * Prueba el método {@link SolicitudCurso#toString()}.
         * Se verifica que la representación en cadena tenga el formato correcto.
         */
        @Test
        void testToString() {
            SolicitudCurso solicitud = new SolicitudCurso("Economía Global", "Macroeconomía");
            String resultado = solicitud.toString();

            assertTrue(resultado.contains("Curso: Economía Global"));
            assertTrue(resultado.contains("Categoría: Macroeconomía"));
        }
    }