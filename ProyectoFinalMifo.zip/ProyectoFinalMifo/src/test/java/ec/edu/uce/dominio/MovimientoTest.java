package ec.edu.uce.dominio;
import ec.edu.uce.util.ExcepcionMifo;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class MovimientoTest {

        /**
         * Prueba el constructor por defecto de la clase {@link Movimiento}.
         * Se espera que el movimiento se inicialice con valores predeterminados.
         */
        @Test
        void testConstructorPorDefecto() {
            Movimiento movimiento = new Movimiento() {
                @Override
                public boolean registrar() {
                    return false;
                }

                @Override
                public boolean validarDuplicado(Movimiento var1) {
                    return false;
                }

                @Override
                public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
                }
            };

            System.out.println("Probando constructor por defecto...");
            System.out.println("Descripción esperada: Sin descripcion | Actual: " + movimiento.getDescripcion());
            System.out.println("Monto esperado: 0.0 | Actual: " + movimiento.getMonto());
            System.out.println("Categoría esperada: Otro | Actual: " + movimiento.getCategoria().getNombreCategoria());

            assertNotNull(movimiento);
            assertEquals("Sin descripcion", movimiento.getDescripcion());
            assertEquals(0.0, movimiento.getMonto());
            assertEquals("Otro", movimiento.getCategoria().getNombreCategoria());
        }

        /**
         * Prueba el constructor con descripción, monto y categoría.
         * Se verifica que los atributos sean correctamente asignados.
         */
        @Test
        void testConstructorConDescripcionMontoCategoria() {
            Categoria categoria = new Categoria("Educación");
            Movimiento movimiento = new Movimiento("Pago de matrícula", 500.0, categoria) {
                @Override
                public boolean registrar() {
                    return false;
                }

                @Override
                public boolean validarDuplicado(Movimiento var1) {
                    return false;
                }

                @Override
                public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
                }
            };

            System.out.println("Probando constructor con descripción, monto y categoría...");
            System.out.println("Descripción esperada: Pago de matrícula | Actual: " + movimiento.getDescripcion());
            System.out.println("Monto esperado: 500.0 | Actual: " + movimiento.getMonto());
            System.out.println("Categoría esperada: Educación | Actual: " + movimiento.getCategoria().getNombreCategoria());

            assertEquals("Pago de matrícula", movimiento.getDescripcion());
            assertEquals(500.0, movimiento.getMonto());
            assertEquals("Educación", movimiento.getCategoria().getNombreCategoria());
        }

        /**
         * Prueba el método {@link Movimiento#setCategoria(Categoria)}.
         * Se verifica que la categoría del movimiento pueda modificarse correctamente.
         */
        @Test
        void testSetCategoria() {
            Movimiento movimiento = new Movimiento() {
                @Override
                public boolean registrar() {
                    return false;
                }

                @Override
                public boolean validarDuplicado(Movimiento var1) {
                    return false;
                }

                @Override
                public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
                }
            };
            Categoria nuevaCategoria = new Categoria("Transporte");
            movimiento.setCategoria(nuevaCategoria);

            System.out.println("Probando setCategoria...");
            System.out.println("Nueva categoría esperada: Transporte | Actual: " + movimiento.getCategoria().getNombreCategoria());

            assertEquals("Transporte", movimiento.getCategoria().getNombreCategoria());
        }

        /**
         * Prueba el método {@link Movimiento#toString()}.
         * Se verifica que la representación en cadena tenga el formato correcto.
         */
        @Test
        void testToString() {
            Movimiento movimiento = new Movimiento("Compra de libros", 200.0, new Categoria("Educación")) {
                @Override
                public boolean registrar() {
                    return false;
                }

                @Override
                public boolean validarDuplicado(Movimiento var1) {
                    return false;
                }

                @Override
                public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
                }
            };
            String resultado = movimiento.toString();

            System.out.println("Probando toString...");
            System.out.println("Salida obtenida:\n" + resultado);

            assertTrue(resultado.contains("Descripcion= Compra de libros"));
            assertTrue(resultado.contains("Monto= 200.0"));
            assertTrue(resultado.contains("Categoria= Educación"));
        }
    }