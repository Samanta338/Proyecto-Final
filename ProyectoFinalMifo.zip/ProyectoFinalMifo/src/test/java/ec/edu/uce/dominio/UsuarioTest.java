package ec.edu.uce.dominio;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;
import ec.edu.uce.util.ExcepcionMifo;
import org.junit.jupiter.api.Test;
class UsuarioTest {
    @Test
    void testCrearPresupuestoValido() {
        Usuario usuario = new Usuario("Juan", "1234", "juan@example.com", 0, 101);

        try {
            usuario.crearPresupuesto(2000.0, new Date());
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            fail("No debería lanzar excepción para un monto válido.");
        }

        // Verifica que el número de presupuestos aumentó correctamente
        assertEquals(1, usuario.getNumPresupuestos());
    }

        @Test
        void testCambiarContrasenaCorrecta() {
            Usuario usuario = new Usuario("Juan", "1234", "juan@example.com", 0, 101);

            // Cambiar la contraseña con la actual correcta
            assertDoesNotThrow(() -> usuario.cambiarContrasena("1234", "nuevaClave"));
            assertEquals("nuevaClave", usuario.getContrasena());
        }

        @Test
        void testCambiarContrasenaIncorrecta() {
            Usuario usuario = new Usuario("Juan", "1234", "juan@example.com", 0, 101);

            // Intentar cambiar la contraseña con una incorrecta
            assertThrows(ExcepcionMifo.ContrasenaInvalidaExcepcion.class, () -> usuario.cambiarContrasena("9999", "nuevaClave"));
        }

    }


