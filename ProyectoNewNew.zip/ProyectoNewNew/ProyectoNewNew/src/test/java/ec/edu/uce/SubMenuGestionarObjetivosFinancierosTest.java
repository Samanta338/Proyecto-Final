package ec.edu.uce;

import ec.edu.uce.GUI.SubMenuGestionarObjetivosFinancieros;

class SubMenuGestionarObjetivosFinancierosTest {
    public static void main(String[] args)  {
        SubMenuGestionarObjetivosFinancieros subMenu = new SubMenuGestionarObjetivosFinancieros();
        subMenu.menuGestionarObjetivosFinancieros();
    }
}