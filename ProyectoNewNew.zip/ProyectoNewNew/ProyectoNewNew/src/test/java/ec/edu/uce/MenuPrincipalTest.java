package ec.edu.uce;
import ec.edu.uce.GUI.MenuPrincipal;
import ec.edu.uce.Util.ExcepcionMifo;
class MenuPrincipalTest {
    public static void main(String[] args) throws ExcepcionMifo {
        MenuPrincipal menuPrincipal = new MenuPrincipal();
        menuPrincipal.mostrarMenuPrincipal();
    }
}