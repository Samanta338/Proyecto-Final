/*package ec.edu.uce.dominio;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class SolicitudCursoTest {
    @Test
    public void testEquals() {
        EducacionFinanciera curso = new EducacionFinanciera("Ahorro", EducacionFinanciera.NIVEL_BASICO);
        Usuario usuario = new Usuario("Juan","Perez", "juan@gmail.com", "1713158564");
        Date fecha = new Date();

        SolicitudCurso s1 = new SolicitudCurso(curso, usuario, fecha);
        SolicitudCurso s2 = new SolicitudCurso(curso, usuario, fecha);

        assertTrue(s1.equals(s2), "Las solicitudes s1 y s2 deben ser iguales");
        assertTrue(s2.equals(s1), "Las solicitudes s2 y s1 deben ser iguales");

        SolicitudCurso s3 = new SolicitudCurso(null, usuario, fecha);
        assertFalse(s1.equals(s3), "s1 no debe ser igual a s3 (curso null)");

        SolicitudCurso s4 = new SolicitudCurso(curso, null, fecha);
        assertFalse(s1.equals(s4), "s1 no debe ser igual a s4 (usuario null)");

        SolicitudCurso s5 = new SolicitudCurso(curso, usuario, new Date(fecha.getTime() + 1000));
        assertFalse(s1.equals(s5), "s1 no debe ser igual a s5 (fecha distinta)");

        assertFalse(s1.equals(null), "s1 no debe ser igual a null");
        assertFalse(s1.equals(new Object()), "s1 no debe ser igual a un objeto diferente");
    }
    @Test
    public void testToString() {
        EducacionFinanciera curso = new EducacionFinanciera("Educación Financiera", EducacionFinanciera.NIVEL_INTERMEDIO);
        Usuario usuario = new Usuario("Luis","Perez", "juan@gmail.com", "1713158564");
        Date fecha = new Date();

        SolicitudCurso s = new SolicitudCurso(curso, usuario, fecha);
        String texto = s.toString();

        assertTrue(texto.contains("Curso: Educación Financiera"));
        assertTrue(texto.contains("Usuario:"));
        assertTrue(texto.contains("Luis"));
        assertTrue(texto.contains("Fecha de solicitud:"));

        SolicitudCurso sSinDatos = new SolicitudCurso();
        String textoSinDatos = sSinDatos.toString();
        assertTrue(textoSinDatos.contains("Curso: No especificado"));
        assertTrue(textoSinDatos.contains("Usuario: No especificado"));
        assertTrue(textoSinDatos.contains("Fecha de solicitud:"));
    }

}*/
