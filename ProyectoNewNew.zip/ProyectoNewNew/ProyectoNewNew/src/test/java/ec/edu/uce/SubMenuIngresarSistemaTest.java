package ec.edu.uce;
import ec.edu.uce.Dominio.Usuario;
import ec.edu.uce.GUI.SubMenuIngresarSistema;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Prueba unitaria para {@link SubMenuIngresarSistema}.
 * Se verifica la correcta inicialización del menú.
 */
class SubMenuIngresarSistemaTest {
    public class EjecutarSubMenuUsuario {
        public static void main(String[] args) {
            Usuario usuario = new Usuario("juan", "pass123", "juan@mail.com", "1234567890");
            SubMenuIngresarSistema subMenu = new SubMenuIngresarSistema(usuario);
            subMenu.menuIngresarSistema();
        }
    }
}
