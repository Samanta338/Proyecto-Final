package ec.edu.uce;
import ec.edu.uce.Dominio.Usuario;
import ec.edu.uce.GUI.MenuMifo;
import ec.edu.uce.Util.ExcepcionMifo;
class MenuMifoTest {
    public static void main(String[] args) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Usuario usuario = new Usuario("admin", "contraseña", "admin@gmail.com", "2300330673");
        MenuMifo menuMifo = new MenuMifo(usuario);
        menuMifo.menuMifo();
    }
}
