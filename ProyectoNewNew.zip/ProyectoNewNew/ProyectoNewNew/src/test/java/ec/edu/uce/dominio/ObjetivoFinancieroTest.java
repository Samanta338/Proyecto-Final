package ec.edu.uce.dominio;
import ec.edu.uce.Dominio.Categoria;
import ec.edu.uce.Dominio.ObjetivoFinanciero;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
class ObjetivoFinancieroTest {

    @Test
    public void testConstructorPorDefecto() {
        ObjetivoFinanciero obj = new ObjetivoFinanciero();

        assertEquals("Sin descripcion", obj.getDescripcion());
        assertEquals(0.0, obj.getMonto());
        assertNotNull(obj.getFecha());
        assertNotNull(obj.getCategoria());
        // Corrige esta línea con tilde
        assertEquals("Sin categoría", obj.getCategoria().getNombreCategoria());
    }
    @Test
    public void testToStringContieneDatos() {
        Categoria cat = new Categoria("Educación");
        ObjetivoFinanciero obj = new ObjetivoFinanciero("Ahorro para viajes", 1000.0, new Date(), cat);

        String texto = obj.toString();
        System.out.println(texto);
        assertTrue(texto.toLowerCase().contains("ahorro para viajes".toLowerCase()));
        assertTrue(texto.contains("1000.00") || texto.contains("1000"));
        assertTrue(texto.contains("Educación"));
        assertTrue(texto.contains("ObjetivoFinanciero"));
    }
    @Test
    public void testConstructorConParametros() {
        Date fecha = new Date();
        Categoria cat = new Categoria("Educación");
        ObjetivoFinanciero obj = new ObjetivoFinanciero("Ahorro para cursos", 1500.0, fecha, cat);

        assertEquals("Ahorro para cursos", obj.getDescripcion());
        assertEquals(1500.0, obj.getMonto());
        assertEquals(fecha, obj.getFecha());
        assertEquals(cat, obj.getCategoria());
    }

}