/*package ec.edu.uce.dominio;

import ec.edu.uce.util.ExcepcionMifo;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class ReporteObjetivosFinancierosTest {

    @Test
    void reporteObjetivosFinancieros() {
        Empresa empresa = Empresa.getInstance();

        Categoria catAhorro = new Categoria("Ahorro", TipoMovimiento.INGRESO);
        Categoria catGasto = new Categoria("Gastos", TipoMovimiento.GASTO);

        try {
            empresa.agregarCategoria(catAhorro);
            empresa.agregarCategoria(catGasto);
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al agregar categorías: " + e.getMessage());
        }

        // Crear usuarios
        Usuario u1 = new Usuario("Luis", "123", "luis@correo.com", "111");
        Usuario u2 = new Usuario("Maria", "456", "maria@correo.com", "222");

        try {
            empresa.agregarUsuario(u1);
            empresa.agregarUsuario(u2);
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al agregar usuario: " + e.getMessage());
        }



        Presupuesto p1 = new Presupuesto(300.0, new Date(), TipoPresupuesto.MENSUAL);
        Presupuesto p2 = new Presupuesto(200.0, new Date(), TipoPresupuesto.MENSUAL);

        p1.setUsuario(u1);
        p2.setUsuario(u2);

        empresa.getListaPresupuestos()[0] = p1;
        empresa.getListaPresupuestos()[1] = p2;
        // Crear objetivos financieros
        ObjetivoFinanciero o1 = new ObjetivoFinanciero("Meta de ahorro mensual", 150.0, new Date(), catAhorro);
        ObjetivoFinanciero o2 = new ObjetivoFinanciero("Reducir gastos hormiga", 100.0, new Date(), catGasto);
        ObjetivoFinanciero o3 = new ObjetivoFinanciero("Ahorrar para vacaciones", 200.0, new Date(), catAhorro);

        empresa.getListaObjetivosFinancieros()[0] = o1;
        empresa.getListaObjetivosFinancieros()[1] = o2;
        empresa.getListaObjetivosFinancieros()[2] = o3;
    }
}
*/