/*package ec.edu.uce.dominio;

import ec.edu.uce.util.ExcepcionMifo;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ReporteCursoSolicitadosTest {

    @Test
    void reporteCursosSolicitados() {
        Empresa empresa = Empresa.getInstance();

        Categoria categoriaX = new Categoria("General");
        Usuario u1 = new Usuario("Carlos", "123", "carlos@correo.com", "1711111111");
        Usuario u2 = new Usuario("Ana", "456", "ana@correo.com", "1711111112");
        Usuario u3 = new Usuario("Daniela", "789", "daniela@correo.com", "1711111113");
        Usuario u4 = new Usuario("Ana", "456", "ana2@correo.com", "1711111114");


        try {
            empresa.agregarUsuario(u1);
            empresa.agregarUsuario(u2);
            empresa.agregarUsuario(u3);
            empresa.agregarUsuario(u4);
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al agregar usuario: " + e.getMessage());
        }

        EducacionFinanciera curso1 = new EducacionFinanciera("Finanzas Personales", "BASICO");
        EducacionFinanciera curso2 = new EducacionFinanciera("Ahorro Familiar", "INTERMEDIO");


        // Crear solicitudes utilizando constructor con curso y usuario
        SolicitudCurso s1 = new SolicitudCurso(curso1, u1);
        SolicitudCurso s2 = new SolicitudCurso(curso2, u2);
        SolicitudCurso s3 = new SolicitudCurso(curso1, u4);
        SolicitudCurso s4 = new SolicitudCurso(curso2, u3);

        // Asociar solicitudes a cursos
        try {
            curso1.agregarSolicitud(s1, s3);
            curso2.agregarSolicitud(s2, s4);
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al agregar solicitudes: " + e.getMessage());
        }

        // Registrar solicitudes en Empresa
        empresa.registrarSolicitud(s1);
        empresa.registrarSolicitud(s2);
        empresa.registrarSolicitud(s3);
        empresa.registrarSolicitud(s4);

        // Generar el reporte
        String resultado = ReporteCursoSolicitados.reporteCursosSolicitados();
        System.out.println("=== Reporte de Cursos Solicitados ===");
        System.out.println(resultado);

        // Verificación ligera (visual)
        assert resultado.contains("Usuario: Ana");
        assert resultado.contains("Usuario: Carlos");
        assert resultado.contains("Usuario: Daniela");
    }
}*/