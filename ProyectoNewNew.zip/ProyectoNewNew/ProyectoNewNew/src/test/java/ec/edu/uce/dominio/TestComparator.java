package ec.edu.uce.dominio;
import ec.edu.uce.Dominio.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
public class TestComparator {
    public static void main(String[] args) {
        // Categorías
        List<Categoria> categorias = new ArrayList<>();
        categorias.add(new Categoria("Inversiones"));
        categorias.add(new Categoria("Ahorro"));
        categorias.add(new Categoria("Gastos"));

        System.out.println("-------- Categorías ordenadas por nombre --------");
        Collections.sort(categorias, new OrdenarCategoriaPorNombre());
        categorias.forEach(System.out::println);

        System.out.println("-------- Categorías ordenadas por ID --------");
        Collections.sort(categorias, new OrdenarCategoriaPorId());
        categorias.forEach(System.out::println);

        // Educación Financiera
        List<EducacionFinanciera> cursos = new ArrayList<>();
        cursos.add(new EducacionFinanciera("Curso A", 5, EducacionFinanciera.NIVEL_BASICO));
        cursos.add(new EducacionFinanciera("Curso B", 10, EducacionFinanciera.NIVEL_INTERMEDIO));
        cursos.add(new EducacionFinanciera("Curso C", 3, EducacionFinanciera.NIVEL_AVANZADO));

        System.out.println("-------- Cursos ordenados por duración --------");
        Collections.sort(cursos, new OrdenarEducacionPorDuracion());
        cursos.forEach(System.out::println);

        // Movimientos
        List<Movimiento> movimientos = new ArrayList<>();
        movimientos.add(new Gasto("Compra", 80.50, new Date()));
        movimientos.add(new Ingreso("Salario", 400.00, new Date()));
        movimientos.add(new Ingreso("Inversión", 200.00, new Date()));

        System.out.println("-------- Movimientos ordenados por monto --------");
        Collections.sort(movimientos, new OrdenarMovimientoPorMontoDescendente());
        movimientos.forEach(System.out::println);

        // Objetivos Financieros
        List<ObjetivoFinanciero> objetivos = new ArrayList<>();
        objetivos.add(new ObjetivoFinanciero("Viaje", 1000.0, new Date(), new Categoria("Ahorro")));
        objetivos.add(new ObjetivoFinanciero("Carro", 8000.0, new Date(), new Categoria("Inversiones")));
        objetivos.add(new ObjetivoFinanciero("Estudios", 3000.0, new Date(), new Categoria("Educación")));

        System.out.println("-------- Objetivos ordenados por monto --------");
        Collections.sort(objetivos, new OrdenarObjetivoPorMonto());
        objetivos.forEach(System.out::println);

        List<Usuario> usuarios = new ArrayList<>();
        usuarios.add(new Usuario("Carlos", "clave123", "carlos@mail.com", "1100110011"));
        usuarios.add(new Usuario("Ana", "clave456", "ana@mail.com", "1100110012"));
        usuarios.add(new Usuario("Bruno", "clave789", "bruno@mail.com", "1100110013"));

        System.out.println("-------- Usuarios ordenados por nombre --------");
        Collections.sort(usuarios); // Usa compareTo() de Usuario
        usuarios.forEach(System.out::println);

        System.out.println("-------- Usuarios ordenados por código --------");
        Collections.sort(usuarios, new OrdenarUsuarioPorCodigo()); // Usa Comparator
        usuarios.forEach(System.out::println);

    }

}

