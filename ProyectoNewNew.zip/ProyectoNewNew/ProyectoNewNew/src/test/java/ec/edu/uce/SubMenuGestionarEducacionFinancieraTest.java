package ec.edu.uce;

import ec.edu.uce.GUI.SubMenuGestionarEducacionFinanciera;

class SubMenuGestionarEducacionFinancieraTest {
    public static void main(String[] args) {
        SubMenuGestionarEducacionFinanciera subMenu= new SubMenuGestionarEducacionFinanciera();
        subMenu.menuGestionarEducacionFinanciera();
    }
}