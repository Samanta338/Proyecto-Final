package ec.edu.uce.dominio;
import java.util.Set;
import java.util.TreeSet;
public class TestCategoriaComparable {
    public static void main(String[] args) {
        Set<Categoria> categorias = new TreeSet<>(new OrdenarCategoriaPorId());
        categorias.add(new Categoria("Alimentos", TipoMovimiento.INGRESO));
        categorias.add(new Categoria("Transporte", TipoMovimiento.GASTO));
        categorias.add(new Categoria("Salud", TipoMovimiento.GASTO));
        categorias.add(new Categoria("Educacion", TipoMovimiento.INGRESO));
        for (Categoria c : categorias) {
            System.out.println(c);
        }
    }
}
