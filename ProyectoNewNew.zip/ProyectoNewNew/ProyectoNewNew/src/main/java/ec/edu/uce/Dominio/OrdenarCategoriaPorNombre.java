package ec.edu.uce.Dominio;
import java.util.Comparator;
public class OrdenarCategoriaPorNombre implements Comparator<Categoria> {
    @Override
    public int compare(Categoria c1, Categoria c2) {
        int resultado = c1.getNombreCategoria().compareTo(c2.getNombreCategoria());
        if (resultado!= 0) {
            return resultado;
        } else {
            return 0;
        }
    }
}
