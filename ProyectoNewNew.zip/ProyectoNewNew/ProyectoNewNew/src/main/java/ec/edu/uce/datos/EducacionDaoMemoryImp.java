package ec.edu.uce.datos;
import ec.edu.uce.Dominio.EducacionFinanciera;
import java.util.ArrayList;
import java.util.List;
public class EducacionDaoMemoryImp {
    private static List<EducacionFinanciera> cursos = new ArrayList<>();
    public void agregar(EducacionFinanciera curso) {
        cursos.add(curso);
    }
    public void editar(EducacionFinanciera curso) {
        for (int i = 0; i < cursos.size(); i++) {
            if (cursos.get(i).getCodigo() == curso.getCodigo()) {
                cursos.set(i, curso);
                return;
            }
        }
    }
    public void eliminar(int id) {
        for (int i = 0; i < cursos.size(); i++) {
            EducacionFinanciera c = cursos.get(i);
            if (c.getCodigo() == id) {
                cursos.remove(i);
                i--;
            }
        }
    }
    public EducacionFinanciera buscarPorId(int id) {
        for (EducacionFinanciera c : cursos) {
            if (c.getCodigo() == id) return c;
        }
        return null;
    }
    public List<EducacionFinanciera> listar() {
        return new ArrayList<>(cursos);
    }
}