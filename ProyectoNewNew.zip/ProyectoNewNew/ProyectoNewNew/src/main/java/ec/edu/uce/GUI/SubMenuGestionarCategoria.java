/**
 * Clase que representa el submenú para gestionar categorías en el sistema MIFO.
 * Permite crear, editar, eliminar y consultar categorías dentro de la aplicación.
 */
package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.*;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import ec.edu.uce.Util.ExcepcionMifo.MovimientoInvalidoExcepcion;

import java.util.*;

public class SubMenuGestionarCategoria {
    /**
     * Scanner para leer la entrada del usuario desde la consola.
     */
    private Scanner entrada = new Scanner(System.in);

    /**
     * Arreglo que almacena las categorías registradas en el sistema.
     */

    List<Categoria> categorias = Empresa.getInstance().getCategorias();

    /**
     * Instancia de la empresa que administra las categorías.
     */
    private Empresa empresa = Empresa.getInstance();

    /**
     * Muestra el menú de gestión de categorías y procesa la opción elegida por el usuario.
     */
    public void menuGestionarCategoria() {
        int seleccion;
        do {
            mostrarMenuGestionarCategorias();
            seleccion = ComprobacionMenu.validarOpcionMenu(entrada, 7);
            try {
                procesarOpcionGestionarCategorias(seleccion);
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (seleccion != 5 && seleccion != 6);
    }

    /**
     * Muestra las opciones disponibles en el submenú de gestión de categorías.
     */
    private void mostrarMenuGestionarCategorias() {
        System.out.println();
        System.out.println("  ---------------------------------------  ");
        System.out.println(" |           Gestionar Categoría            |");
        System.out.println("  ---------------------------------------  ");
        System.out.println(" |  1. Crear Categoría                     |");
        System.out.println(" |  2. Editar Categoría                    |");
        System.out.println(" |  3. Eliminar Categoría                  |");
        System.out.println(" |  4. Consultar Categoría                 |");
        System.out.println(" |  5. Ordenar Categorías                  |");
        System.out.println(" |  6. Volver al menú principal            |");
        System.out.println(" |  7. Salir del programa                  |");
        System.out.println("  ---------------------------------------  ");
        System.out.println();
        System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
    }

    /**
     * Procesa la opción elegida en el menú e invoca la funcionalidad correspondiente.
     *
     * @param seleccion Opción elegida por el usuario.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si se produce un error en la gestión de movimientos de categoría.
     */
    private void procesarOpcionGestionarCategorias(int seleccion) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        switch (seleccion) {
            case 1:
                crearCategoria();
                break;
            case 2:
                editarCategoria();
                break;
            case 3:
                eliminarCategoria();
                break;
            case 4:
                consultarCategorias();
                break;
            case 5:
                mostrarSubmenuOrdenamiento();;
                break;
            case 6:
                System.out.println();
                System.out.println("Volviendo al menú principal...");
                return;

            case 7:
                System.out.println();
                System.out.println("                                     Cerrando el sistema.");
                System.out.println("------------------------------------------------------------------------------------------------");
                System.out.println("Gracias por haber confiado en Mifo. Esperamos que nuestra plataforma te haya sido de gran ayuda.");
                System.exit(0);
                break;
            default:
                System.out.println("Opción no válida, por favor intente de nuevo.");
        }
    }

    /**
     * CRUD: Crear categoría
     * Crea una nueva categoría verificando la validez de los datos ingresados.
     */
    private void crearCategoria() {
        System.out.println(" --------------------------------------------------------");
        String nombreCategoria;
        TipoMovimiento tipoMovimiento;

        // Validación del nombre de la categoría
        while (true) {
            System.out.print(" | Ingrese el nombre de la categoría: ");
            nombreCategoria = entrada.nextLine().trim();
            if (nombreCategoria == null || nombreCategoria.trim().isEmpty()) {
                System.out.println("Error: El nombre no puede estar vacío.");
                continue;
            }
            if (ComprobacionMenu.validarNombreCategoria(nombreCategoria)) {
                if (buscarCategoriaPorNombreCategoria(nombreCategoria) == null) {
                    break;
                } else {
                    System.out.println("Error: La categoría ya existe. Intente con otro nombre.");
                }
            }
        }

        // Selección del tipo de movimiento
        while (true) {
            System.out.println(" | Seleccione el tipo de movimiento:");
            TipoMovimiento[] movimientos = TipoMovimiento.values();
            for (int i = 0; i < movimientos.length; i++) {
                System.out.println("   " + (i + 1) + ". " + movimientos[i]);
            }
            System.out.print("Ingrese la opción: ");
            if (entrada.hasNextInt()) {
                int opcionMovimiento = entrada.nextInt();
                entrada.nextLine(); // Limpiar buffer
                if (opcionMovimiento >= 1 && opcionMovimiento <= movimientos.length) {
                    tipoMovimiento = movimientos[opcionMovimiento - 1];
                    break;
                } else {
                    System.out.println("Opción no válida, intente nuevamente.");
                }
            } else {
                System.out.println("Debe ingresar un número válido.");
                entrada.nextLine();
            }
        }

        // Agregar categoría usando el método dedicado
        agregarCategoria(nombreCategoria, tipoMovimiento);
    }

    /**
     * Agrega una categoría al sistema con redimensionamiento dinámico del arreglo.
     *
     * @param nombreCategoria Nombre de la categoría
     * @param tipoMovimiento Tipo de movimiento de la categoría
     */
    public void agregarCategoria(String nombreCategoria, TipoMovimiento tipoMovimiento) {
        if (nombreCategoria == null || nombreCategoria.trim().isEmpty()) {
            System.out.println("Error: El nombre de la categoría no puede estar vacío.");
            return;
        }
        if (tipoMovimiento == null) {
            System.out.println("Error: El tipo de movimiento no puede ser nulo.");
            return;
        }

        Categoria categoria = new Categoria(nombreCategoria, tipoMovimiento);
        if (verificarCategoria(categoria)) {
            System.out.println("Error: La categoría ya existe.");
            return;
        }

        categorias.add(categoria); 

        try {
            empresa.agregarCategoria(categoria); // Asumo que esto aún sincroniza con Empresa
            System.out.println("✔ Categoría creada exitosamente.");
        } catch (MovimientoInvalidoExcepcion e) {
            categorias.remove(categoria); // Revierte si falla
            System.out.println("Error al agregar la categoría: " + e.getMessage());
        }
    }


    /**
     * Agrega una categoría existente al sistema.
     *
     * @param categoria Categoría a agregar
     */
    public void agregarCategoria(Categoria categoria) {
        if (categoria == null) {
            System.out.println("Error: No se puede agregar una categoría nula.");
            return;
        }

        if (categorias.contains(categoria)) {
            System.out.println("Error: La categoría ya existe.");
            return;
        }

        categorias.add(categoria);
        System.out.println("✔ Categoría agregada exitosamente.");
    }


    /**
     * CRUD: Editar categoría
     * Edita una categoría existente verificando su validez y permitiendo cambios en su nombre y tipo de movimiento.
     */
    private void editarCategoria() {
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
            return;
        }

        System.out.print(" | Ingrese el nombre de la categoría que desea editar: ");
        String nombreCategoriaAntiguo = entrada.nextLine().trim();

        // Buscar la categoría directamente en la lista
        Categoria categoriaEditar = buscarCategoriaPorNombre(nombreCategoriaAntiguo);
        if (categoriaEditar == null) {
            System.out.println("No se encontró ninguna categoría con el nombre especificado.");
            return;
        }

        String nuevoNombreCategoria;
        TipoMovimiento nuevoTipoMovimiento;

        // Validación del nuevo nombre
        while (true) {
            System.out.print(" | Ingrese el nuevo nombre de la categoría: ");
            nuevoNombreCategoria = entrada.nextLine().trim();
            if (ComprobacionMenu.validarDescripcion(nuevoNombreCategoria)) {
                Categoria duplicada = buscarCategoriaPorNombre(nuevoNombreCategoria);
                if (duplicada == null || duplicada.equals(categoriaEditar)) {
                    break;
                } else {
                    System.out.println("Ya existe otra categoría con ese nombre.");
                }
            } else {
                System.out.println("El nombre no puede estar vacío.");
            }
        }

        // Selección del nuevo tipo de movimiento
        while (true) {
            System.out.println(" | Seleccione el nuevo tipo de movimiento:");
            TipoMovimiento[] movimientos = TipoMovimiento.values();
            for (int i = 0; i < movimientos.length; i++) {
                System.out.println("   " + (i + 1) + ". " + movimientos[i]);
            }
            System.out.print("Ingrese la opción: ");
            if (entrada.hasNextInt()) {
                int opcionMovimiento = entrada.nextInt();
                entrada.nextLine(); // Limpia buffer
                if (opcionMovimiento >= 1 && opcionMovimiento <= movimientos.length) {
                    nuevoTipoMovimiento = movimientos[opcionMovimiento - 1];
                    break;
                } else {
                    System.out.println("Opción no válida.");
                }
            } else {
                System.out.println("Debe ingresar un número.");
                entrada.nextLine(); // Limpia buffer
            }
        }

        // Actualizar directamente el objeto encontrado
        categoriaEditar.setNombreCategoria(nuevoNombreCategoria);
        categoriaEditar.setTipoMovimiento(nuevoTipoMovimiento);

        System.out.println("✔ Categoría editada exitosamente.");
        System.out.println(categoriaEditar.toString());
    }

    /**
     * Edita los datos de una categoría existente.
     *
     * @param indice Índice de la categoría a editar
     * @param categoria Nueva categoría con los datos actualizados
     */
    public void editarCategoria(int indice, Categoria categoria) {
        if (indice >= 0 && indice < categorias.size()) {
            categorias.set(indice, categoria);
            System.out.println("Categoría editada exitosamente.");
        } else {
            System.out.println("Índice inválido para editar categoría.");
        }
    }

    /**
     * CRUD: Eliminar categoría
     * Elimina una categoría existente del sistema.
     */
    private void eliminarCategoria() {
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
            return;
        }
        System.out.print(" | Ingrese el nombre de la categoría que desea eliminar: ");
        String nombreCategoriaEliminar = entrada.nextLine().trim();

        Categoria categoriaEliminar = null;
        for (Categoria c : categorias) {
            if (c.getNombreCategoria().equalsIgnoreCase(nombreCategoriaEliminar)) {
                categoriaEliminar = c;
                break;
            }
        }
        if (categoriaEliminar == null) {
            System.out.println("No se encontró ninguna categoría con ese nombre.");
            return;
        }
        categorias.remove(categoriaEliminar);
        System.out.println(" -> Categoría eliminada exitosamente.");
    }


    /**
     * Elimina una categoría por índice.
     *
     * @param indice Índice de la categoría a eliminar
     */
    public void eliminarCategoria(int indice) {
        if (indice >= 0 && indice < categorias.size()) {
            categorias.remove(indice);
            System.out.println(" -> Categoría eliminada exitosamente.");
        } else {
            System.out.println("Índice inválido para eliminar categoría.");
        }
    }


    /**
     * CRUD: Consultar categoría
     * Consulta y muestra en pantalla la información de una categoría existente.
     */
    // CONSULTAR UNA CATEGORIA/******************************************* 03
    private void consultarCategoria(String nombreCategoriaConsulta) {
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
            return;
        }

        System.out.print(" | Ingrese el nombre de la categoría que desea consultar: ");

        Categoria categoriaConsulta = null;
        for (Categoria c : categorias) {
            if (c.getNombreCategoria().equalsIgnoreCase(nombreCategoriaConsulta)) {
                categoriaConsulta = c;
                break;
            }
        }

        if (categoriaConsulta == null) {
            System.out.println("No se encontró ninguna categoría con ese nombre.");
            return;
        }

        // Muestra los detalles de la categoría encontrada.
        System.out.println("Información de la categoría:");
        System.out.println("Nombre: " + categoriaConsulta.getNombreCategoria());
        System.out.println("Tipo Movimiento: " + categoriaConsulta.getTipoMovimiento());
    }

    /**
     * Consulta todas las categorías del sistema.
     *
     * @return Cadena con información de las categorías
     */
    // STRINGBUILER****************************************************** 03/07/2025
    public void consultarCategorias() {
//        String texto = "";
//        for (Categoria c : categorias) {
//            if (c != null) {
//                texto += c + "\r\n";
//            }
//        }
        System.out.println("Lista de categorias");
        System.out.println(empresa.consultarCategorias());
         //return texto;
    }
    /**
     * Busca una categoría por nombre dentro del arreglo de categorías.
     *
     * @param nombreCategoria Nombre de la categoría a buscar.
     * @return La categoría encontrada o null si no existe.
     */
    public Categoria buscarCategoriaPorNombreCategoria(String nombreCategoria) {
        for (Categoria c : categorias) {
            if (c.getNombreCategoria().equalsIgnoreCase(nombreCategoria)) {
                return c;
            }
        }
        return null;
    }


    private Categoria buscarCategoriaPorNombre(String nombre) {
        for (Categoria c : categorias) {
            if (c.getNombreCategoria().equalsIgnoreCase(nombre)) {
                return c;
            }
        }
        return null;
    }


    /**
     * Busca y retorna una categoría por índice.
     *
     * @param indice Índice de la categoría
     * @return Categoría encontrada o null si el índice no es válido
     */
    public Categoria buscarCategoria(int indice) {
        if (indice >= 0 && indice < categorias.size()) {
            return categorias.get(indice);
        }
        System.out.println("Error: Índice de categoría no válido.");
        return null;
    }


    /**
     * Verifica si una categoría ya existe en el sistema.
     *
     * @param categoria Categoría a verificar
     * @return true si ya existe, false si no
     */
    public boolean verificarCategoria(Categoria categoria) {
        if (categoria.getNombreCategoria() == null) {
            return false;
        }
        for (Categoria c : categorias) {
            if (c.getNombreCategoria().equalsIgnoreCase(categoria.getNombreCategoria())) {
                return true;
            }
        }
        return false;
    }


    /**
     * Muestra todas las categorías actualmente registradas en el sistema.
     */
    public void mostrarCategoriasDisponibles() {
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
            return;
        }
        System.out.println("Categorías disponibles:");
        for (Categoria c : categorias) {
            System.out.println(" - " + c.getNombreCategoria() + " (" + c.getTipoMovimiento() + ")");
        }
    }

    /**
     * Método que pide al usuario ingresar datos para crear una nueva categoría y la devuelve.
     * @return La nueva categoría creada con los datos ingresados por el usuario.
     */
    public Categoria pedirOCrearCategoria() {
        String nombreCategoria;
        TipoMovimiento tipoMovimiento;

        while (true) {
            System.out.print("Ingrese el nombre de la categoría: ");
            nombreCategoria = entrada.nextLine().trim();
            if (ComprobacionMenu.validarDescripcion(nombreCategoria)) {
                if (buscarCategoriaPorNombreCategoria(nombreCategoria) == null) {
                    break;
                } else {
                    System.out.println("La categoría ya existe. Intente con otro nombre.");
                }
            } else {
                System.out.println("El nombre no puede estar vacío.");
            }
        }

        while (true) {
            System.out.println("Seleccione el tipo de movimiento:");
            TipoMovimiento[] movimientos = TipoMovimiento.values();
            for (int i = 0; i < movimientos.length; i++) {
                System.out.println((i + 1) + ". " + movimientos[i]);
            }
            System.out.print("Ingrese la opción: ");
            if (entrada.hasNextInt()) {
                int opcionMovimiento = entrada.nextInt();
                entrada.nextLine();
                if (opcionMovimiento >= 1 && opcionMovimiento <= movimientos.length) {
                    tipoMovimiento = movimientos[opcionMovimiento - 1];
                    break;
                } else {
                    System.out.println("Opción no válida, intente nuevamente.");
                }
            } else {
                System.out.println("Debe ingresar un número válido.");
                entrada.nextLine();
            }
        }

        return new Categoria(nombreCategoria, tipoMovimiento);
    }


    private void mostrarSubmenuOrdenamiento() {
        int opcion;
        do {
            System.out.println();
            System.out.println("  -------------------------------  ");
            System.out.println(" |     Ordenar Categorías         |");
            System.out.println("  -------------------------------  ");
            System.out.println(" |  1. Por Nombre (Comparable)    |");
            System.out.println(" |  2. Por ID     (Comparator)    |");
            System.out.println(" |  3. Volver                     |");
            System.out.println("  -------------------------------  ");
            System.out.print("Seleccione una opción: ");

            opcion = ComprobacionMenu.validarOpcionMenu(entrada, 3);

            switch (opcion) {
                case 1:
                    ordenarCategoriasComparable(); // usa compareTo()
                    break;
                case 2:
                    ordenarCategorias(new OrdenarCategoriaPorId()); // usa Comparator
                    break;
                case 3:
                    menuGestionarCategoria();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 3);
    }
    private void mostrarCategoriasOrdenadas(List<Categoria> categorias) {
        if (categorias == null || categorias.isEmpty()) {
            System.out.println("No hay categorías disponibles.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("\n  ----------------------------------------------------------------------------\n");
        sb.append(String.format(" | %-3s | %-5s | %-25s | %-20s |\n", "#", "ID", "Nombre", "Tipo Movimiento"));
        sb.append("  ----------------------------------------------------------------------------\n");

        for (int i = 0; i < categorias.size(); i++) {
            Categoria c = categorias.get(i);
            sb.append(String.format(" | %-3d | %-5d | %-25s | %-20s |\n",
                    i,
                    c.getId(),
                    c.getNombreCategoria(),
                    c.getTipoMovimiento()));
        }

        sb.append("  ----------------------------------------------------------------------------");
        System.out.println(sb.toString());
    }


    public void ordenarCategoriasComparable() {
        List<Categoria> categorias = Empresa.getInstance().getCategorias();
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías para ordenar.");
            return;
        }

        Collections.sort(categorias); // usa compareTo()

        System.out.println("Categorías ordenadas por nombre (Comparable):");
        mostrarCategoriasOrdenadas(categorias);
    }

    public void ordenarCategorias(Comparator<Categoria> comparador) {
        List<Categoria> categorias = Empresa.getInstance().getCategorias();
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías para ordenar.");
            return;
        }

        Collections.sort(categorias, comparador);

        System.out.println("Categorías ordenadas por ID (Comparator):");
        mostrarCategoriasOrdenadas(categorias);
    }



}