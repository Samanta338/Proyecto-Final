package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Usuario;
import java.util.List;
public interface UsuarioDao {
    void agregar(Usuario usuario);
    void editar(Usuario usuario);
    void eliminar(int codigo);
    Usuario buscarPorCodigo(int codigo);
    List<Usuario> consultarTodos();
}
