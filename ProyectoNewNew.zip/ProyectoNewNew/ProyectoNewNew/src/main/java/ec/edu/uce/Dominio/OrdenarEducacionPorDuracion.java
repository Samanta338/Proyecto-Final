package ec.edu.uce.Dominio;
import java.util.Comparator;
public class OrdenarEducacionPorDuracion implements Comparator<EducacionFinanciera> {
    @Override
    public int compare(EducacionFinanciera e1, EducacionFinanciera e2) {
        if (e1.getDuracionSemanas() < e2.getDuracionSemanas()) {
            return -1;
        } else if (e1.getDuracionSemanas() > e2.getDuracionSemanas()) {
            return 1;
        } else {
            return 0;
        }
    }
}