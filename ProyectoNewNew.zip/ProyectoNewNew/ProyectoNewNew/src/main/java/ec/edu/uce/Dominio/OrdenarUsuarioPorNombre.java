package ec.edu.uce.Dominio;
import java.util.Comparator;
public class OrdenarUsuarioPorNombre implements Comparator<Usuario> {
    @Override
    public int compare(Usuario u1, Usuario u2) {
        int resultado = u1.getNombre().compareTo(u2.getNombre());
        if (resultado!= 0) {
            return resultado;
        } else{
            return 0;
        }
    }
}