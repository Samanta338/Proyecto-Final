package ec.edu.uce.Dominio;

import java.util.Comparator;

public class OrdenarPresupuestoPorMonto implements Comparator<Presupuesto> {
    @Override
    public int compare(Presupuesto p1, Presupuesto p2) {
        if (p1.getMontoPresupuesto() < p2.getMontoPresupuesto()) {
            return -1;
        } else if (p1.getMontoPresupuesto() > p2.getMontoPresupuesto()) {
            return 1;
        } else {
            return 0;
        }
    }
}
