package ec.edu.uce.datos;

import ec.edu.uce.Dominio.ObjetivoFinanciero;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ObjetivoDaoMemoriaImp {
    private static List<ObjetivoFinanciero> objetivos = new ArrayList<>();
    public void agregar(ObjetivoFinanciero objetivo) {
        objetivos.add(objetivo);
    }
    public void editar(ObjetivoFinanciero objetivo) {
        for (int i = 0; i < objetivos.size(); i++) {
            if (objetivos.get(i).getCodigo() == objetivo.getCodigo()) {
                objetivos.set(i, objetivo);
                return;
            }
        }
        System.out.println("Objetivo no encontrado para editar.");
    }
    public void eliminar(int codigo) {
        for (int i = 0; i < objetivos.size(); i++) {
            ObjetivoFinanciero obj = objetivos.get(i);
            if (obj != null && obj.getCodigo() == codigo) {
                objetivos.remove(i);
                return;
            }
        }
        System.out.println("Objetivo no encontrado para eliminar.");
    }
    public ObjetivoFinanciero buscarPorCodigo(int codigo) {
        for (ObjetivoFinanciero obj : objetivos) {
            if (obj.getCodigo() == codigo) {
                return obj;
            }
        }
        return null;
    }
    public List<ObjetivoFinanciero> consultarObjetivos() {
        return new ArrayList<>(objetivos);
    }
}
