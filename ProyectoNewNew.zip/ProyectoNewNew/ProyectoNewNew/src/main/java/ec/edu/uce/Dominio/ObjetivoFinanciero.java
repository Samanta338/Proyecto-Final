package ec.edu.uce.Dominio;
import java.util.Date;
public class ObjetivoFinanciero implements Comparable<ObjetivoFinanciero>  {
    private String descripcion;
    private Double monto;
    private Date fecha;
    private Categoria categoria;
    private static int contadorCodigo = 0;
    private final int codigo;
    // Bloque de inicialización de instancia
    {
        this.codigo = ++contadorCodigo;
    }
    // Constructor por defecto
    public ObjetivoFinanciero() {
        this.descripcion = "Sin descripcion";
        this.monto = 0.0;
        this.fecha = new Date();
        this.categoria = new Categoria();

    }

    // Constructor con parámetros
    public ObjetivoFinanciero(String descripcion, double monto, Date fecha, Categoria categoria) {
        this.descripcion = descripcion;
        this.monto = monto;
        this.fecha = fecha;
        this.categoria = categoria;
    }

    // Constructor con descripción y monto, fecha actual, categoría por defecto
    public ObjetivoFinanciero(String descripcion, double monto) {
        this(descripcion, monto, new Date(), new Categoria());
    }

    // Constructor con descripción, monto y fecha, categoría por defecto
    public ObjetivoFinanciero(String descripcion, double monto, Date fecha) {
        this(descripcion, monto, fecha, new Categoria());
    }

    // Constructor con descripción y categoría, monto 0.0, fecha actual
    public ObjetivoFinanciero(String descripcion, Categoria categoria) {
        this(descripcion, 0.0, new Date(), categoria);
    }

    // Constructor con monto y categoría, descripción por defecto, fecha actual
    public ObjetivoFinanciero(double monto, Categoria categoria) {
        this("Sin descripcion", monto, new Date(), categoria);
    }

    // Constructor solo con monto, descripción por defecto, fecha actual, categoría por defecto
    public ObjetivoFinanciero(double monto) {
        this("Sin descripcion", monto, new Date(), new Categoria());
    }

    // Getters y setters
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getMonto() {
        return monto;
    }
    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Date getFecha() {
        return fecha;
    }
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Categoria getCategoria() {
        return categoria;
    }
    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;

    }
    public int getCodigo() {
        return codigo;
    }
    @Override
    public boolean equals(Object o) {
        boolean result = false;
        if (o != null && o instanceof ObjetivoFinanciero) {
            ObjetivoFinanciero otro = (ObjetivoFinanciero) o;
            if (this.descripcion.equals(otro.descripcion)
                    && Double.compare(this.monto, otro.monto) == 0
                    && ((this.fecha == null && otro.fecha == null)
                    || (this.fecha != null && this.fecha.equals(otro.fecha)))
                    && this.categoria.equals(otro.categoria)) {
                result = true;
            }
        }
        return result;
    }

    @Override
    public String toString() {
        return String.format("ObjetivoFinanciero {\n" +
                        "\tDescripcion: %s\n" +
                        "\tMonto:       %.2f\n" +
                        "\tFecha:       %s\n" +
                        "\tCategoria:   %s\n" +
                        "}",
                descripcion,
                monto,
                fecha,
                categoria);
    }

    public int compareTo(ObjetivoFinanciero obj1) {
        int resultado = this.monto.compareTo(obj1.getMonto());
        if (resultado > 0){
            return 1;
        } else if (resultado < 0){
            return -1;
        } else {
            return 0;
        }
    }
}
