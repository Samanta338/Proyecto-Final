package ec.edu.uce.datos;
import ec.edu.uce.Dominio.EducacionFinanciera;
import java.util.List;
public interface EducacionFinancieraDao {
        void agregar(EducacionFinanciera curso);
        void editar(EducacionFinanciera curso);
        void eliminar(int id);
        EducacionFinanciera buscarPorId(int id);
        List<EducacionFinanciera> listar();
}
