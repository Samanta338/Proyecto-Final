package ec.edu.uce.Dominio;
/**
 * Enumeración que representa los tipos de movimiento financiero.
 * Cada tipo tiene un código, descripción, prioridad y un límite mensual sugerido.
 */
public enum TipoMovimiento {
    /**
     * Representa un ingreso de dinero.
     */
     INGRESO("I", "Entrada de dinero al presupuesto", 1, 10.0),

    /**
     * Representa un gasto de dinero.
     */
    GASTO("G", "Salida de dinero del presupuesto", 2, 500.0);
    private final String codigo;
    private final String descripcion;
    private final int prioridad;
    private final double limiteMensualSugerido;

    /**
     * Constructor del tipo de movimiento.
     *
     * @param codigo Código abreviado del tipo
     * @param descripcion Descripción del tipo
     * @param prioridad Prioridad del tipo (1 = alta, 2 = media, etc.)
     * @param limiteMensualSugerido Límite sugerido mensual en dinero
     */
    private TipoMovimiento(String codigo, String descripcion, int prioridad, double limiteMensualSugerido) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.limiteMensualSugerido = limiteMensualSugerido;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public double getLimiteMensualSugerido() {
        return limiteMensualSugerido;
    }
}
