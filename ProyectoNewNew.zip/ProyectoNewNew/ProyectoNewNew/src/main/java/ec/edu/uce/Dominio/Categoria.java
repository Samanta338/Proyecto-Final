package ec.edu.uce.Dominio;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa una categoría utilizada en el sistema.
 * Cada categoría tiene un nombre, un tipo de movimiento asociado y un ID único.
 */
public class Categoria implements Comparable<Categoria> {
    private String nombreCategoria;
    private TipoMovimiento tipoMovimiento;
    private List<Categoria> categorias = new ArrayList<>();
    //private int numCategorias = 0;
    private static int contadorId = 1;
    private final int id;

    // Bloque de inicialización de instancia
    {
        id = contadorId++;
    }

    public Categoria() {
        this("Sin categoría", TipoMovimiento.GASTO);
    }

    public Categoria(String nombreCategoria) {
        this(nombreCategoria, TipoMovimiento.GASTO);
    }

    // Constructor con nombre y tipoMovimiento
    public Categoria(String nombreCategoria, TipoMovimiento tipoMovimiento) {
        this.nombreCategoria = nombreCategoria;
        this.tipoMovimiento = tipoMovimiento;

    }

    public int getId() {
        return id;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public TipoMovimiento getTipoMovimiento() {
        return tipoMovimiento;
    }

    public void setTipoMovimiento(TipoMovimiento tipoMovimiento) {
        this.tipoMovimiento = tipoMovimiento;
    }

    public List<Categoria> getCategorias() {
        return Collections.unmodifiableList(categorias);
    }

    public void eliminarCategoria(Categoria categoria) {
        categorias.remove(categoria);
    }

    /**
     * Valida si una categoría ya existe en el arreglo, para evitar duplicados.
     *
     * @return true si ya existe, false si no.
     */
    // AÑADIDO PARA VALIDAR LOS DUPLICADOS******
    public boolean validarDuplicado(Categoria categoria) {
        return categorias.contains(categoria);
    }


    @Override
    public boolean equals(Object o) {
        boolean result = false;
        if (o != null && o instanceof Categoria) {
            Categoria otraCategoria = (Categoria) o;
            if (this.nombreCategoria.equals(otraCategoria.nombreCategoria)) {
                result = true;
            }
        }
        return result;
    }

    /**
     * Agrega una categoría al arreglo, con inicialización y redimensionamiento dinámico.
     *
     * @param categoria Categoría a agregar.
     * @return true si se agregó, false si estaba duplicada.
     */
    public boolean agregarCategoria(Categoria categoria) {
        if (categorias.contains(categoria)) {
            System.out.println("Error: Categoría duplicada.");
            return false;
        }
        categorias.add(categoria);
        return true;
    }


    /**
     * Compara esta categoría con otro objeto para determinar si son iguales.
     * Dos categorías se consideran iguales si tienen el mismo nombre.
     *
     * @param o Objeto a comparar.
     * @return true si el objeto es una categoría con el mismo nombre, false en caso contrario.
     */


    /**
     * Devuelve una representación en cadena de la categoría.
     *
     * @return Cadena con el ID, nombre y tipo de movimiento de la categoría.
     */


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("  -------------------------------  \n");
        sb.append(String.format(" |     Categoría ID: %-13d     |\n", id));
        sb.append("  -------------------------------  \n");
        sb.append(String.format(" | Nombre           : %-13s |\n", nombreCategoria));
        sb.append(String.format(" | Tipo             : %-13s |\n", tipoMovimiento.toString()));
        sb.append(String.format(" | Prioridad        : %-13s |\n", tipoMovimiento.getPrioridad()));
        sb.append(String.format(" | Límite Sugerido  : $%-12.2f |\n", tipoMovimiento.getLimiteMensualSugerido()));
        sb.append(String.format(" | Descripción      : %-13s |\n", tipoMovimiento.getDescripcion()));
        sb.append("  -------------------------------  ");
        return sb.toString();
    }



    public int compareTo(Categoria c1) {
        // Primero se compara por el nombre de la categoría (orden alfabético)
        int resultado = this.nombreCategoria.compareTo(c1.getNombreCategoria());
        if (resultado > 0) {
            return 1;
        } else if (resultado < 0) {
            return -1;
        } else {
            // Si los nombres son iguales, se compara por el ID de la categoría
            //Sirve para comparar dos números enteros (int) y saber cuál es mayor, menor o si son iguales.
            // Integer que envuelve al int y le da funciones útiles.
            int resultadoId = Integer.compare(this.id, c1.getId());
            if (resultadoId > 0) {
                return 1;
            } else if (resultadoId < 0) {
                return -1;
            } else {
                return 0;
            }
        }
    }

}

