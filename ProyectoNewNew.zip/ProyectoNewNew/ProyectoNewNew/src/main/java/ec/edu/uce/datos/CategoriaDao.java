package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Categoria;
import java.util.List;
/* Métodos:
        * - agregar(Categoria categoria): agrega una nueva categoría a la fuente de datos.
 * - editar(Categoria categoria): actualiza una categoría existente, identificada por su ID.
 * - eliminar(int id): elimina una categoría según su ID.
        * - buscarPorId(int id): busca y devuelve una categoría según su ID.
        * - listarTodas(): devuelve una lista con todas las categorías disponibles.
        *
        * Facilita el cambio de implementación
        * (por ejemplo, cambiar de almacenamiento en memoria a base de datos)
        * sin afectar otras partes del sistema.
*/
public interface CategoriaDao {
        void agregar(Categoria categoria);
        void editar(Categoria categoria);
        void eliminar(int id);
        Categoria buscarPorId(int id);
        List<Categoria> listarTodas();
}
