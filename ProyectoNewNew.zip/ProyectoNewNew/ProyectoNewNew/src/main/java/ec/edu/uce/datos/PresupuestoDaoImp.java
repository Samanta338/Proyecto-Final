package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Presupuesto;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class PresupuestoDaoImp {
    private static List<Presupuesto> presupuestos = new ArrayList<>();
    public void agregar(Presupuesto presupuesto) {
        presupuestos.add(presupuesto);
    }
    public void editar(Presupuesto presupuesto) {
        for (int i = 0; i < presupuestos.size(); i++) {
            if (presupuestos.get(i).getCodigo() == presupuesto.getCodigo()) {
                presupuestos.set(i, presupuesto);
                return;
            }
        }
        System.out.println("Presupuesto no encontrado para editar.");
    }
    public void eliminar(int codigo) {
        for (int i = 0; i < presupuestos.size(); i++) {
            Presupuesto p = presupuestos.get(i);
            if (p != null && p.getCodigo() == codigo) {
                presupuestos.remove(i);
                return;
            }
        }
        System.out.println("Presupuesto no encontrado para eliminar.");
    }

    public Presupuesto buscarPorCodigo(int codigo) {
        for (Presupuesto p : presupuestos) {
            if (p.getCodigo() == codigo) {
                return p;
            }
        }
        return null;
    }
    public List<Presupuesto> consultarTodos() {
        return new ArrayList<>(presupuestos);
    }
}

