package ec.edu.uce.Util;
public class ComprobacionCredenciales {
    /**
     * Método que valida si una contraseña es válida según los siguientes criterios:
     * - Debe tener al menos 8 caracteres
     * - Debe contener al menos una letra (mayúscula o minúscula)
     * - Debe contener al menos un número
     *
     * @param contrasena La contraseña a validar
     * @return true si cumple los requisitos, false si no
     */
    public static boolean esValida(String contrasena) {
        /* Expresión regular explicada:
        // ^               : inicio de cadena
        // (?=.*[a-zA-Z])  : al menos una letra
        // (?=.*\\d)       : al menos un dígito
        // [a-zA-Z\\d]{8,} : mínimo 8 caracteres (solo letras y números)
        // $               : fin de cadena*/
        return contrasena.matches("^(?=.*[a-zA-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$");
    }
}
