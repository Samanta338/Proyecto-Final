package ec.edu.uce.Util;

import java.text.SimpleDateFormat;

public class ComprobacionFormato {

    public static final SimpleDateFormat FORMATO_FECHA_CORTA = new SimpleDateFormat("dd-MM-yyyy");
    public static final SimpleDateFormat FORMATO_FECHA_LARGA = new SimpleDateFormat("EEEE, dd MMMM yyyy");
    public static final SimpleDateFormat FORMATO_TIMESTAMP = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
}
