package ec.edu.uce.Dominio;
import java.util.Comparator;
public class OrdenarObjetivoPorMonto implements Comparator<ObjetivoFinanciero> {
    @Override
    public int compare(ObjetivoFinanciero o1, ObjetivoFinanciero o2) {
        if (o1.getMonto() < o2.getMonto()) {
            return -1;
        } else if (o1.getMonto() > o2.getMonto()) {
            return 1;
        } else {
            return 0;
        }
    }
}