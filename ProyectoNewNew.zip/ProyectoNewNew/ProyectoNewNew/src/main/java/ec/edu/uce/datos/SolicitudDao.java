package ec.edu.uce.datos;
import ec.edu.uce.Dominio.SolicitudCurso;
import java.util.List;
public interface SolicitudDao {
    void agregar(SolicitudCurso solicitud);
    void editar(SolicitudCurso solicitud);
    void eliminar(int codigo);
    SolicitudCurso buscarPorCodigo(int codigo);
    List<SolicitudCurso> consultarSolicitudes();
}
