package ec.edu.uce.datos;
import ec.edu.uce.Dominio.ObjetivoFinanciero;
import java.util.List;
public interface ObjetivoDao {
    void agregar(ObjetivoFinanciero objetivo);
    void editar(ObjetivoFinanciero objetivo);
    void eliminar(int codigo);
    ObjetivoFinanciero buscarPorCodigo(int codigo);
    List<ObjetivoFinanciero> consultarObjetivos();
}

