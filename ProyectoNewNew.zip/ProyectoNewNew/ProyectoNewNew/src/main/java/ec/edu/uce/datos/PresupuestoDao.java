package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Presupuesto;
import java.util.List;
public interface PresupuestoDao {
    void agregar(Presupuesto presupuesto);
    void editar(Presupuesto presupuesto);
    void eliminar(int codigo);
    Presupuesto buscarPorCodigo(int codigo);
    List<Presupuesto> consultarTodos();
}
