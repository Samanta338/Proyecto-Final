package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Categoria;
import java.util.ArrayList;
import java.util.List;
public class CategoriaDaoMemoriaImp {
    // Lista estática que actúa como base de datos en memoria
    private static List<Categoria> categorias = new ArrayList<>();
    /**
     * Agrega una nueva categoría a la lista.
     * @param categoria La categoría que se desea agregar.
     */
    public void agregar(Categoria categoria) {
        categorias.add(categoria);
    }
    /**
     * Edita una categoría existente buscando por su ID.
     * Si encuentra una categoría con el mismo ID, la reemplaza.
     * @param categoria La categoría con datos actualizados.
     */
    public void editar(Categoria categoria) {
        //devuelve cuántos elementos hay en la lista.
        for (int i = 0; i < categorias.size(); i++) {
            //obtiene el elemento de la lista que está en la posición i.
            if (categorias.get(i).getId() == categoria.getId()) {
                //reemplaza el elemento en la posición i con el nuevo objeto categoria.
                categorias.set(i, categoria);
                return;
            }
        }
        System.out.println("Error: No se encontró la categoría con ID " + categoria.getId());
    }
    public void eliminar(int id) {
        for (int i = 0; i < categorias.size(); i++) {
            Categoria c = categorias.get(i);
            if (c != null && c.getId() == id) {
                categorias.remove(i);
                i--;
            }
        }
    }
    public Categoria buscarPorId(int id) {
        for (Categoria c : categorias) {
            if (c != null && c.getId() == id) {
                return c;
            }
        }
        return null;
    }
    public Categoria[] consultarCategorias() {
        return categorias.toArray(new Categoria[0]);
    }
}
