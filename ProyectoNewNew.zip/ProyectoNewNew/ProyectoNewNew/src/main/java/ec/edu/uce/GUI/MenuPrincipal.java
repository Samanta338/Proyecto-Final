package ec.edu.uce.GUI;
import java.util.Scanner;
import ec.edu.uce.Dominio.Usuario;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import ec.edu.uce.Dominio.Empresa;
import org.jetbrains.annotations.Nullable;
public class MenuPrincipal {
    private Scanner entrada = new Scanner(System.in);
    private Empresa empresa = Empresa.getInstance();


    public void mostrarMenuPrincipal() throws ExcepcionMifo {

        while (true) {
            System.out.println();
            System.out.println("  ---------------------------------------  ");
            System.out.println(" |             MENÚ PRINCIPAL             |");
            System.out.println("  --------------------------------------- |");
            System.out.println(" |  1. Crear Cuenta                       |");
            System.out.println(" |  2. Ingresar al Sistema                |");
            System.out.println(" |  3. Salir                              |");
            System.out.println("  ---------------------------------------");
            System.out.println();
            System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
            System.out.print("");
            int seleccion = ComprobacionMenu.validarOpcionMenu(entrada,4);
            switch (seleccion) {
                case 1:
                    System.out.println();
                    System.out.println("  ---------------------------------------  ");
                    System.out.println(" |             Crear Cuenta              |");
                    System.out.println("  ---------------------------------------  ");
                    crearCuenta();
                    break;

                case 2:
                    System.out.println();
                    System.out.println("  ---------------------------------------  ");
                    System.out.println(" |          Ingresar al sistema          |");
                    System.out.println("  ---------------------------------------  ");
                    ingresarAlSistema();
                    break;

                case 3:System.out.println();
                    System.out.println("                                     Cerrando el sistema.");
                    System.out.println("------------------------------------------------------------------------------------------------");
                    System.out.println(" Gracias por haber confiado en Mifo. Esperamos que nuestra plataforma te haya sido de gran ayuda.");
                    System.exit(0);

            }
        }
    }
    private void ingresarAlSistema() throws ExcepcionMifo {
        System.out.println();
        System.out.print(" | Nombre de usuario: ");
        String nombre = entrada.nextLine().trim();
        System.out.print(" | Contraseña: ");
        String contrasena = entrada.nextLine().trim();
        System.out.println("  ---------------------------------------  ");
        System.out.println();
        try {
            Usuario usuarioEncontrado = buscarUsuario(nombre, contrasena);
            if (usuarioEncontrado != null) {
                System.out.println();
                System.out.println(" Ingreso exitoso. Bienvenido, " + nombre + "!");
                new MenuMifo(usuarioEncontrado);
            } else {
                System.out.println();
                System.out.println(" Usuario encontrado, pero contraseña incorrecta. Inténtelo de nuevo.");
            }
        } catch (ExcepcionMifo.UsuarioNoEncontradoExcepcion e) {
            System.out.println();
            System.out.println(" Usuario incorrecto o no encontrado. Inténtelo de nuevo.");
        }
    }
    @Nullable
    private Usuario buscarUsuario(String nombre, String contrasena) throws ExcepcionMifo {
        for (Usuario u : empresa.getUsuarios()) {
            if (u != null && u.getNombre().equals(nombre)) {
                if (u.getContrasena().equals(contrasena)) {
                    return u;
                } else {
                    return null;
                }
            }
        }
        throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("Usuario '" + nombre + "' no encontrado.");
    }
    private void crearCuenta() {
        String nombre;
        String contrasena;
        String correo;
        String cedula;

        // Validación del nombre
        while (true) {
            System.out.println();
            System.out.print(" | Ingrese un nombre: ");
            nombre = entrada.nextLine().trim();
            if (ComprobacionMenu.validarNombreUsuario(nombre)) {
                break;
            }
        }

        // Validación de la contraseña
        while (true) {
            System.out.println();
            System.out.print(" | Ingrese una contraseña: ");
            contrasena = entrada.nextLine().trim();
            if (!ComprobacionMenu.validarContrasena(contrasena)) {
                System.out.println();
                System.out.println(" La contraseña no es válida. Asegúrate de incluir los elementos necesarios.");
                System.out.println(" Debe contener al menos una letra.");
                System.out.println(" Debe contener al menos un dígito.");
                System.out.println(" Debe tener una longitud mínima de 8 caracteres.");
            } else {
                break;
            }
        }

        // Validación del correo
        while (true) {
            System.out.println();
            System.out.print(" | Ingrese un correo electrónico: ");
            correo = entrada.nextLine().trim();
            if (!ComprobacionMenu.validarCorreo(correo)) {
                System.out.println();
                System.out.println(" Correo electrónico inválido. Intente con uno válido.");
            } else {
                break;
            }
        }

        // Validación de la cédula
        while (true) {
            System.out.println();
            System.out.print(" | Ingrese su número de cédula: ");
            cedula = entrada.nextLine().trim();
            if (!ComprobacionMenu.validarCedula(cedula)) {
                System.out.println();
                System.out.println(" Cédula inválida. Intente nuevamente.");
            } else {
                break;
            }
        }

        // Verificación de nombre duplicado
        System.out.println();
        for (Usuario u : empresa.getUsuarios()) {
            if (u != null && u.getNombre().equals(nombre)) {
                System.out.println();
                System.out.println(" Nombre en uso. Intente con uno diferente.");
                return;
            }
        }

        // Registro del usuario con todos los datos
        try {
            String resultadoCreacion = empresa.agregarUsuarioConCodigo(nombre, contrasena, correo, cedula);
            System.out.println(resultadoCreacion);
            System.out.println();
            System.out.println("        Su cuenta ha sido registrada exitosamente. Ya puede ingresar al sistema");
            System.out.println();
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al crear usuario: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws ExcepcionMifo {
        new MenuPrincipal().mostrarMenuPrincipal();

    }
}