package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.Empresa;

public class MenuInicializacion {

    public static void main(String[] args) {
        Empresa empresa = Empresa.getInstance();

        empresa.inicializarSistema();
        empresa.asegurarPresupuestoInicializado();


        // Inicializar usuarios
        System.out.println("========== INICIALIZACIÓN DE USUARIOS ==========");
        System.out.println(empresa.inicializarUsuarios());
        System.out.println();
        // Inicializar categorías
        System.out.println("========== INICIALIZACIÓN DE CATEGORÍAS ==========");
        System.out.println(empresa.inicializarCategorias());
        System.out.println();
        // Inicializar cursos de educación financiera
        System.out.println("========== INICIALIZACIÓN DE EDUCACIÓN FINANCIERA ==========");
        System.out.println(empresa.inicializarEducacionesFinancieras());
        System.out.println();




    }
}

