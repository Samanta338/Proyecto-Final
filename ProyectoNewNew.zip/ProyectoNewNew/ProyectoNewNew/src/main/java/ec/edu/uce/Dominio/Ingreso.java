package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ExcepcionMifo;
import java.util.Date;
public class Ingreso extends Movimiento {
    private final TipoMovimiento tipoMovimiento = TipoMovimiento.INGRESO;
    // 1.- Constructor por defecto
    public Ingreso() {
        super("Sin descripción", 0.0, new Date(), new Categoria("Otro"));
    }
    // 2.- Constructor con todos los parámetros excepto tipoMovimiento (es propio)
    public Ingreso(String descripcion, double monto, Date fecha, Categoria categoria) {
        super(descripcion, monto, fecha, categoria);
    }
    // 3.- Constructor con descripción, monto y categoría (fecha actual)
    public Ingreso(String descripcion, double monto, Categoria categoria) {
        super(descripcion, monto, new Date(), categoria);
    }
    // 4.- Constructor con descripción y categoría (monto 0.0, fecha actual)
    public Ingreso(String descripcion, Categoria categoria) {
        super(descripcion, 0.0, new Date(), categoria);
    }
    // 5.- Constructor con descripción, monto y fecha (categoría "Otro")
    public Ingreso(String descripcion, double monto, Date fecha) {
        this(descripcion, monto, fecha, new Categoria("Otro"));
    }
    // 6.- Constructor con descripción y monto (fecha actual y categoría "Otro")
    public Ingreso(String descripcion, double monto) {
        this(descripcion, monto, new Date(), new Categoria("Otro"));
    }
    // 7.- Constructor con solo descripción (monto 0.0, fecha actual, categoría "Otro")
    public Ingreso(String descripcion) {
        this(descripcion, 0.0, new Date(), new Categoria("Otro"));
    }
    public TipoMovimiento getTipoMovimiento() {
        return tipoMovimiento;
    }
    /* Sobreescritura del método registrar para representar el objeto como texto */
    @Override
    public boolean registrar() {
        if (this.monto <= 0.0) {
            return false;
        } else {
            System.out.println("Ingreso registrado: "
                    + "\nDescripción: " + descripcion
                    + "\nMonto: " + monto
                    + "\nFecha: " + fecha
                    + "\nCategoría: " + categoria.getNombreCategoria()
                    + "\nTipo de Movimiento: " + tipoMovimiento.getDescripcion()
                    + "\nCódigo: " + tipoMovimiento.getCodigo()
                    + "\nPrioridad: " + tipoMovimiento.getPrioridad()
                    + "\nLímite mensual sugerido: " + tipoMovimiento.getLimiteMensualSugerido());
            return true;
        }
    }

    /* AÑADIDO PARA VALIDAR LOS DUPLICADOS******
    public boolean validarDuplicado(Movimiento movimiento) {
        boolean result = false;
        if (movimiento != null && movimiento instanceof Ingreso) {
            Ingreso otroIngreso = (Ingreso) movimiento;
            if (this.getDescripcion().equals(otroIngreso.getDescripcion())
                    && this.getMonto() == otroIngreso.getMonto()
                    && this.getFecha().equals(otroIngreso.getFecha())) {
                result = true;
            }
        }
        return result;
    }*/
    @Override
    public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (this.monto <= 0.0) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El monto del ingreso debe ser mayor que cero.");
        }

        if (this.monto > tipoMovimiento.getLimiteMensualSugerido()) {
            System.out.println("Advertencia: El monto excede el límite mensual sugerido para este tipo de movimiento.");
        }

        System.out.println("Realizando ingreso: "
                + "\nDescripción: " + descripcion
                + "\nMonto: " + monto
                + "\nFecha: " + fecha
                + "\nCategoría: " + categoria.getNombreCategoria()
                + "\nTipo de Movimiento: " + tipoMovimiento.getDescripcion()
                + "\nCódigo: " + tipoMovimiento.getCodigo()
                + "\nPrioridad: " + tipoMovimiento.getPrioridad());
    }

    @Override
    public String toString() {
        return String.format("Ingreso:\n%s\n" +
                        "\tCódigo:                  %s\n" +
                        "\tTipo de Movimiento:      %s\n" +
                        "\tPrioridad:               %s\n" +
                        "\tLímite mensual sugerido: %.2f",
                super.toString(),
                tipoMovimiento.getCodigo(),
                tipoMovimiento.getDescripcion(),
                tipoMovimiento.getPrioridad(),
                tipoMovimiento.getLimiteMensualSugerido());
    }

}
