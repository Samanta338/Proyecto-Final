package ec.edu.uce.Dominio;
import java.util.Comparator;
public class OrdenarMovimientoPorMontoDescendente implements Comparator<Movimiento> {
    @Override
    public int compare(Movimiento m1, Movimiento m2) {
        if (m1.getMonto() > m2.getMonto()) {
            return -1;
        } else if (m1.getMonto() < m2.getMonto()) {
            return 1;
        } else {
            return 0;
        }
    }
}


