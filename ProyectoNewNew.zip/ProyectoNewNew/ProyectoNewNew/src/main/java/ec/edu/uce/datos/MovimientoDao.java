package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Movimiento;
import java.util.List;
public interface MovimientoDao {
    void agregar(Movimiento movimiento);
    void editar(Movimiento movimiento);
    void eliminar(int codigo);
    Movimiento buscarPorCodigo(int codigo);
    List<Movimiento> consultarMovimientos();
}
