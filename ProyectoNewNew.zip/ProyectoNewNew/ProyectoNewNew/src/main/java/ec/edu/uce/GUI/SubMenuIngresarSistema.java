/**
 * Clase que representa el submenú de ingreso al sistema en MIFO.
 * Permite al usuario gestionar sus credenciales, incluyendo edición, eliminación y consulta.
 */
package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.Empresa;
import ec.edu.uce.Dominio.OrdenarUsuarioPorCodigo;
import ec.edu.uce.Dominio.Usuario;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class SubMenuIngresarSistema {
    /**
     * Scanner para leer la entrada del usuario desde la consola.
     */
    private Scanner entrada = new Scanner(System.in);
    private Empresa empresa = Empresa.getInstance();
    /**
     * Usuario actualmente autenticado en el sistema.
     */
    private Usuario usuario;


    /**
     * Constructor que inicializa el usuario actual y la lista de usuarios registrados.
     *
     * @param usuario  Usuario autenticado actualmente
     * @param usuario Arreglo de usuarios registrados
     */
    public SubMenuIngresarSistema(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * Muestra el submenú de ingreso al sistema y procesa la opción elegida por el usuario.
     */
    public void menuIngresarSistema() {
        mostrarMenuIngresarSistema();
        int seleccion = ComprobacionMenu.validarOpcionMenu(entrada, 6);
        procesarOpcionIngresarSistema(seleccion);
    }
    /**
     * Muestra las opciones disponibles dentro del submenú de ingreso al sistema.
     */
    private void mostrarMenuIngresarSistema() {
        System.out.println();
        System.out.println("  ---------------------------------------  ");
        System.out.println(" |            Ingresar al sistema         |");
        System.out.println("  --------------------------------------- |");
        System.out.println(" |  1. Editar credenciales                |");
        System.out.println(" |  2. Eliminar credenciales              |");
        System.out.println(" |  3. Consultar credenciales             |");
        System.out.println(" |  4. Ordenar usuarios                   |");
        System.out.println(" |  5. Volver al menú principal           |");
        System.out.println(" |  6. Salir del programa                 |");
        System.out.println("  ---------------------------------------");
        System.out.println();
        System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
    }

    /**
     * Procesa la opción elegida en el menú e invoca la funcionalidad correspondiente.
     *
     * @param seleccion Opción elegida por el usuario.
     */
    private void procesarOpcionIngresarSistema(int seleccion) {
        switch (seleccion) {
            case 1:
                try {
                    if (validarCredenciales()) {
                        editarCredenciales();
                    } else {
                        System.out.println("Contraseña incorrecta. No se pueden editar las credenciales.");
                    }
                } catch (ExcepcionMifo.CredencialesInvalidasExcepcion e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 2:
                try {
                    if (validarCredenciales()) {
                        eliminarCredenciales();
                        System.exit(0);
                    } else {
                        System.out.println("Contraseña incorrecta. No se pueden eliminar las credenciales.");
                    }
                } catch (ExcepcionMifo.CredencialesInvalidasExcepcion e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 3:
                try {
                    if (validarCredenciales()) {
                        consultarCredenciales();
                    } else {
                        System.out.println("Contraseña incorrecta. No se pueden consultar las credenciales.");
                    }
                } catch (ExcepcionMifo.CredencialesInvalidasExcepcion e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 4:
                ordenarUsuarios();
            case 5:
                System.out.println();
                System.out.println("Volviendo al menú principal...");
                return;

            case 6:
                System.out.println();
                System.out.println("                                     Cerrando el sistema.");
                System.out.println("------------------------------------------------------------------------------------------------");
                System.out.println("Gracias por haber confiado en Mifo. Esperamos que nuestra plataforma te haya sido de gran ayuda.");
                System.exit(0);
                break;
        }
    }

    /**
     * Valida las credenciales del usuario solicitando su contraseña actual.
     *
     * @return true si la contraseña es válida, false en caso contrario.
     * @throws ExcepcionMifo.CredencialesInvalidasExcepcion Si la contraseña ingresada es incorrecta.
     */
    private boolean validarCredenciales() throws ExcepcionMifo.CredencialesInvalidasExcepcion {
        System.out.print(" | Ingrese su contraseña actual: ");
        String contrasena = entrada.nextLine();
        if (usuario.getContrasena().equals(contrasena)) {
            return true;
        } else {
            throw new ExcepcionMifo.CredencialesInvalidasExcepcion("Contraseña incorrecta. No se pueden validar las credenciales.");
        }
    }

    /**
     * Permite al usuario editar su nombre y contraseña verificando su validez.
     */
    private void editarCredenciales() {
        String nuevoNombre;
        String nuevaContrasena;

        // Validación del nombre de usuario
        do {
            System.out.print(" | Ingrese nuevo nombre (solo letras): ");
            nuevoNombre = entrada.nextLine();
            if (!nuevoNombre.matches("[a-zA-Z]+")) {
                System.out.println("Error: El nombre debe contener solo letras.");
            }
        } while (!nuevoNombre.matches("[a-zA-Z]+"));

        // Validación de la nueva contraseña
        do {
            System.out.print(" | Ingrese nueva contraseña (mínimo 8 caracteres con al menos una letra): ");
            nuevaContrasena = entrada.nextLine();
            if (nuevaContrasena.length() < 8 || !nuevaContrasena.matches(".*[a-zA-Z].*")) {
                System.out.println(" La contraseña debe tener al menos 8 caracteres con al menos una letra.");
            }
        } while (nuevaContrasena.length() < 8 || !nuevaContrasena.matches(".*[a-zA-Z].*"));

        usuario.setNombre(nuevoNombre);
        usuario.setContrasena(nuevaContrasena);
        System.out.println("Credenciales editadas correctamente.");
    }

    /**
     * Elimina las credenciales del usuario borrando su nombre y contraseña.
     */
    private void eliminarCredenciales() {
        usuario.setNombre("");
        usuario.setContrasena("");
        System.out.println("Credenciales eliminadas correctamente.");
        System.out.println("Para volver a utilizar Mifo, deberá crear una nueva cuenta.");
    }

    /**
     * Consulta y muestra en pantalla las credenciales del usuario actual.
     */
    private void consultarCredenciales() {
        List<Usuario> listaUsuarios = empresa.getUsuarios();

        if (listaUsuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }

        System.out.println("Usuarios registrados:");
        for (Usuario u : listaUsuarios) {
            if (u != null) {
                System.out.printf(" | Código: %d | Nombre: %s | Correo: %s%n",
                        u.getCodigo(), u.getNombre(), u.getCorreo());
            }
        }
    }

    private void ordenarUsuarios() {
        List<Usuario> lista = Empresa.getInstance().getUsuarios();
        if (lista.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }

        boolean regresar = false;

        while (!regresar) {
            System.out.println();
            System.out.println("  --------------------------------------------  ");
            System.out.println(" |         Ordenar Usuarios Registrados        |");
            System.out.println("  --------------------------------------------  ");
            System.out.println(" |  1. Por nombre (Comparable)                 |");
            System.out.println(" |  2. Por código ASCENDENTE (Comparator)      |");
            System.out.println(" |  3. Volver                                  |");
            System.out.println("  --------------------------------------------  ");
            System.out.print("Seleccione una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                    ordenarUsuariosPorNombreAscendente();
                    break;
                case "2":
                    ordenarUsuariosPorCodigoAscendente();
                    break;
                case "3":
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
    }

    public void ordenarUsuariosPorNombreAscendente() {
        List<Usuario> lista = Empresa.getInstance().getUsuarios();
        Collections.sort(lista); // Usa compareTo() en Usuario
        System.out.println("Usuarios ordenados por nombre ASCENDENTE:");
        mostrarUsuarios(lista);
    }
    public void ordenarUsuariosPorCodigoAscendente() {
        List<Usuario> lista = Empresa.getInstance().getUsuarios();
        Collections.sort(lista, new OrdenarUsuarioPorCodigo());
        System.out.println("Usuarios ordenados por código ASCENDENTE:");
        mostrarUsuarios(lista);
    }

    private void mostrarUsuarios(List<Usuario> usuarios) {
        if (usuarios == null || usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }

        StringBuilder sb = new StringBuilder();

        sb.append("  ---------------------------------------------------------------------------------------------\n");
        sb.append(String.format(" | %-5s | %-28s | %-28s | %-12s |\n", "ID", "Nombre", "Correo electrónico", "Cédula"));
        sb.append("  ---------------------------------------------------------------------------------------------\n");

        for (Usuario u : usuarios) {
            sb.append(String.format(" | %-5d | %-28s | %-28s | %-12s |\n",
                    u.getCodigo(),
                    u.getNombre(),
                    u.getCorreo(),
                    u.getCedula()));
        }

        sb.append("  ---------------------------------------------------------------------------------------------");
        System.out.println(sb.toString());
    }

}