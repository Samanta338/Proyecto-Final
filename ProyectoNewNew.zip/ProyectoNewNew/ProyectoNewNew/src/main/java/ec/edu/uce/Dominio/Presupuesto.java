package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ExcepcionMifo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;


/**
 * Clase que representa un presupuesto que contiene movimientos financieros
 * (ingresos y gastos) con sus respectivas categorías.
 */
public class Presupuesto implements IAdministrarCRUD, Comparable <Presupuesto>{
    private double montoPresupuesto;
    private Date fecha;
    private double gastoTotal;
    private double ingresoTotal;
    private Usuario usuario;
    private List<Movimiento> movimientos = new ArrayList<>();
    //private int numMovimientos = 0;
    private TipoPresupuesto tipo;
    private List<ObjetivoFinanciero> objetivos = new ArrayList<>();
    //private int numObjetivos;
    private static int contadorCodigo = 0;
    private final int codigo;

    // Bloque de inicialización de instancia
    {
        this.codigo = ++contadorCodigo;
    }
    /**
     * 1.- Constructor que inicializa un presupuesto con un monto y una fecha.
     * Los valores de gasto total, ingreso total, número de movimientos y tipo se inicializan por defecto.
     *
     * @param presupuesto Monto total del presupuesto.
     * @param fecha Fecha del presupuesto.
     */
    public Presupuesto(double presupuesto, Date fecha) {
        this.montoPresupuesto = presupuesto;
        this.fecha = fecha;
        inicializarObjetivos();

    }



    /**
     * 2.- Constructor que inicializa un presupuesto con monto, fecha y usuario asociado.
     * Los valores de gasto total, ingreso total, número de movimientos y tipo se inicializan por defecto.
     *
     * @param presupuesto Monto total del presupuesto.
     * @param fecha Fecha del presupuesto.
     * @param usuario Usuario propietario del presupuesto.
     */
    public Presupuesto(double presupuesto, Date fecha, Usuario usuario) {
        this.montoPresupuesto= presupuesto;
        this.fecha = fecha;
        this.usuario = usuario;
        inicializarObjetivos();
        inicializarMovimientos();
    }


    /**
     * 3.- Constructor principal que inicializa todos los atributos del presupuesto.
     *
     * @param presupuesto Monto total del presupuesto.
     * @param fecha Fecha del presupuesto.
     * @param gastoTotal Suma total de gastos registrados.
     * @param ingresoTotal Suma total de ingresos registrados..
     * @param tipo Tipo de presupuesto (puede ser nulo).
     */

    public Presupuesto(double presupuesto, Date fecha, double gastoTotal, double ingresoTotal, TipoPresupuesto tipo) {
        this.montoPresupuesto = presupuesto;
        this.fecha = fecha;
        this.gastoTotal = gastoTotal;
        this.ingresoTotal = ingresoTotal;
        this.tipo = tipo;
        inicializarObjetivos();
        inicializarMovimientos();
    }
    // 4. Constructor con presupuesto, fecha y tipo
    public Presupuesto(double presupuesto, Date fecha, TipoPresupuesto tipo) {
        this.fecha=fecha;
        this.montoPresupuesto = presupuesto;
        this.tipo = tipo;
        inicializarObjetivos();
        inicializarMovimientos();
    }

    // 5. Constructor con presupuesto, fecha, usuario y tipo
    public Presupuesto(double presupuesto, Date fecha, Usuario usuario, TipoPresupuesto tipo) {
        this(presupuesto, fecha, 0.0, 0.0, tipo);
        this.usuario = usuario;
        inicializarObjetivos();
        inicializarMovimientos();
    }

    // 6. Constructor con presupuesto, fecha, gastoTotal e ingresoTotal
    public Presupuesto(double presupuesto, Date fecha, double gastoTotal, double ingresoTotal) {
        this(presupuesto, fecha, gastoTotal, ingresoTotal, null);
        inicializarObjetivos();
        inicializarMovimientos();
    }


    // Getters y setters

    public double getMontoPresupuesto() {
        return this.montoPresupuesto;
    }

    public void setPresupuesto(double montoPresupuesto) {
        this.montoPresupuesto = montoPresupuesto;
    }

    public Date getFecha() {
        return this.fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getGastoTotal() {
        return this.gastoTotal;
    }

    public void setGastoTotal(double gastoTotal) {
        this.gastoTotal = gastoTotal;
    }

    public double getIngresoTotal() {
        return this.ingresoTotal;
    }

    public void setIngresoTotal(double ingresoTotal) {
        this.ingresoTotal = ingresoTotal;
    }

    public class ComprobacionFormato {
        public static final SimpleDateFormat FORMATO_FECHA_CORTA = new SimpleDateFormat("dd-MM-yyyy");
    }

    public void setMovimientos(List<Movimiento> movimientos) {
        this.movimientos = (movimientos != null) ? movimientos : new ArrayList<>();
    }
    public List<Movimiento> getMovimientos() {
        return Collections.unmodifiableList(movimientos);
    }

    public void setObjetivos(List<ObjetivoFinanciero> objetivos) {
        this.objetivos = (objetivos != null) ? objetivos : new ArrayList<>();
    }
    public List<ObjetivoFinanciero> getObjetivosFinancieros() {
        return objetivos;
    }


    public TipoPresupuesto getTipo() {
        return this.tipo;
    }


    public void setTipo(TipoPresupuesto tipo) {
        this.tipo = tipo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    public int getCodigo() {
        return codigo;
    }


    /**
     * Crea y agrega un movimiento al presupuesto
     */

    /*public String agregarMovimiento(Movimiento nuevoMovimiento) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (nuevoMovimiento == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Movimiento no puede ser nulo.");
        }

        if (validarDuplicado(nuevoMovimiento)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Movimiento duplicado.");
        }

        movimientos.add(nuevoMovimiento);

        // Actualizar presupuesto según tipo
        if (nuevoMovimiento instanceof Ingreso) {
            this.montoPresupuesto += nuevoMovimiento.getMonto();
            this.ingresoTotal += nuevoMovimiento.getMonto();
        } else if (nuevoMovimiento instanceof Gasto) {
            this.montoPresupuesto -= nuevoMovimiento.getMonto();
            this.gastoTotal += nuevoMovimiento.getMonto();
        }

        return "Descripción: " + nuevoMovimiento.getDescripcion() +
                "\nMonto: " + nuevoMovimiento.getMonto() +
                "\nFecha: " + nuevoMovimiento.getFecha() +
                "\nCategoría: " + (nuevoMovimiento.getCategoria() != null
                ? nuevoMovimiento.getCategoria().getNombreCategoria()
                : "Sin categoría");
    }*/
    public String agregarMovimiento(Movimiento nuevoMovimiento) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (nuevoMovimiento == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Movimiento no puede ser nulo.");
        }

        if (validarDuplicado(nuevoMovimiento)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Movimiento duplicado.");
        }

        nuevoMovimiento.setPresupuesto(this); //  Vínculo bidireccional

        movimientos.add(nuevoMovimiento);

        // Actualizar presupuesto según tipo
        if (nuevoMovimiento instanceof Ingreso) {
            this.montoPresupuesto += nuevoMovimiento.getMonto();
            this.ingresoTotal += nuevoMovimiento.getMonto();
        } else if (nuevoMovimiento instanceof Gasto) {
            this.montoPresupuesto -= nuevoMovimiento.getMonto();
            this.gastoTotal += nuevoMovimiento.getMonto();
        }

        return "\nMovimiento Registrado\n"
                + "╔════════════════════════════════════════╗\n"
                + "║ Descripción : " + nuevoMovimiento.getDescripcion() + "\n"
                + "║ Monto       : $" + String.format("%.2f", nuevoMovimiento.getMonto()) + "\n"
                + "║ Fecha       : " + ComprobacionFormato.FORMATO_FECHA_CORTA.format(nuevoMovimiento.getFecha()) + "\n"
                + "║ Categoría   : " + (nuevoMovimiento.getCategoria() != null
                ? nuevoMovimiento.getCategoria().getNombreCategoria()
                : "Sin categoría") + "\n"
                + "║ Tipo        : " + (nuevoMovimiento instanceof Ingreso ? "Ingreso" : "Gasto") + "\n"
                + "╚════════════════════════════════════════╝";

    }


    /**
     * Agrega un movimiento al presupuesto a partir de datos separados.
     *
     * @param descripcion Descripción del movimiento.
     * @param monto Monto del movimiento.
     * @param fecha Fecha del movimiento.
     * @param categoria Categoría del movimiento.
     * @param esIngreso Indica si es ingreso (true) o gasto (false).
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si el movimiento es duplicado.
     */
    public String agregarMovimiento(String descripcion, double monto, Date fecha, Categoria categoria, boolean esIngreso) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Movimiento nuevoMovimiento;
        if (esIngreso) {
            nuevoMovimiento = new Ingreso(descripcion, monto, fecha, categoria);
        } else {
            nuevoMovimiento = new Gasto(descripcion, monto, fecha, categoria);
        }
        return agregarMovimiento(nuevoMovimiento);
    }

    /**
     *
     * CRUD: Editar movimiento
     * @param indice           índice del movimiento a editar
     * @param nuevaDescripcion nueva descripción
     * @param nuevoMonto       nuevo monto
     * @param nuevaFecha       nueva fecha
     * @param esIngreso        true si es ingreso, false si gasto
     * @param categoria        nueva categoría
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si índice inválido
     */
    public void editarMovimiento(int indice, String nuevaDescripcion, double nuevoMonto, Date nuevaFecha, boolean esIngreso, Categoria categoria) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= movimientos.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice de movimiento inválido.");
        }

        Movimiento movimientoOriginal = movimientos.get(indice);
        double montoAnterior = movimientoOriginal.getMonto();

        // Actualizar valores comunes
        movimientoOriginal.setDescripcion(nuevaDescripcion);
        movimientoOriginal.setMonto(nuevoMonto);
        movimientoOriginal.setFecha(nuevaFecha);

        if (movimientoOriginal instanceof Ingreso ingreso) {
            ingreso.setCategoria(categoria);
        } else if (movimientoOriginal instanceof Gasto gasto) {
            gasto.setCategoria(categoria);
        }

        // Ajuste a totales y presupuesto
        if (movimientoOriginal instanceof Ingreso && !esIngreso) {
            // Cambio de tipo: de Ingreso → Gasto (pero sin cambiar la instancia)
            montoPresupuesto = montoPresupuesto - montoAnterior - nuevoMonto;
            ingresoTotal -= montoAnterior;
            gastoTotal += nuevoMonto;
        } else if (movimientoOriginal instanceof Gasto && esIngreso) {
            // Cambio de tipo: de Gasto → Ingreso
            montoPresupuesto = montoPresupuesto + montoAnterior + nuevoMonto;
            gastoTotal -= montoAnterior;
            ingresoTotal += nuevoMonto;
        } else if (movimientoOriginal instanceof Ingreso) {
            // Sigue siendo Ingreso
            montoPresupuesto = montoPresupuesto - montoAnterior + nuevoMonto;
            ingresoTotal += nuevoMonto - montoAnterior;
        } else if (movimientoOriginal instanceof Gasto) {
            // Sigue siendo Gasto
            montoPresupuesto = montoPresupuesto + montoAnterior - nuevoMonto;
            gastoTotal += nuevoMonto - montoAnterior;
        }
    }

    /**
     * Edita un movimiento existente en la posición indicada.
     *
     * @param indice Índice del movimiento a editar.
     * @param nuevoMovimiento Nuevo objeto Movimiento con los datos actualizados.
     */
    public void editarMovimiento(int indice, Movimiento nuevoMovimiento) {
        if (nuevoMovimiento == null) {
            System.out.println("Movimiento nulo. No se puede editar.");
            return;
        }
        if (indice >= 0 && indice < movimientos.size()) {
            movimientos.set(indice, nuevoMovimiento);
            System.out.println("Movimiento editado exitosamente.");
        } else {
            System.out.println("Índice inválido para editar el movimiento.");
        }
    }


    /**
     * Elimina un movimiento por índice.
     * Usa System.arraycopy para corrimiento.
     *
     * @param indice índice del movimiento a eliminar
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si índice inválido
     */
    public void eliminarMovimiento(int indice) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= movimientos.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice de movimiento inválido.");
        }

        Movimiento movimiento = movimientos.get(indice);

        if (movimiento instanceof Ingreso) {
            montoPresupuesto -= movimiento.getMonto();
            ingresoTotal -= movimiento.getMonto();
        } else if (movimiento instanceof Gasto) {
            montoPresupuesto += movimiento.getMonto();
            gastoTotal -= movimiento.getMonto();
        }

        movimientos.remove(indice);
    }

    /**
     *
     * CRUD: Eliminar movimiento
     */

    /**
     * Elimina un movimiento específico si existe en el arreglo.
     *
     * @param movimiento Movimiento a eliminar.
     */
    public void eliminarMovimiento(Movimiento movimiento) {
        if (movimiento == null) {
            System.out.println("No se puede eliminar un movimiento nulo.");
            return;
        }

        int indiceEliminar = -1;
        int i = 0;
        for (Movimiento mov : movimientos) {
            if (mov.equals(movimiento)) {
                indiceEliminar = i;
                break;
            }
            i++;
        }

        if (indiceEliminar == -1) {
            System.out.println("Movimiento no encontrado para eliminar.");
            return;
        }

        Movimiento movEliminar = movimientos.get(indiceEliminar);
        // Ajustar presupuesto y totales
        if (movEliminar instanceof Ingreso) {
            montoPresupuesto -= movEliminar.getMonto();
            ingresoTotal -= movEliminar.getMonto();
        } else if (movEliminar instanceof Gasto) {
            montoPresupuesto += movEliminar.getMonto();
            gastoTotal -= movEliminar.getMonto();
        }

        movimientos.remove(indiceEliminar);

        System.out.println("Movimiento eliminado exitosamente.");
    }

    /**
     * Consulta un movimiento por su índice y retorna su información en formato String.
     *
     * @param indice índice del movimiento a consultar
     * @return detalles del movimiento en texto
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el índice es inválido
     */
    public String consultarMovimiento(int indice) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= movimientos.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice de movimiento inválido.");
        }

        Movimiento mov = movimientos.get(indice);

        StringBuilder sb = new StringBuilder();
        sb.append("Descripción: ").append(mov.getDescripcion()).append("\n");
        sb.append("Monto: ").append(mov.getMonto()).append("\n");
        sb.append("Fecha: ").append(mov.getFecha()).append("\n");
        sb.append("Categoría: ").append(mov.getCategoria() != null
                ? mov.getCategoria().getNombreCategoria()
                : "Sin categoría").append("\n");
        sb.append("Tipo: ").append(mov instanceof Ingreso ? "Ingreso" : "Gasto");

        return sb.toString();
    }


    /**
     * Consulta todos los movimientos existentes.
     *
     * @return Cadena con la información de todos los movimientos
     */
    public String consultarMovimientos() {
        if (movimientos.isEmpty()) {
            return "No hay movimientos para este presupuesto.";
        }
        Movimiento mov = movimientos.get(0);
        return "Descripción: " + mov.getDescripcion() +
                "\nMonto: " + mov.getMonto() +
                "\nFecha: " + mov.getFecha() +
                "\nCategoría: " + (mov.getCategoria() != null ? mov.getCategoria().getNombreCategoria() : "Sin categoría") +
                "\nTipo: " + (mov instanceof Ingreso ? "Ingreso" : "Gasto");
    }

    /* Inicializa algunos movimientos de ejemplo en el sistema.
     *
     * @return Mensaje con el resultado de agregar cada movimiento.
     */
    /*public void inicializarMovimientos() {
        Empresa empresa = Empresa.getInstance();
        List<Categoria> categorias = empresa.getCategorias();

        if (categorias == null || categorias.size() < 8) {
            System.out.println(" No se pueden inicializar movimientos: faltan categorías.");
            return;
        }

        try {
            // INGRESOS
            this.agregarMovimiento("Salario mensual", 350.0, new Date(), categorias.get(0), true);
            this.agregarMovimiento("Pago por proyecto", 150.0, new Date(), categorias.get(1), true);
            this.agregarMovimiento("Ingreso por alquiler", 180.0, new Date(), categorias.get(2), true);

            // GASTOS
            this.agregarMovimiento("Pago de alquiler mensual", 280.0, new Date(), categorias.get(3), false);
            this.agregarMovimiento("Cena rápida", 25.0, new Date(), categorias.get(4), false);
            this.agregarMovimiento("Transporte diario", 30.0, new Date(), categorias.get(5), false);
            this.agregarMovimiento("Compra de libros", 60.0, new Date(), categorias.get(6), false);
            this.agregarMovimiento("Suscripción Netflix", 7.99, new Date(), categorias.get(7), false);

            System.out.println("Movimientos inicializados para el presupuesto #" + this.getCodigo());
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al agregar movimientos: " + e.getMessage());
        }
    }*/
    public void inicializarMovimientos() {
        Empresa empresa = Empresa.getInstance();

        if (empresa == null) {
           // System.out.println("Empresa aún no está disponible para inicializar movimientos.");
            return;
        }

        List<Categoria> categorias = empresa.getCategorias();

        if (categorias == null || categorias.size() < 8) {
           // System.out.println("No se pueden inicializar movimientos: faltan categorías.");
            return;
        }

        try {
            // INGRESOS
            this.agregarMovimiento("Salario mensual", 350.0, new Date(), categorias.get(0), true);
            this.agregarMovimiento("Pago por proyecto", 150.0, new Date(), categorias.get(1), true);
            this.agregarMovimiento("Ingreso por alquiler", 180.0, new Date(), categorias.get(2), true);

            // GASTOS
            this.agregarMovimiento("Pago de alquiler mensual", 280.0, new Date(), categorias.get(3), false);
            this.agregarMovimiento("Cena rápida", 25.0, new Date(), categorias.get(4), false);
            this.agregarMovimiento("Transporte diario", 30.0, new Date(), categorias.get(5), false);
            this.agregarMovimiento("Compra de libros", 60.0, new Date(), categorias.get(6), false);
            this.agregarMovimiento("Suscripción Netflix", 7.99, new Date(), categorias.get(7), false);

            System.out.println("Movimientos inicializados para el presupuesto #" + this.getCodigo());
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al agregar movimientos: " + e.getMessage());
        }
    }




    public Movimiento buscarMovimiento(int indice) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= movimientos.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice de movimiento inválido.");
        }
        return movimientos.get(indice);
    }

    /**
     * Valida si un movimiento ya existe en el arreglo de movimientos.
     * Se usa foreach para evitar for tradicional.
     *
     * @param movimiento Movimiento a validar
     * @return true si el movimiento ya existe, false si no
     */
    public boolean validarDuplicado(Movimiento movimiento) {
        return movimientos.contains(movimiento);
    }


    /**
     * Agrega un nuevo objetivo financiero al presupuesto.
     * @param objetivo Objetivo financiero a agregar.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(ObjetivoFinanciero objetivo) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        if (objetivo == null) {
            throw new ExcepcionMifo.ObjetivoDuplicadoExcepcion("El objetivo no puede ser nulo.");
        }

        if (validarDuplicado(objetivo)) {
            throw new ExcepcionMifo.ObjetivoDuplicadoExcepcion("El objetivo financiero ya existe.");
        }

        objetivos.add(objetivo);

        return "Objetivo agregado: " + objetivo.getDescripcion() +
                ", Monto: " + objetivo.getMonto();
    }

    /**
     * Agrega un objetivo financiero con descripción y monto, usando la fecha actual y categoría nula.
     *
     * @param descripcion Descripción del objetivo.
     * @param monto Monto del objetivo.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(String descripcion, double monto) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        ObjetivoFinanciero nuevoObjetivo = new ObjetivoFinanciero(descripcion, monto, new Date(), null);
        return agregarObjetivoFinanciero(nuevoObjetivo);
    }
    /**
     * Agrega un objetivo financiero con descripción, monto y categoría, usando la fecha actual.
     *
     * @param descripcion Descripción del objetivo.
     * @param monto Monto del objetivo.
     * @param categoria Categoría del objetivo.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(String descripcion, double monto, Categoria categoria) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        ObjetivoFinanciero nuevoObjetivo = new ObjetivoFinanciero(descripcion, monto, new Date(), categoria);
        return agregarObjetivoFinanciero(nuevoObjetivo);
    }


    /**
     * Crea y agrega un objetivo financiero a partir de parámetros simples.
     *
     * @param descripcion Descripción del objetivo.
     * @param monto Monto objetivo.
     * @param fecha Fecha objetivo (puedes sobrecargar para fecha opcional).
     * @param categoria Categoría del objetivo.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(String descripcion, double monto, Date fecha, Categoria categoria) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        ObjetivoFinanciero nuevoObjetivo = new ObjetivoFinanciero(descripcion, monto, fecha, categoria);
        return agregarObjetivoFinanciero(nuevoObjetivo);
    }

    /**
     * Edita un objetivo financiero existente.
     * @param indice Índice del objetivo a editar.
     * @param nuevo Nuevo objeto de objetivo financiero.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice es inválido.
     */
    public void editarObjetivoFinanciero(int indice, ObjetivoFinanciero nuevo) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (nuevo == null) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("El objetivo proporcionado no puede ser nulo.");
        }
        if (indice < 0 || indice >= objetivos.size()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("Índice inválido para editar objetivo.");
        }
        objetivos.set(indice, nuevo);
    }

    /**
     * Edita un objetivo financiero directamente con nuevos datos, asignando fecha actual.
     *
     * @param indice Índice del objetivo a editar.
     * @param descripcion Nueva descripción.
     * @param monto Nuevo monto.
     * @param categoria Nueva categoría.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice no es válido.
     */
    public void editarObjetivoFinanciero(int indice, String descripcion, double monto, Categoria categoria) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        ObjetivoFinanciero nuevo = new ObjetivoFinanciero(descripcion, monto, new Date(), categoria);
        editarObjetivoFinanciero(indice, nuevo);
    }
    /**
     * Edita un objetivo financiero buscándolo por su descripción.
     *
     * @param descripcion Descripción del objetivo a editar.
     * @param nuevo Nuevo objeto objetivo financiero.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si no se encuentra el objetivo.
     */
    public void editarObjetivoFinanciero(String descripcion, ObjetivoFinanciero nuevo) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("La descripción no puede estar vacía.");
        }

        for (int i = 0; i < objetivos.size(); i++) {
            ObjetivoFinanciero actual = objetivos.get(i);
            if (actual.getDescripcion().equalsIgnoreCase(descripcion)) {
                objetivos.set(i, nuevo);
                return;
            }
        }
        throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("No se encontró un objetivo con la descripción dada.");
    }

    /**
     * Edita un objetivo financiero buscado por descripción, actualizando monto y categoría.
     * Usa la fecha actual.
     *
     * @param descripcion Descripción del objetivo a editar.
     * @param nuevoMonto Nuevo monto.
     * @param nuevaCategoria Nueva categoría.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si no se encuentra el objetivo.
     */
    public void editarObjetivoFinanciero(String descripcion, double nuevoMonto, Categoria nuevaCategoria) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        ObjetivoFinanciero nuevo = new ObjetivoFinanciero(descripcion, nuevoMonto, new Date(), nuevaCategoria);
        editarObjetivoFinanciero(descripcion, nuevo);
    }


    /**
     * Elimina un objetivo financiero por índice.
     * @param indice Índice del objetivo a eliminar.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice no es válido.
     */
    public void eliminarObjetivoFinanciero(int indice) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (indice < 0 || indice >= objetivos.size()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("Índice inválido para eliminar objetivo.");
        }

        objetivos.remove(indice);
    }

    /**
     * Elimina un objetivo financiero buscándolo por su descripción.
     *
     * @param descripcion Descripción del objetivo a eliminar.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si no se encuentra el objetivo.
     */
    public void eliminarObjetivoFinanciero(String descripcion) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("La descripción no puede estar vacía.");
        }
        for (int i = 0; i < objetivos.size(); i++) {
            ObjetivoFinanciero objetivo = objetivos.get(i);
            if (objetivo.getDescripcion().equalsIgnoreCase(descripcion)) {
                objetivos.remove(i);
                return;
            }
        }

        throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("No se encontró un objetivo con la descripción dada.");
    }

    /**
     * Elimina un objetivo financiero por objeto.
     *
     * @param objetivo Objetivo financiero a eliminar.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el objetivo no se encuentra.
     */
    public void eliminarObjetivoFinanciero(ObjetivoFinanciero objetivo) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (objetivo == null) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("El objetivo a eliminar no puede ser nulo.");
        }
        int indice = objetivos.indexOf(objetivo);
        if (indice == -1) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("No se encontró el objetivo financiero para eliminar.");
        }
        objetivos.remove(indice);
    }

    /**
     * Consulta un objetivo por índice.
     * @param indice Índice del objetivo.
     * @return Cadena con la información del objetivo.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice no es válido.
     */
    public String consultarObjetivoFinanciero(int indice) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (indice < 0 || indice >= objetivos.size()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("Índice inválido para consultar objetivo.");
        }

        ObjetivoFinanciero obj = objetivos.get(indice);

        return "Descripción: " + obj.getDescripcion() +
                "\nMonto: " + obj.getMonto() +
                "\nFecha: " + obj.getFecha() +
                "\nCategoría: " + (obj.getCategoria() != null
                ? obj.getCategoria().getNombreCategoria()
                : "Sin categoría");
    }


    /**
     * Consulta todos los objetivos financieros del presupuesto.
     * @return Cadena con todos los objetivos.
     */
    public String consultarObjetivosFinancieros() {
        if (objetivos.isEmpty()) {
            return "No hay objetivos financieros registrados.";
        }

        StringBuilder sb = new StringBuilder();
        System.out.println("");
        sb.append("OBJETIVOS FINANCIEROS REGISTRADOS:\n");
        sb.append("------------------------------------------------------------\n");

        int cont = 1;
        for (ObjetivoFinanciero obj : objetivos) {
            sb.append("Objetivo #" + cont++ + "\n");
            sb.append("Descripción : " + obj.getDescripcion() + "\n");
            sb.append("Monto       : $" + String.format("%.2f", obj.getMonto()) + "\n");
            sb.append("Fecha       : " + ComprobacionFormato.FORMATO_FECHA_CORTA.format(obj.getFecha()) + "\n");
            sb.append("Categoría   : " + (obj.getCategoria() != null ? obj.getCategoria().getNombreCategoria() : "Sin categoría") + "\n");
            sb.append("------------------------------------------------------------\n");
        }

        return sb.toString();
    }



    /**
     * Consulta un objetivo financiero buscándolo por su descripción.
     *
     * @param descripcion Descripción del objetivo.
     * @return Texto con la información del objetivo o mensaje de no encontrado.
     */
    public String consultarObjetivoFinanciero(String descripcion) {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            return "La descripción no puede estar vacía.";
        }
        for (ObjetivoFinanciero obj : objetivos) {
            if (obj != null && obj.getDescripcion().equalsIgnoreCase(descripcion)) {
                return "Descripción: " + obj.getDescripcion() +
                        "\nMonto: " + obj.getMonto() +
                        "\nFecha: " + obj.getFecha() +
                        "\nCategoría: " + (obj.getCategoria() != null ? obj.getCategoria().getNombreCategoria() : "Sin categoría");
            }
        }
        return "No se encontró un objetivo con la descripción: " + descripcion;
    }
    public String inicializarObjetivos() {
        StringBuilder resultado = new StringBuilder();
        try {
            resultado.append(agregarObjetivoFinanciero("Ahorrar para viaje", 500.0, new Date(), new Categoria())).append("\n");
            resultado.append(agregarObjetivoFinanciero("Comprar laptop", 1000.0, new Date(), new Categoria())).append("\n");
            resultado.append(agregarObjetivoFinanciero("Pagar curso en línea", 300.0, new Date(), new Categoria())).append("\n");
            resultado.append(agregarObjetivoFinanciero("Ahorrar para alquiler y servicios", 900.0, new Date(), new Categoria())).append("\n");
            resultado.append(agregarObjetivoFinanciero("Reunir dinero para pasajes de regreso", 600.0, new Date(), new Categoria())).append("\n");

            resultado.append("Objetivos inicializados correctamente.");
        } catch (ExcepcionMifo.ObjetivoDuplicadoExcepcion e) {
            resultado.append("Error al inicializar: ").append(e.getMessage());
        }
        return resultado.toString();
    }


    /**
     * Valida si un objetivo ya existe en el arreglo de objetivos financieros.
     * @param obj Objetivo a verificar.
     * @return true si ya existe, false si no.
     */
    public boolean validarDuplicado(ObjetivoFinanciero obj) {
        for (ObjetivoFinanciero o : getObjetivos()) {
            if (o != null && o.equals(obj)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Devuelve los objetivos actuales como un arreglo seguro.
     * @return Arreglo de objetivos registrados.
     */
    public List<ObjetivoFinanciero> getObjetivos() {
        return Collections.unmodifiableList(objetivos);
    }

    /*@Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Presupuesto: ").append(montoPresupuesto).append("\n");
        sb.append("Fecha: ").append(fecha).append("\n");
        sb.append("Gasto Total: ").append(gastoTotal).append("\n");
        sb.append("Ingreso Total: ").append(ingresoTotal).append("\n");
        sb.append("Número de movimientos: ").append(numMovimientos).append("\n");
        sb.append("Tipo: ").append(tipo).append("\n");
        sb.append("Movimientos:\n");
        if (movimientos != null) {
            for (int i = 0; i < numMovimientos; i++) {
                sb.append("  ").append(movimientos[i]).append("\n");
            }
        }
        sb.append("Objetivos Financieros:\n");
        if (objetivos != null) {
            for (int i = 0; i < numObjetivos; i++) {
                sb.append("  ").append(objetivos[i]).append("\n");
            }
        }
        return sb.toString();
    }*/
    @Override
    public String toString() {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

        return "Presupuesto #" + codigo +
                " | Fecha: " + formato.format(fecha) +
                " | Monto: $" + String.format("%.2f", montoPresupuesto) +
                " | Usuario: " + (usuario != null ? usuario.getNombre() : "Sin usuario") +
                " | Tipo: " + (tipo != null ? tipo.name() : "Sin tipo") +
                " | Ingresos: $" + String.format("%.2f", ingresoTotal) +
                " | Gastos: $" + String.format("%.2f", gastoTotal);
    }


    @Override
    public int compareTo(Presupuesto otro) {
        int resultado = Integer.compare(this.codigo, otro.codigo);
        if (resultado > 0) {
            return 1;
        } else if (resultado < 0) {
            return -1;
        } else {
            return 0;
        }
    }

    @Override
    public boolean equals(Object o) {
        boolean result = false;
        if (o != null && o instanceof Presupuesto) {
            Presupuesto p = (Presupuesto) o;
            if (Double.compare(this.montoPresupuesto, p.montoPresupuesto) == 0 &&
                    ((this.fecha == null && p.fecha == null) ||
                            (this.fecha != null && this.fecha.equals(p.fecha)))) {
                result = true;
            }
        }
        return result;
    }
    @Override
    public String nuevo(Object obj) {
        if (obj instanceof ObjetivoFinanciero) {
            try {
                ObjetivoFinanciero objetivo = (ObjetivoFinanciero) obj;
                return agregarObjetivoFinanciero(objetivo);
            } catch (Exception e) {
                return "Error al agregar objetivo financiero: " + e.getMessage();
            }
        }
        return "Tipo de objeto no válido para agregar en Presupuesto.";
    }


    @Override
    public String editar(Object obj) {
        if (obj instanceof ObjetivoFinanciero objetivoEditado) {
            int indice = objetivos.indexOf(objetivoEditado);
            if (indice != -1) {
                objetivos.set(indice, objetivoEditado);
                return "Objetivo financiero editado correctamente.";
            }
            return "Objetivo financiero no encontrado.";
        }
        return "Tipo de objeto no válido para editar.";
    }


    @Override
    public String borrar(Object obj) {
        if (obj instanceof ObjetivoFinanciero objetivo) {
            try {
                eliminarObjetivoFinanciero(objetivo);  // método que lanza excepción
                return "Objetivo eliminado correctamente.";
            } catch (ExcepcionMifo.ObjetivoInvalidoExcepcion e) {
                return "Error al eliminar objetivo: " + e.getMessage();
            }
        }
        return "Tipo de objeto no válido para eliminar.";
    }
    @Override
    public Object buscarPorId(Integer id) {
        for (ObjetivoFinanciero o : objetivos) {
            if (o != null && o.getCodigo() == id) {
                return o;
            }
        }
        return null;
    }

    @Override
    public String listar() {
        StringBuilder sb = new StringBuilder("Objetivos Financieros:\n");
        for (ObjetivoFinanciero o : objetivos) {
            if (o != null) sb.append(o).append("\n");
        }
        return sb.toString();
    }

}