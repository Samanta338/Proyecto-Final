package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Usuario;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class UsuarioDaoMemoriaImp {
    private static List<Usuario> usuarios = new ArrayList<>();
    public void agregar(Usuario usuario) {
        usuarios.add(usuario);
    }
    public void editar(Usuario usuarioActualizado) {
        for (int i = 0; i < usuarios.size(); i++) {
            if (usuarios.get(i).getCodigo() == usuarioActualizado.getCodigo()) {
                usuarios.set(i, usuarioActualizado);
                return;
            }
        }
        System.out.println("Usuario no encontrado para editar.");
    }
    public void eliminar(int codigo) {
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario u = usuarios.get(i);
            if (u != null && u.getCodigo() == codigo) {
                usuarios.remove(i);
                return;
            }
        }
        System.out.println("Usuario no encontrado para eliminar.");
    }
    public Usuario buscarPorCodigo(int codigo) {
        for (Usuario u : usuarios) {
            if (u.getCodigo() == codigo) {
                return u;
            }
        }
        return null;
    }

    public List<Usuario> consultarTodos() {
        return new ArrayList<>(usuarios);
    }
}
