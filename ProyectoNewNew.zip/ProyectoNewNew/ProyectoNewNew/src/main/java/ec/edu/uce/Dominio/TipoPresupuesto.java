package ec.edu.uce.Dominio;
public enum TipoPresupuesto {
       //ANUAL, SEMANAL, MENSUAL
        ANUAL("A", "Presupuesto anual", 365, 12, 10000.0, 1),
        MENSUAL("M", "Presupuesto mensual", 30, 1, 1000.0, 2),
        SEMANAL("S", "Presupuesto semanal", 7, 0, 250.0, 3);
        private final String codigo;
        private final String descripcion;
        private final int diasDuracion;
        private final int mesesDuracion;
        private final double limiteSugerido;
        private final int prioridad;
        private TipoPresupuesto(String codigo, String descripcion, int diasDuracion, int mesesDuracion, double limiteSugerido, int prioridad) {
            this.codigo = codigo;
            this.descripcion = descripcion;
            this.diasDuracion = diasDuracion;
            this.mesesDuracion = mesesDuracion;
            this.limiteSugerido = limiteSugerido;
            this.prioridad = prioridad;
        }

        public String getCodigo() {
            return codigo;
        }
        public String getDescripcion() {
            return descripcion;
        }
        public int getDiasDuracion() {
            return diasDuracion;
        }
        public int getMesesDuracion() {
            return mesesDuracion;
        }
        public double getLimiteSugerido()
        { return limiteSugerido;
        }
        public int getPrioridad() {
            return prioridad;
        }
    }

