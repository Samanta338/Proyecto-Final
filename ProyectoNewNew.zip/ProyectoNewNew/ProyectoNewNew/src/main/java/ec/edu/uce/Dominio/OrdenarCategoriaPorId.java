package ec.edu.uce.Dominio;
import java.util.Comparator;
public class OrdenarCategoriaPorId implements Comparator<Categoria> {
    @Override
    public int compare(Categoria c1, Categoria c2) {
        if (c1.getId() < c2.getId()) {
            return -1;
        } else if (c1.getId() > c2.getId()) {
            return 1;
        } else {
            return 0;
        }
    }
}
