package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.*;

import ec.edu.uce.Dominio.SolicitudCurso;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;

import java.util.*;
public class SubMenuGestionarEducacionFinanciera {
    /**
     * Instancia de la empresa que administra las categorías.
     */
    private Empresa empresa = Empresa.getInstance();
    private List<EducacionFinanciera> cursos = new ArrayList<>();

    private int numCursos = 0;
    private Scanner entrada = new Scanner(System.in);
    public void menuGestionarEducacionFinanciera() {
        boolean continuar = true;
        while (continuar) {
            System.out.println();
            System.out.println("  ----------------------------------------------  ");
            System.out.println(" |       Gestionar Educación Financiera          |");
            System.out.println("  ----------------------------------------------  ");
            System.out.println(" |  1. Crear Educación Financiera                |");
            System.out.println(" |  2. Editar Educación Financiera               |");
            System.out.println(" |  3. Eliminar Educación Financiera             |");
            System.out.println(" |  4. Consultar Educación Financiera            |");
            System.out.println(" |  5. Ordenar cursos                            |");
            System.out.println(" |  6. Volver al menú principal                  |");
            System.out.println(" |  7. Salir del sistema                         |");
            System.out.println("  ----------------------------------------------  ");
            System.out.println();
            System.out.print("Por favor, selecciona una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                    crearCurso();
                    break;
                case "2":
                    editarCurso();
                    break;
                case "3":
                    eliminarCurso();
                    break;
                case "4":
                    menuConsultaCursos();
                    break;
                case "5":
                    menuOrdenarCursos();
                    break;
                case "6":
                    System.out.println();
                    System.out.println("Volviendo al menú principal...");
                    return;
                case "7":
                    System.out.println();
                    System.out.println("                                     Cerrando el sistema.");
                    System.out.println("------------------------------------------------------------------------------------------------");
                    System.out.println("Gracias por haber confiado en Mifo. Esperamos que nuestra plataforma te haya sido de gran ayuda.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
            System.out.println();
        }
    }
    public void crearCurso() {
        System.out.println("\n--- CREAR NUEVO CURSO ---");

        // Validar título
        String titulo;
        do {
            System.out.print("Título: ");
            titulo = entrada.nextLine().trim();
            if (titulo.length() < 3 || titulo.length() > 50 || titulo.matches("\\d+")) {
                System.out.println("El título debe tener entre 3 y 50 caracteres y no puede ser solo números.");
            }
        } while (titulo.length() < 3 || titulo.length() > 50 || titulo.matches("\\d+"));

        // Validar descripción
        String descripcion;
        do {
            System.out.print("Descripción: ");
            descripcion = entrada.nextLine().trim();
            if (descripcion.length() < 10 || descripcion.length() > 200 || descripcion.matches("\\d+")) {
                System.out.println("La descripción debe tener entre 10 y 200 caracteres y no puede ser solo números.");
            }
        } while (descripcion.length() < 10 || descripcion.length() > 200 || descripcion.matches("\\d+"));

        // Duración en semanas
        int duracion = solicitarEnteroPositivo("Duración en semanas: ");

        // Nivel
        String nivel;
        while (true) {
            System.out.print("Nivel (BASICO, INTERMEDIO, AVANZADO): ");
            nivel = entrada.nextLine().trim().toUpperCase();
            if (nivel.equals("BASICO") || nivel.equals("INTERMEDIO") || nivel.equals("AVANZADO") || nivel.equals("DESCONOCIDO")) {
                break;
            } else {
                System.out.println("Nivel inválido. Debe ser BASICO, INTERMEDIO o AVANZADO.");
            }
        }

        // Modalidad
        String modalidad;
        do {
            System.out.print("Modalidad: ");
            modalidad = entrada.nextLine().trim();
            if (modalidad.length() < 3 || modalidad.length() > 30 || modalidad.matches("\\d+(\\.\\d+)?")) {
                System.out.println("La modalidad debe tener entre 3 y 30 caracteres y no puede ser solo números o decimales.");
            }
        } while (modalidad.length() < 3 || modalidad.length() > 30 || modalidad.matches("\\d+(\\.\\d+)?"));


        System.out.print("Nombre de la categoría: ");
        String nombreCategoria = entrada.nextLine().trim();
        Categoria categoria = new Categoria(nombreCategoria);

        Date fechaInicio = new Date();

        try {
            EducacionFinanciera curso = new EducacionFinanciera(
                    titulo, descripcion, duracion, nivel, modalidad, categoria, fechaInicio
            );

            //Guardar en la lista oficial de Empresa
            Empresa.getInstance().getEducacionesFinancieras().add(curso);

            System.out.println("Curso creado exitosamente.");

        } catch (IllegalArgumentException e) {
            System.out.println("Error al crear el curso: " + e.getMessage());
        }
    }

    // Editar un curso
    public void editarCurso() {
        System.out.print("Ingrese el título del curso a editar: ");
        String titulo = entrada.nextLine().trim();

        EducacionFinanciera curso = buscarCursoPorTitulo(titulo);
        if (curso == null) {
            System.out.println("Curso no encontrado.");
            return;
        }

        System.out.println("EDITANDO: " + curso.getTitulo());

        System.out.print("Nuevo título (Enter para mantener): ");
        String nuevoTitulo = entrada.nextLine().trim();
        if (!nuevoTitulo.isEmpty()) {
            curso.setTitulo(nuevoTitulo);
        }

        System.out.print("Nueva descripción (Enter para mantener): ");
        String nuevaDescripcion = entrada.nextLine().trim();
        if (!nuevaDescripcion.isEmpty()) {
            curso.setDescripcion(nuevaDescripcion);
        }

        System.out.print("Nueva duración (0 para mantener): ");
        try {
            int nuevaDuracion = Integer.parseInt(entrada.nextLine().trim());
            if (nuevaDuracion > 0) {
                curso.setDuracionSemanas(nuevaDuracion);
            }
        } catch (NumberFormatException e) {
            System.out.println("Formato inválido. La duración se ha mantenido.");
        }

        System.out.print("Nuevo nivel (Enter para mantener): ");
        String nuevoNivel = entrada.nextLine().trim();
        if (!nuevoNivel.isEmpty()) {
            curso.setNivel(nuevoNivel.toUpperCase());
        }

        System.out.print("Nueva modalidad (Enter para mantener): ");
        String nuevaModalidad = entrada.nextLine().trim();
        if (!nuevaModalidad.isEmpty()) {
            curso.setModalidad(nuevaModalidad);
        }

        System.out.print("Nueva categoría (Enter para mantener): ");
        String nuevaCategoria = entrada.nextLine().trim();
        if (!nuevaCategoria.isEmpty()) {
            curso.setCategoria(new Categoria(nuevaCategoria));
        }

        System.out.println("Curso actualizado correctamente.");
    }


    public void eliminarCurso() {
        System.out.print("Ingrese el título del curso a eliminar: ");
        String titulo = entrada.nextLine().trim();

        EducacionFinanciera curso = buscarCursoPorTitulo(titulo);
        if (curso == null) {
            System.out.println("Curso no encontrado.");
            return;
        }

        cursos.remove(curso); // Elimina el objeto directamente
        System.out.println("Curso eliminado exitosamente.");
    }

    private void menuConsultaCursos() {
        boolean regresar = false;
        while (!regresar) {
            System.out.println();
            System.out.println("  -----------------------------------------------  ");
            System.out.println(" |        Consultar Educación Financiera          |");
            System.out.println("  -----------------------------------------------  ");
            System.out.println(" |  1. Ver cursos disponibles                     |");
            System.out.println(" |  2. Buscar cursos por categoría                |");
            System.out.println(" |  3. Ver detalle de un curso                    |");
            System.out.println(" |  4. Inscribirse a un curso                     |");
            System.out.println(" |  5. Volver al menú anterior                    |");
            System.out.println("  -----------------------------------------------  ");
            System.out.println();
            System.out.print("Seleccione una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                  consultarEducacionFinanciera();
                    break;
                case "2":
                    buscarCursosPorCategoria();
                    break;
                case "3":
                    verDetalleCurso();
                    break;
                case "4":
                    inscribirseCurso();
                    break;
                case "5":
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
            System.out.println();
        }
    }
    private void consultarEducacionFinanciera() {
        System.out.println("\n----- Cursos Disponibles -----");
        System.out.println(empresa.consultarEducacionFinanciera());
    }


    private void buscarCursosPorCategoria() {
        String categoriaBuscada = solicitarCadenaNoVacia("Ingrese la categoría a buscar: ");
        boolean encontrado = false;
        for (EducacionFinanciera curso : cursos) {
            if (curso != null && curso.getCategoria().getNombreCategoria().equalsIgnoreCase(categoriaBuscada)) {
                System.out.println(curso);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron cursos en esa categoría.");
        }
    }

    private void verDetalleCurso() {
        System.out.print("Ingrese el título del curso para ver el detalle: ");
        String titulo = entrada.nextLine().trim();

        EducacionFinanciera curso = buscarCursoPorTitulo(titulo); // usa List
        if (curso == null) {
            System.out.println("Curso no encontrado.");
            return;
        }

        System.out.println();
        System.out.println(curso);
    }


    private EducacionFinanciera buscarCursoPorTitulo(String titulo) {
        for (EducacionFinanciera curso : cursos) {
            if (curso != null && curso.getTitulo().equalsIgnoreCase(titulo)) {
                return curso;
            }
        }
        return null;
    }

    private void inscribirseCurso() {
        String nombre = solicitarCadenaNoVacia("Ingrese el nombre del curso al que desea inscribirse: ");

        for (EducacionFinanciera curso : cursos) {
            if (curso != null && curso.getTitulo().equalsIgnoreCase(nombre)) {

                Usuario usuarioActual = Empresa.getInstance().getUsuarioActual();

                if (usuarioActual == null) {
                    System.out.println(" No hay un usuario autenticado para inscribirse.");
                    return;
                }

                SolicitudCurso nuevaSolicitud = new SolicitudCurso(curso, usuarioActual, new Date());

                try {
                    String mensaje = curso.agregarSolicitudCurso(nuevaSolicitud);
                    System.out.println(mensaje);
                } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                    System.out.println("Error al inscribirse: " + e.getMessage());
                }

                return;
            }
        }

        System.out.println("Curso no encontrado.");
    }


    private String solicitarCadenaNoVacia(String mensaje) {
        String input;
        do {
            System.out.print(mensaje);
            input = entrada.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("Entrada no puede estar vacía. Intente de nuevo.");
            }
        } while (input.isEmpty());
        return input;
    }

    private String solicitarCadenaOpcional(String mensaje) {
        System.out.print(mensaje);
        return entrada.nextLine().trim();
    }

    private EducacionFinanciera buscarCurso(String titulo) {
        for (EducacionFinanciera curso : cursos) {
            if (curso != null && curso.getTitulo().equalsIgnoreCase(titulo)) {
                return curso;
            }
        }
        return null;
    }

    private int solicitarEnteroPositivo(String mensaje) {
        int valor = -1;
        do {
            System.out.print(mensaje);
            String input = entrada.nextLine().trim();
            try {
                valor = Integer.parseInt(input);
                if (valor <= 0) {
                    System.out.println("Por favor ingrese un número entero positivo.");
                    valor = -1;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }
        } while (valor <= 0);
        return valor;
    }
    private void menuOrdenarCursos() {
        boolean regresar = false;

        while (!regresar) {
            System.out.println();
            System.out.println("  ---------------------------------------------  ");
            System.out.println(" |     Ordenar Curosos Educación Financiera     |");
            System.out.println("  ---------------------------------------------  ");
            System.out.println(" |  1. Por Título (Comparable)                  |");
            System.out.println(" |  2. Por Duración (Comparator)                |");
            System.out.println(" |  3. Volver                                   |");
            System.out.println("  ---------------------------------------------  ");
            System.out.print("Seleccione una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                    ordenarCursosPorTituloComparable(); // usa compareTo()
                    break;
                case "2":
                    ordenarCursos(new OrdenarEducacionPorDuracion()); // usa Comparator
                    break;
                case "3":
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }

    public void ordenarCursos(Comparator<EducacionFinanciera> comparador) {
        List<EducacionFinanciera> cursos = Empresa.getInstance().getEducacionesFinancieras();
        if (cursos.isEmpty()) {
            System.out.println("No hay cursos para ordenar.");
            return;
        }

        Collections.sort(cursos, comparador); // usa Comparator externo

        System.out.println("Cursos ordenados por duración (Comparator):");
        mostrarCursosEnTabla(cursos);
    }

    public void ordenarCursosPorTituloComparable() {
        List<EducacionFinanciera> cursos = Empresa.getInstance().getEducacionesFinancieras();
        if (cursos.isEmpty()) {
            System.out.println("No hay cursos para ordenar.");
            return;
        }

        Collections.sort(cursos); // usa compareTo por título

        System.out.println("Cursos ordenados por título (Comparable):");
        mostrarCursosEnTabla(cursos);
    }


    private void mostrarCursosEnTabla(List<EducacionFinanciera> cursos) {
        if (cursos == null || cursos.isEmpty()) {
            System.out.println("No hay cursos registrados.");
            return;
        }

        System.out.println();
        System.out.println("  =========================================================================================================================================================");
        System.out.printf(" | %-3s | %-10s | %-25s | %-35s | %-8s | %-10s | %-15s | %-20s | %-15s | %-6s |\n",
                "Nº", "Código", "Título", "Descripción", "Duración", "Nivel", "Modalidad", "Categoría", "Fecha inicio", "Solic.");
        System.out.println("  =========================================================================================================================================================");

        for (int i = 0; i < cursos.size(); i++) {
            EducacionFinanciera curso = cursos.get(i);
            String descripcion = curso.getDescripcion().length() > 35
                    ? curso.getDescripcion().substring(0, 32) + "..."
                    : curso.getDescripcion();

            System.out.printf(" | %-3d | %-10s | %-25s | %-35s | %-8d | %-10s | %-15s | %-20s | %-15s | %-6d |\n",
                    (i + 1),
                    curso.getCodigo(),
                    curso.getTitulo(),
                    descripcion,
                    curso.getDuracionSemanas(),
                    curso.getNivel(),
                    curso.getModalidad(),
                    curso.getCategoria().getNombreCategoria(),
                    new java.text.SimpleDateFormat("dd-MM-yyyy").format(curso.getFechaInicio()),
                    curso.getSolicitudes().size());
        }

        System.out.println("  =========================================================================================================================================================");
    }


}
