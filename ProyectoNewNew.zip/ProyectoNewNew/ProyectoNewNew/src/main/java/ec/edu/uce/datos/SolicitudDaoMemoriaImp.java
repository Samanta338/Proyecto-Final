package ec.edu.uce.datos;
import ec.edu.uce.Dominio.SolicitudCurso;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class SolicitudDaoMemoriaImp {
    private static List<SolicitudCurso> solicitudes = new ArrayList<>();
    public void agregar(SolicitudCurso solicitud) {
        solicitudes.add(solicitud);
    }
    public void editar(SolicitudCurso solicitud) {
        for (int i = 0; i < solicitudes.size(); i++) {
            if (solicitudes.get(i).getCodigo() == solicitud.getCodigo()) {
                solicitudes.set(i, solicitud);
                return;
            }
        }
        System.out.println("Solicitud no encontrada para editar.");
    }
    public void eliminar(int codigo) {
        for (int i = 0; i < solicitudes.size(); i++) {
            SolicitudCurso s = solicitudes.get(i);
            if (s != null && s.getCodigo() == codigo) {
                solicitudes.remove(i);
                return;
            }
        }
        System.out.println("Solicitud no encontrada para eliminar.");
    }
    public SolicitudCurso buscarPorCodigo(int codigo) {
        for (SolicitudCurso s : solicitudes) {
            if (s.getCodigo() == codigo) {
                return s;
            }
        }
        return null;
    }
    public List<SolicitudCurso> consultarSolicitudes() {
        return new ArrayList<>(solicitudes);
    }
}
