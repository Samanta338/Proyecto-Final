package ec.edu.uce.dominio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import ec.edu.uce.util.ExcepcionMifo;

import java.util.Date;
class EmpresaTest {
    private Empresa empresa;
    @BeforeEach
    void setUp() {
        empresa = Empresa.getInstance();
        empresa.getUsuarios().clear();
        empresa.getCategorias().clear();
        empresa.getEducacionesFinancieras().clear();
    }

    // --- USUARIOS ---

    @Test
    void testAgregarYEliminarUsuarioPorNombre() throws Exception {
        empresa.agregarUsuarioConCodigo("jose", "pass123", "jose@mail.com");
        assertEquals(1, empresa.getUsuarios().size());

        empresa.eliminarUsuario("jose");
        assertEquals(0, empresa.getUsuarios().size());
    }

    @Test
    void testEliminarUsuarioNoExistenteLanzaExcepcion() {
        ExcepcionMifo.UsuarioNoEncontradoExcepcion ex = assertThrows(
                ExcepcionMifo.UsuarioNoEncontradoExcepcion.class,
                () -> empresa.eliminarUsuario("noexiste")
        );
        assertTrue(ex.getMessage().contains("Usuario no encontrado"));
    }

    @Test
    void testEditarUsuarioPorIndice() throws Exception {
        empresa.agregarUsuarioConCodigo("maria", "1234", "maria@mail.com");

        Usuario editado = new Usuario("mariaEditada", "newpass", "mariaEditada@mail.com", "17037839264");
        empresa.editarUsuario(0, editado);

        Usuario usuarioModificado = empresa.getUsuarios().get(0);
        assertEquals("mariaEditada", usuarioModificado.getNombre());
        assertEquals("newpass", usuarioModificado.getContrasena());
    }

    @Test
    void testEditarUsuarioPorNombre() throws Exception {
        empresa.agregarUsuarioConCodigo("pedro", "1234", "pedro@mail.com");

        Usuario editado = new Usuario("pedroNuevo", "passNueva", "pedroNuevo@mail.com", "10373546384");
        empresa.editarUsuario("pedro", editado);

        Usuario usuarioModificado = empresa.getUsuarios().get(0);
        assertEquals("pedroNuevo", usuarioModificado.getNombre());
    }

    // --- CATEGORIAS ---

    @Test
    void testAgregarYConsultarCategoria() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        empresa.agregarCategoriaConCodigo("Viajes");
        assertEquals(1, empresa.getCategorias().size());

        String resultado = empresa.consultarCategorias();
        assertTrue(resultado.contains("Viajes"));
    }
    @Test
    void testEditarCategoriaPorIndice() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        empresa.agregarCategoriaConCodigo("Alimentos");

        Categoria nuevaCategoria = new Categoria("Comida");
        empresa.editarCategoria(0, nuevaCategoria);

        String resultado = empresa.consultarCategorias();
        assertTrue(resultado.contains("Comida"));
        assertFalse(resultado.contains("Alimentos"));
    }

    @Test
    void testEliminarCategoriaPorNombre() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        empresa.agregarCategoriaConCodigo("Deportes");
        empresa.eliminarCategoria("Deportes");
        assertEquals(0, empresa.getCategorias().size());
    }
    // --- EDUCACION FINANCIERA ---

    @Test
    void testAgregarEducacionFinanciera() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Categoria categoria = new Categoria("Educacion");
        empresa.agregarCategoria(categoria);

        String mensaje = empresa.agregarEducacionFinancieraConCodigo(
                "Curso Ahorro",
                "Aprende a ahorrar",
                4,
                "BASICO",
                "Online",
                categoria,
                new Date()
        );

        assertTrue(mensaje.contains("Curso Ahorro"));
        assertEquals(1, empresa.getEducacionesFinancieras().size());
    }

    @Test
    void testAgregarEducacionFinancieraDuplicadaLanzaExcepcion() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Categoria categoria = new Categoria("Finanzas");
        empresa.agregarCategoria(categoria);

        empresa.agregarEducacionFinancieraConCodigo(
                "Curso Finanzas",
                "Descripción",
                5,
                "INTERMEDIO",
                "Presencial",
                categoria,
                new Date()
        );

        ExcepcionMifo.MovimientoInvalidoExcepcion ex = assertThrows(
                ExcepcionMifo.MovimientoInvalidoExcepcion.class,
                () -> empresa.agregarEducacionFinancieraConCodigo(
                        "Curso Finanzas",
                        "Otra descripción",
                        3,
                        "AVANZADO",
                        "Online",
                        categoria,
                        new Date()
                )
        );

        assertTrue(ex.getMessage().contains("Ya existe una educación financiera"));
    }
}


