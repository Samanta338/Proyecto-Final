package ec.edu.uce;
class SubMenuGestionarEducacionFinancieraTest {
    public static void main(String[] args) {
        SubMenuGestionarEducacionFinanciera subMenu= new SubMenuGestionarEducacionFinanciera();
        subMenu.menuGestionarEducacionFinanciera();
    }
}