package ec.edu.uce.dominio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;
import ec.edu.uce.util.ExcepcionMifo;
class PresupuestoTest {
    private Presupuesto presupuesto;
    private Categoria categoria;
    private Date fecha;

    @BeforeEach
    public void setUp() {
        fecha = new Date();
        presupuesto = new Presupuesto(1000.0, fecha);
        categoria = new Categoria("Comida", null);
    }

    @Test
    public void testPresupuestoInicial() {
        assertNotNull(presupuesto);
        assertEquals(1000.0, presupuesto.getMontoPresupuesto());
        assertEquals(fecha, presupuesto.getFecha());
        assertEquals(0, presupuesto.getNumMovimientos());
    }

    @Test
    public void testAgregarIngreso() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        presupuesto.agregarMovimiento("Sueldo", 500.0, fecha, categoria, true);

        assertEquals(1, presupuesto.getNumMovimientos());
        assertEquals(1500.0, presupuesto.getMontoPresupuesto());
        assertEquals(500.0, presupuesto.getIngresoTotal());
        assertEquals(0.0, presupuesto.getGastoTotal());
    }

    @Test
    public void testAgregarGasto() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        presupuesto.agregarMovimiento("Compra", 200.0, fecha, categoria, false);

        assertEquals(1, presupuesto.getNumMovimientos());
        assertEquals(800.0, presupuesto.getMontoPresupuesto());
        assertEquals(0.0, presupuesto.getIngresoTotal());
        assertEquals(200.0, presupuesto.getGastoTotal());
    }

    @Test
    public void testEditarMovimiento() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        presupuesto.agregarMovimiento("Sueldo", 500.0, fecha, categoria, true);
        presupuesto.editarMovimiento(0, "Sueldo modificado", 600.0, fecha, true, categoria);

        assertEquals(1, presupuesto.getNumMovimientos());
        assertEquals(1600.0, presupuesto.getMontoPresupuesto());
        assertEquals(600.0, presupuesto.getIngresoTotal());
        assertEquals("Sueldo modificado", presupuesto.getMovimientos()[0].getDescripcion());
    }

    @Test
    public void testGetters() {
        assertEquals(fecha, presupuesto.getFecha());
        assertEquals(1000.0, presupuesto.getMontoPresupuesto());
        assertEquals(0, presupuesto.getNumMovimientos());
    }

    // Tests para Objetivos Financieros

    @Test
    public void testAgregarObjetivo() throws Exception {
        String res = presupuesto.agregarObjetivoFinanciero("Viaje", 500.0, categoria);
        assertTrue(res.contains("Viaje"));
        assertEquals(1, presupuesto.getObjetivos().length);
    }
    @Test
    void testAgregarObjetivoFinanciero() throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        Presupuesto presupuesto = new Presupuesto(10.00, new Date());
        presupuesto.agregarObjetivoFinanciero(new ObjetivoFinanciero("Ahorro", 500));

        String objetivos = presupuesto.consultarObjetivosFinancieros();
        assertTrue(objetivos.contains("Ahorro"));
    }
    @Test
    public void testEditarObjetivoPorIndice() throws Exception {
        presupuesto.agregarObjetivoFinanciero("Viaje", 500.0, categoria);
        ObjetivoFinanciero editado = new ObjetivoFinanciero("Viaje", 600.0, new Date(), categoria);
        presupuesto.editarObjetivoFinanciero(0, editado);
        assertEquals(600.0, presupuesto.getObjetivos()[0].getMonto());
    }

    @Test
    public void testEditarObjetivoPorDescripcion() throws Exception {
        presupuesto.agregarObjetivoFinanciero("Viaje", 500.0, categoria);
        ObjetivoFinanciero nuevo = new ObjetivoFinanciero("Viaje", 700.0, new Date(), categoria);
        presupuesto.editarObjetivoFinanciero("Viaje", nuevo);
        String info = presupuesto.consultarObjetivoFinanciero("Viaje");
        assertTrue(info.contains("700.0"));
    }

    @Test
    public void testConsultarObjetivo() throws Exception {
        presupuesto.agregarObjetivoFinanciero("Viaje", 500.0, categoria);
        String info = presupuesto.consultarObjetivoFinanciero("Viaje");
        assertTrue(info.contains("Viaje"));
        assertTrue(info.contains("500.0"));
    }

    @Test
    public void testValidarDuplicado() throws Exception {
        presupuesto.agregarObjetivoFinanciero("Viaje", 500.0, categoria);
        ObjetivoFinanciero obj = presupuesto.getObjetivos()[0];
        assertTrue(presupuesto.validarDuplicado(obj));
    }

    @Test
    public void testEliminarObjetivoPorDescripcion() throws Exception {
        presupuesto.agregarObjetivoFinanciero("Viaje", 500.0, categoria);
        presupuesto.eliminarObjetivoFinanciero("Viaje");
        assertEquals(0, presupuesto.getObjetivos().length);
    }

    @Test
    public void testEliminarObjetivoPorIndice() throws Exception {
        presupuesto.agregarObjetivoFinanciero("Viaje", 500.0, categoria);
        presupuesto.eliminarObjetivoFinanciero(0);
        assertEquals(0, presupuesto.getObjetivos().length);
    }

    // Tests para movimientos con objetos

    @Test
    public void testAgregarMovimientoIngresoObjeto() throws Exception {
        Movimiento ingreso = new Ingreso("Sueldo", 1000.0, new Date(), categoria);
        String res = presupuesto.agregarMovimiento(ingreso);
        assertTrue(res.contains("Sueldo"));
        assertEquals(1, presupuesto.getNumMovimientos());
        assertEquals(1000.0, presupuesto.getIngresoTotal());
    }

    @Test
    public void testAgregarMovimientoGastoObjeto() throws Exception {
        Movimiento gasto = new Gasto("Comida", 200.0, new Date(), categoria);
        String res = presupuesto.agregarMovimiento(gasto);
        assertTrue(res.contains("Comida"));
        assertEquals(1, presupuesto.getNumMovimientos());
        assertEquals(200.0, presupuesto.getGastoTotal());
    }

    @Test
    public void testEditarMovimientoObjeto() throws Exception {
        Movimiento ingreso = new Ingreso("Sueldo", 1000.0, new Date(), categoria);
        presupuesto.agregarMovimiento(ingreso);
        presupuesto.editarMovimiento(0, "Sueldo aumentado", 1200.0, new Date(), true, categoria);
        Movimiento mov = presupuesto.getMovimientos()[0];
        assertEquals("Sueldo aumentado", mov.getDescripcion());
        assertEquals(1200.0, mov.getMonto());
    }

}






