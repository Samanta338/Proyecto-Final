package ec.edu.uce.dominio;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
public class TestComparator {
    public static void main(String[] args) {
        // Ordenar Categoría por ID y Nombre
        List<Categoria> categorias = new ArrayList<>();
        categorias.add(new Categoria("Inversiones"));
        categorias.add(new Categoria("Ahorro"));
        categorias.add(new Categoria("Gastos"));
        System.out.println("-------- Categorías ordenadas por nombre --------");
        Collections.sort(categorias, new OrdenarCategoriaPorNombre());
        for (Categoria c : categorias) {
            System.out.println(c);
        }
        System.out.println("-------- Categorías ordenadas por ID --------");
        Collections.sort(categorias, new OrdenarCategoriaPorId());
        for (Categoria c : categorias) {
            System.out.println(c);
        }

        // Ordenar Educación Financiera por duración
        List<EducacionFinanciera> cursos = new ArrayList<>();
        cursos.add(new EducacionFinanciera("Curso A", 5, EducacionFinanciera.NIVEL_BASICO));
        cursos.add(new EducacionFinanciera("Curso B", 10, EducacionFinanciera.NIVEL_INTERMEDIO));
        cursos.add(new EducacionFinanciera("Curso C", 3, EducacionFinanciera.NIVEL_AVANZADO));

        System.out.println("-------- Cursos ordenados por duración --------");
        Collections.sort(cursos, new OrdenarEducacionPorDuracion());
        for (EducacionFinanciera e : cursos) {
            System.out.println(e);
        }
        // Ordenar Movimiento por monto
        List<Movimiento> movimientos = new ArrayList<>();
        movimientos.add(new Gasto("Compra", 80.50, new Date()));
        movimientos.add(new Ingreso("Salario", 400.00, new Date()));
        movimientos.add(new Ingreso("Inversión", 200.00, new Date()));

        System.out.println("-------- Movimientos ordenados por monto --------");
        Collections.sort(movimientos, new OrdenarMovimientoPorMontoDescendente());
        for (Movimiento m : movimientos) {
            System.out.println(m);
        }

        // Ordenar Objetivos Financieros por monto
        List<ObjetivoFinanciero> objetivos = new ArrayList<>();
        objetivos.add(new ObjetivoFinanciero("Viaje", 1000.0, new Date(), new Categoria("Ahorro")));
        objetivos.add(new ObjetivoFinanciero("Carro", 8000.0, new Date(), new Categoria("Inversiones")));
        objetivos.add(new ObjetivoFinanciero("Estudios", 3000.0, new Date(), new Categoria("Educación")));

        System.out.println("-------- Objetivos ordenados por monto --------");
        Collections.sort(objetivos, new OrdenarObjetivoPorMonto());
        for (ObjetivoFinanciero o : objetivos) {
            System.out.println(o);
        }

        // Ordenar Usuario por nombre
        List<Usuario> usuarios = new ArrayList<>();
        usuarios.add(new Usuario("Carlos", "clave123", "carlos@mail.com", "1100110011"));
        usuarios.add(new Usuario("Ana", "clave456", "ana@mail.com", "1100110012"));
        usuarios.add(new Usuario("Bruno", "clave789", "bruno@mail.com", "1100110013"));

        System.out.println("-------- Usuarios ordenados por nombre --------");
        Collections.sort(usuarios, new OrdenarUsuarioPorNombre());
        for (Usuario u : usuarios) {
            System.out.println(u);
        }
    }
}

