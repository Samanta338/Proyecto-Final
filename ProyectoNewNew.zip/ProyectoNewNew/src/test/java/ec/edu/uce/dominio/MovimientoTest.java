package ec.edu.uce.dominio;
import org.junit.jupiter.api.Test;
import java.util.Date;
import ec.edu.uce.util.ExcepcionMifo;

import static org.junit.jupiter.api.Assertions.*;
class MovimientoTest {
    @Test
    public void testMovimientoBasico() {
        Movimiento m = new Movimiento("Compra", 150.0, new Date(), new Categoria("Educación")) {
            @Override
            public boolean registrar() {
                return true;
            }

            @Override
            public void realizar() {
            }
        };

        // Pruebas básicas:
        assertEquals("Compra", m.getDescripcion());
        assertEquals(150.0, m.getMonto());
        assertEquals("Educación", m.getCategoria().getNombreCategoria());
        assertNotNull(m.getFecha());
        assertTrue(m.getCodigo() > 0);
    }

    @Test
    public void testToStringSimple() {
        Movimiento m = new Movimiento("Pago", 50.0, new Date(), new Categoria("Servicios")) {
            @Override
            public boolean registrar() {
                return true;
            }

            @Override
            public void realizar() {
            }
        };

        String texto = m.toString();

        assertTrue(texto.contains("Pago"));
        assertTrue(texto.contains("50.00") || texto.contains("50,00"));
        assertTrue(texto.contains("Servicios"));
    }

    @Test
    public void testEqualsSimple() {
        Date fecha = new Date();
        Categoria cat = new Categoria("Comida");

        Movimiento m1 = new Movimiento("Almuerzo", 20.0, fecha, cat) {
            @Override
            public boolean registrar() {
                return true;
            }

            @Override
            public void realizar() {
            }
        };
        Movimiento m2 = new Movimiento("Almuerzo", 20.0, fecha, cat) {
            @Override
            public boolean registrar() {
                return true;
            }

            @Override
            public void realizar() {
            }
        };
        Movimiento m3 = new Movimiento("Cena", 30.0, fecha, cat) {
            @Override
            public boolean registrar() {
                return true;
            }

            @Override
            public void realizar() {
            }
        };

        assertEquals(m1, m2);
        assertNotEquals(m1, m3);
    }
}