package ec.edu.uce;
import static org.junit.jupiter.api.Assertions.*;
import ec.edu.uce.dominio.Usuario;
import ec.edu.uce.util.ExcepcionMifo;
import org.junit.jupiter.api.Test;
/**
 * Prueba unitaria para {@link SubMenuGestionarPresupuesto}.
 * Se valida la inicialización del submenú sin verificar usuario.
 */
class SubMenuGestionarPresupuestoTest {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Juan", "123456juan", "juan@mail.com", "1234567890");
        SubMenuGestionarPresupuesto subMenu = new SubMenuGestionarPresupuesto(usuario);
        try {
            subMenu.menuGestionarPresupuesto();
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error en el manejo del presupuesto: " + e.getMessage());
        }
    }
}


