/*package ec.edu.uce.dominio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import ec.edu.uce.util.ExcepcionMifo;
import static org.junit.jupiter.api.Assertions.*;
class EducacionFinancieraTest {
    private EducacionFinanciera curso;
    private Usuario usuario1;
    private Usuario usuario2;
    private SolicitudCurso solicitud1;
    private SolicitudCurso solicitud2;

    @BeforeEach
    void setUp() {
        Categoria categoria = new Categoria("Ahorro", TipoMovimiento.GASTO);
        curso = new EducacionFinanciera("Curso Ahorro", "Ahorrar dinero", 4,
                EducacionFinanciera.NIVEL_BASICO, "Online", categoria, new Date());

        usuario1 = new Usuario("Ana", "clave", "ana@email.com", "1711111111");
        usuario2 = new Usuario("Luis", "clave2", "luis@email.com", "1722222222");

        solicitud1 = new SolicitudCurso(curso, usuario1, new Date());
        solicitud2 = new SolicitudCurso(curso, usuario2, new Date());
    }

    @Test
    void testAgregarSolicitudCurso() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        String mensaje = curso.agregarSolicitudCurso(solicitud1);
        assertEquals(1, curso.getNumSolicitudes());
        assertTrue(mensaje.contains("Solicitud agregada correctamente"));
    }

    @Test
    void testEditarSolicitud() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        curso.agregarSolicitudCurso(solicitud1);

        Usuario usuarioNuevo = new Usuario("Carlos", "clave3", "carlos@email.com", "1733333333");
        SolicitudCurso solicitudNueva = new SolicitudCurso(curso, usuarioNuevo, new Date());

        curso.editarSolicitud(0, solicitudNueva);

        SolicitudCurso solicitada = curso.consultarSolicitud(0);
        assertEquals("Carlos", solicitada.getUsuario().getNombre());
    }

    @Test
    void testEliminarSolicitud() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        curso.agregarSolicitudCurso(solicitud1);
        curso.eliminarSolicitud(0);
        assertEquals(0, curso.getNumSolicitudes());
    }

    @Test
    void testConsultarSolicitud() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        curso.agregarSolicitudCurso(solicitud1);
        SolicitudCurso resultado = curso.consultarSolicitud(0);
        assertNotNull(resultado);
        assertEquals("Ana", resultado.getUsuario().getNombre());
    }

    @Test
    void testConsultarSolicitudes() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        curso.agregarSolicitudCurso(solicitud1);
        curso.agregarSolicitudCurso(solicitud2);

        SolicitudCurso[] solicitudes = curso.consultarSolicitudes(new int[]{0, 1});
        assertEquals(2, solicitudes.length);
        assertEquals("Luis", solicitudes[1].getUsuario().getNombre());
    }

    @Test
    void testListar() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        curso.agregarSolicitudCurso(solicitud1);
        String listado = curso.listar();
        assertTrue(listado.contains("Ana"));
    }

    @Test
    void testNuevoConSolicitudCurso() {
        String resultado = curso.nuevo(solicitud1);
        assertTrue(resultado.contains("Solicitud agregada correctamente"));
    }

    @Test
    void testEditarConSolicitudCurso() {
        curso.nuevo(solicitud1);

        SolicitudCurso nueva = new SolicitudCurso(curso, usuario1, new Date());
        String resultado = curso.editar(nueva);
        assertEquals("Solicitud editada correctamente.", resultado);
    }

    @Test
    void testBorrarConSolicitudCurso() {
        curso.nuevo(solicitud1);
        String resultado = curso.borrar(solicitud1);
        assertEquals("Solicitud eliminada correctamente.", resultado);
    }

    @Test
    void testBuscarPorId() {
        curso.nuevo(solicitud1);
        SolicitudCurso buscada = (SolicitudCurso) curso.buscarPorId(solicitud1.getCodigo());
        assertNotNull(buscada);
        assertEquals(solicitud1.getCodigo(), buscada.getCodigo());
    }

    @Test
    void testToString() {
        String resumen = curso.toString();
        assertTrue(resumen.contains("Curso de Educación Financiera"));
        assertTrue(resumen.contains("Curso Ahorro"));
    }
}*/