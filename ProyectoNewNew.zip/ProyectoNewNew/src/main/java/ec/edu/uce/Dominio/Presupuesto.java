package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ExcepcionMifo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
/**
 * Clase que representa un presupuesto que contiene movimientos financieros
 * (ingresos y gastos) con sus respectivas categorías.
 */
public class Presupuesto implements IAdministrarCRUD{
    private Date fecha;
    private double montoPresupuesto;
    private double gastoTotal;
    private double ingresoTotal;
    private Usuario usuario;
    private TipoPresupuesto tipo;
    private List<Movimiento> movimientos;
    private List<ObjetivoFinanciero> objetivos;
    private List<ObjetivoFinanciero> listaObjetivos;
    private static int contadorCodigo;
    private final int codigo;
    Empresa empresa = Empresa.getInstance();
    public List<ObjetivoFinanciero> getListaObjetivos() {
        return listaObjetivos;
    }

    public void setListaObjetivos(List<ObjetivoFinanciero> listaObjetivos) {
        this.listaObjetivos = listaObjetivos;
    }

    // Bloque de inicialización estático (una sola vez para el contador)
    static {
        contadorCodigo = 0;
    }
    // Bloque de inicialización de instancia (cada vez que se crea un objeto)
    {
        this.codigo = ++contadorCodigo;
        this.movimientos = new ArrayList<>();
        this.objetivos = new ArrayList<>();
        this.listaObjetivos = new ArrayList<>();
    }
    // 1 Constructor que inicializa un presupuesto con un monto y una fecha
    public Presupuesto(Double monto,Date fecha ) {
        this.montoPresupuesto = monto;
        this.fecha = fecha;
    }
    // 2.- Constructor que inicializa un presupuesto con monto, fecha y usuario asociado.
    public Presupuesto(double presupuesto, Date fecha, Usuario usuario) {
        this.montoPresupuesto= presupuesto;
        this.fecha = fecha;
        this.usuario = usuario;
    }

    // 3.- Constructor principal que inicializa todos los atributos del presupuesto.
    public Presupuesto(double presupuesto, Date fecha, double gastoTotal, double ingresoTotal, TipoPresupuesto tipo) {
        this.montoPresupuesto = presupuesto;
        this.fecha = fecha;
        this.gastoTotal = gastoTotal;
        this.ingresoTotal = ingresoTotal;
        this.tipo = tipo;
    }
    // 4. Constructor con presupuesto, fecha y tipo
    public Presupuesto(double presupuesto, Date fecha, TipoPresupuesto tipo) {
        this.fecha=fecha;
        this.montoPresupuesto = presupuesto;
        this.tipo = tipo;
    }
    // 5. Constructor con presupuesto, fecha, usuario y tipo
    public Presupuesto(double presupuesto, Date fecha, Usuario usuario, TipoPresupuesto tipo) {
        this(presupuesto, fecha, 0.0, 0.0, tipo);
        this.usuario = usuario;
    }
    // 6. Constructor con presupuesto, fecha, gastoTotal e ingresoTotal
    public Presupuesto(double presupuesto, Date fecha, double gastoTotal, double ingresoTotal) {
        this(presupuesto, fecha, gastoTotal, ingresoTotal, null);
    }
    public double getMontoPresupuesto() {
        return this.montoPresupuesto;
    }
    public void setMontoPresupuesto(double montoPresupuesto) {
        this.montoPresupuesto = montoPresupuesto;
    }
    public Date getFecha() {
        return this.fecha;
    }
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    public double getGastoTotal() {
        return this.gastoTotal;
    }
    public void setGastoTotal(double gastoTotal) {
        this.gastoTotal = gastoTotal;
    }
    public double getIngresoTotal() {
        return this.ingresoTotal;
    }
    public void setIngresoTotal(double ingresoTotal) {
        this.ingresoTotal = ingresoTotal;
    }
    public void setMovimientos(List<Movimiento> movimientos) {
        this.movimientos = (movimientos != null) ? movimientos : new ArrayList<>();
    }
    public List<Movimiento> getMovimientos() {
        return movimientos;
    }
    public void setObjetivos(List<ObjetivoFinanciero> objetivos) {
        this.objetivos = (objetivos != null) ? objetivos : new ArrayList<>();
    }
    public TipoPresupuesto getTipo() {
        return this.tipo;
    }
    public void setTipo(TipoPresupuesto tipo) {
        this.tipo = tipo;
    }
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    public int getCodigo() {
        return codigo;
    }
    /**
     * Crea y agrega un movimiento al presupuesto
     */
    public void agregarMovimiento(Movimiento movimiento) {
        if (movimiento == null) throw new IllegalArgumentException("Movimiento no puede ser nulo");
        movimientos.add(movimiento);
        if (movimiento instanceof Ingreso) {
            montoPresupuesto = movimiento.getMonto();
            ingresoTotal = movimiento.getMonto();
            gastoTotal = 0;
        } else if (movimiento instanceof Gasto) {
            montoPresupuesto = -movimiento.getMonto();
            gastoTotal = movimiento.getMonto();
            ingresoTotal = 0;
        }
    }
    /**
     * Agrega un movimiento al presupuesto a partir de datos separados.
     *
     * @param descripcion Descripción del movimiento.
     * @param monto Monto del movimiento.
     * @param categoria Categoría del movimiento.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si el movimiento es duplicado.
     */
    public String agregarMovimiento(String descripcion, double monto, Date fecha, Categoria categoria, TipoMovimiento tipo)
            throws ExcepcionMifo.MovimientoInvalidoExcepcion {

        if (fecha == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Fecha inválida.");
        }

        if (validarDuplicado(monto, fecha)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Movimiento duplicado con monto: " + monto + " y fecha: " + fecha);
        }

        Movimiento nuevoMovimiento;
        if (tipo == TipoMovimiento.INGRESO) {
            nuevoMovimiento = new Ingreso(descripcion, monto, fecha, categoria);
        } else {
            nuevoMovimiento = new Gasto(descripcion, monto, fecha, categoria);
        }

        agregarMovimiento(nuevoMovimiento);
        return "Movimiento agregado: " + descripcion;
    }
    public String agregarMovimiento(String descripcion, double monto, String fechaStr, Categoria categoria, TipoMovimiento tipo) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha;
        try {
            fecha = sdf.parse(fechaStr);
        } catch (ParseException e) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Fecha inválida: " + fechaStr);
        }
        return agregarMovimiento(descripcion, monto, fecha, categoria, tipo);
    }

    /**
     *
     * CRUD: Editar movimiento
     * @param indice           índice del movimiento a editar
     * @param nuevaDescripcion nueva descripción
     * @param nuevoMonto       nuevo monto
     * @param nuevaFecha       nueva fecha
     * @param esIngreso        true si es ingreso, false si gasto
     * @param categoria        nueva categoría
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si índice inválido
     */
    public void editarMovimiento(int indice, String nuevaDescripcion, double nuevoMonto, Date nuevaFecha, boolean esIngreso, Categoria categoria) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= movimientos.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice de movimiento inválido.");
        }
        Movimiento movimientoOriginal = movimientos.get(indice);
        double montoAnterior = movimientoOriginal.getMonto();
        movimientoOriginal.setDescripcion(nuevaDescripcion);
        movimientoOriginal.setMonto(nuevoMonto);
        movimientoOriginal.setFecha(nuevaFecha);
        if (movimientoOriginal instanceof Ingreso ingreso) {
            ingreso.setCategoria(categoria);
        } else if (movimientoOriginal instanceof Gasto gasto) {
            gasto.setCategoria(categoria);
        }
        if (movimientoOriginal instanceof Ingreso && !esIngreso) {
            montoPresupuesto = montoPresupuesto - montoAnterior - nuevoMonto;
            ingresoTotal -= montoAnterior;
            gastoTotal += nuevoMonto;
        } else if (movimientoOriginal instanceof Gasto && esIngreso) {
            montoPresupuesto = montoPresupuesto + montoAnterior + nuevoMonto;
            gastoTotal -= montoAnterior;
            ingresoTotal += nuevoMonto;
        } else if (movimientoOriginal instanceof Ingreso) {
            montoPresupuesto = montoPresupuesto - montoAnterior + nuevoMonto;
            ingresoTotal += nuevoMonto - montoAnterior;
        } else if (movimientoOriginal instanceof Gasto) {
            montoPresupuesto = montoPresupuesto + montoAnterior - nuevoMonto;
            gastoTotal += nuevoMonto - montoAnterior;
        }
    }
    public String editarMovimiento(int indice, Movimiento nuevoMovimiento) {
        if (nuevoMovimiento == null) return "Movimiento nulo. No se puede editar.";
        if (indice < 0 || indice >= movimientos.size()) return "Índice inválido.";

        movimientos.set(indice, nuevoMovimiento);
        return "Movimiento editado exitosamente.";
    }
    // ELIMINAR
    public void eliminarMovimiento(int indice) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= movimientos.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice inválido.");
        }
        Movimiento movimiento = movimientos.get(indice);
        if (movimiento instanceof Ingreso) {
            montoPresupuesto -= movimiento.getMonto();
            ingresoTotal -= movimiento.getMonto();
        } else if (movimiento instanceof Gasto) {
            montoPresupuesto += movimiento.getMonto();
            gastoTotal -= movimiento.getMonto();
        }
        movimientos.remove(indice);
    }
    /**
     * Elimina un movimiento específico si existe en la lista.
     *
     * @param movimiento Movimiento a eliminar.
     * @return true si el movimiento fue eliminado, false si no se encontró.
     */
    public boolean eliminarMovimiento(Movimiento movimiento) {
        if (movimiento == null || !movimientos.contains(movimiento)) {
            return false;
        }
        if (movimiento instanceof Ingreso) {
            montoPresupuesto -= movimiento.getMonto();
            ingresoTotal -= movimiento.getMonto();
        } else if (movimiento instanceof Gasto) {
            montoPresupuesto += movimiento.getMonto();
            gastoTotal -= movimiento.getMonto();
        }
        movimientos.remove(movimiento);
        return true;
    }
    // CONSULTAR
    public String consultarMovimiento(int indice) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= movimientos.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice inválido.");
        }
        Movimiento m = movimientos.get(indice);
        return "Descripción: " + m.getDescripcion() +
                "\nMonto: " + m.getMonto() +
                "\nFecha: " + m.getFecha() +
                "\nCategoría: " + (m.getCategoria() != null ? m.getCategoria().getNombreCategoria() : "Sin categoría") +
                "\nTipo: " + (m instanceof Ingreso ? "Ingreso" : "Gasto");
    }
    /**
     * Consulta todos los movimientos existentes.
     *
     * @return Cadena con la información de todos los movimientos
     */
    public String consultarMovimientos() {
        StringBuilder texto = new StringBuilder();
        for (Movimiento mov : movimientos) {
            if (mov != null) {
                texto.append("Descripción: ").append(mov.getDescripcion())
                        .append("\nMonto: ").append(mov.getMonto())
                        .append("\nFecha: ").append(mov.getFecha())
                        .append("\nCategoría: ").append(mov.getCategoria() != null ? mov.getCategoria().getNombreCategoria() : "Sin categoría")
                        .append("\nTipo: ").append(mov instanceof Ingreso ? "Ingreso" : "Gasto")
                        .append("\n-----------------------\n");
            }
        }
        return texto.toString();
    }
    public String inicializarMovimientos() {
        StringBuilder resultado = new StringBuilder();
        try {
            Movimiento ingresoEjemplo = new Ingreso("Sueldo mensual", 1200.0, new SimpleDateFormat("dd/MM/yyyy").parse("01/07/2025"), empresa.buscarCategoriaPorNombre("Salario"));
            movimientos.add(ingresoEjemplo);
            resultado.append("Movimiento agregado para prueba: ").append(ingresoEjemplo.getDescripcion()).append("\n");
        } catch (Exception e) {
            resultado.append("Error al inicializar movimientos: ").append(e.getMessage());
        }
        return resultado.toString();
    }
    //Valida si un movimiento ya existe en el arreglo de movimientos.
    public boolean validarDuplicado(double monto, Date fecha) {
        if (fecha == null) return false;

        for (Movimiento actual : movimientos) {
            if (actual != null &&
                    Double.compare(actual.getMonto(), monto) == 0 &&
                    actual.getFecha().equals(fecha)) {
                return true; // Duplicado encontrado
            }
        }
        return false; // No hay duplicados
    }
    /**
     * Agrega un nuevo objetivo financiero al presupuesto.
     * @param objetivo Objetivo financiero a agregar.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(ObjetivoFinanciero objetivo) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        if (objetivo == null) {
            throw new ExcepcionMifo.ObjetivoDuplicadoExcepcion("El objetivo no puede ser nulo.");
        }
        if (validarDuplicado(objetivo)) {
            throw new ExcepcionMifo.ObjetivoDuplicadoExcepcion("El objetivo financiero ya existe.");
        }
        objetivos.add(objetivo);
        listaObjetivos.add(objetivo);  // Agregar también aquí

        return "Objetivo agregado: " + objetivo.getDescripcion() +
                ", Monto: " + objetivo.getMonto();
    }

    /**
     * Agrega un objetivo financiero con descripción y monto, usando la fecha actual y categoría nula.
     *
     * @param descripcion Descripción del objetivo.
     * @param monto Monto del objetivo.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(String descripcion, double monto) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        ObjetivoFinanciero nuevoObjetivo = new ObjetivoFinanciero(descripcion, monto, new Date(), null);
        return agregarObjetivoFinanciero(nuevoObjetivo);
    }
    public String agregarObjetivoFinanciero(String descripcion, double monto, String fechaStr, Categoria categoria) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha = null;
        try {
            fecha = sdf.parse(fechaStr);
        } catch (ParseException e) {
            e.printStackTrace();
            // Puedes manejar el error o poner una fecha por defecto:
            fecha = new Date();
        }
        return agregarObjetivoFinanciero(descripcion, monto, fecha, categoria);
    }

    /**
     * Agrega un objetivo financiero con descripción, monto y categoría, usando la fecha actual.
     *
     * @param descripcion Descripción del objetivo.
     * @param monto Monto del objetivo.
     * @param categoria Categoría del objetivo.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(String descripcion, double monto, Categoria categoria) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        ObjetivoFinanciero nuevoObjetivo = new ObjetivoFinanciero(descripcion, monto, new Date(), categoria);
        return agregarObjetivoFinanciero(nuevoObjetivo);
    }


    /**
     * Crea y agrega un objetivo financiero a partir de parámetros simples.
     *
     * @param descripcion Descripción del objetivo.
     * @param monto Monto objetivo.
     * @param fecha Fecha objetivo (puedes sobrecargar para fecha opcional).
     * @param categoria Categoría del objetivo.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.ObjetivoDuplicadoExcepcion Si el objetivo ya existe.
     */
    public String agregarObjetivoFinanciero(String descripcion, double monto, Date fecha, Categoria categoria) throws ExcepcionMifo.ObjetivoDuplicadoExcepcion {
        ObjetivoFinanciero nuevoObjetivo = new ObjetivoFinanciero(descripcion, monto, fecha, categoria);
        return agregarObjetivoFinanciero(nuevoObjetivo);
    }

    /**
     * Edita un objetivo financiero existente.
     * @param indice Índice del objetivo a editar.
     * @param nuevo Nuevo objeto de objetivo financiero.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice es inválido.
     */
    public void editarObjetivoFinanciero(int indice, ObjetivoFinanciero nuevo) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (nuevo == null) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("El objetivo proporcionado no puede ser nulo.");
        }
        if (indice < 0 || indice >= objetivos.size()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("Índice inválido para editar objetivo.");
        }
        objetivos.set(indice, nuevo);
    }

    /**
     * Edita un objetivo financiero directamente con nuevos datos, asignando fecha actual.
     *
     * @param indice Índice del objetivo a editar.
     * @param descripcion Nueva descripción.
     * @param monto Nuevo monto.
     * @param categoria Nueva categoría.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice no es válido.
     */
    public void editarObjetivoFinanciero(int indice, String descripcion, double monto, Categoria categoria) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        ObjetivoFinanciero nuevo = new ObjetivoFinanciero(descripcion, monto, new Date(), categoria);
        editarObjetivoFinanciero(indice, nuevo);
    }
    /**
     * Edita un objetivo financiero buscándolo por su descripción.
     *
     * @param descripcion Descripción del objetivo a editar.
     * @param nuevo Nuevo objeto objetivo financiero.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si no se encuentra el objetivo.
     */
    public void editarObjetivoFinanciero(String descripcion, ObjetivoFinanciero nuevo) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("La descripción no puede estar vacía.");
        }

        for (int i = 0; i < objetivos.size(); i++) {
            ObjetivoFinanciero actual = objetivos.get(i);
            if (actual.getDescripcion().equalsIgnoreCase(descripcion)) {
                objetivos.set(i, nuevo);
                return;
            }
        }
        throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("No se encontró un objetivo con la descripción dada.");
    }

    /**
     * Edita un objetivo financiero buscado por descripción, actualizando monto y categoría.
     * Usa la fecha actual.
     *
     * @param descripcion Descripción del objetivo a editar.
     * @param nuevoMonto Nuevo monto.
     * @param nuevaCategoria Nueva categoría.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si no se encuentra el objetivo.
     */
    public void editarObjetivoFinanciero(String descripcion, double nuevoMonto, Categoria nuevaCategoria) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        ObjetivoFinanciero nuevo = new ObjetivoFinanciero(descripcion, nuevoMonto, new Date(), nuevaCategoria);
        editarObjetivoFinanciero(descripcion, nuevo);
    }


    /**
     * Elimina un objetivo financiero por índice.
     * @param indice Índice del objetivo a eliminar.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice no es válido.
     */
    public void eliminarObjetivoFinanciero(int indice) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (indice < 0 || indice >= objetivos.size()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("Índice inválido para eliminar objetivo.");
        }

        objetivos.remove(indice);
    }

    /**
     * Elimina un objetivo financiero buscándolo por su descripción.
     *
     * @param descripcion Descripción del objetivo a eliminar.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si no se encuentra el objetivo.
     */
    public void eliminarObjetivoFinanciero(String descripcion) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("La descripción no puede estar vacía.");
        }
        for (int i = 0; i < objetivos.size(); i++) {
            ObjetivoFinanciero objetivo = objetivos.get(i);
            if (objetivo.getDescripcion().equalsIgnoreCase(descripcion)) {
                objetivos.remove(i);
                return;
            }
        }

        throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("No se encontró un objetivo con la descripción dada.");
    }

    /**
     * Elimina un objetivo financiero por objeto.
     *
     * @param objetivo Objetivo financiero a eliminar.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el objetivo no se encuentra.
     */
    public void eliminarObjetivoFinanciero(ObjetivoFinanciero objetivo) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (objetivo == null) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("El objetivo a eliminar no puede ser nulo.");
        }
        int indice = objetivos.indexOf(objetivo);
        if (indice == -1) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("No se encontró el objetivo financiero para eliminar.");
        }
        objetivos.remove(indice);
    }

    /**
     * Consulta un objetivo por índice.
     * @param indice Índice del objetivo.
     * @return Cadena con la información del objetivo.
     * @throws ExcepcionMifo.ObjetivoInvalidoExcepcion Si el índice no es válido.
     */
    public String consultarObjetivoFinanciero(int indice) throws ExcepcionMifo.ObjetivoInvalidoExcepcion {
        if (indice < 0 || indice >= objetivos.size()) {
            throw new ExcepcionMifo.ObjetivoInvalidoExcepcion("Índice inválido para consultar objetivo.");
        }

        ObjetivoFinanciero obj = objetivos.get(indice);

        return "Descripción: " + obj.getDescripcion() +
                "\nMonto: " + obj.getMonto() +
                "\nFecha: " + obj.getFecha() +
                "\nCategoría: " + (obj.getCategoria() != null
                ? obj.getCategoria().getNombreCategoria()
                : "Sin categoría");
    }


    /**
     * Consulta todos los objetivos financieros del presupuesto.
     * @return Cadena con todos los objetivos.
     */
    public String consultarObjetivos() {
        if (objetivos.isEmpty()) {
            return "No hay objetivos financieros registrados.";
        }

        StringBuilder resultado = new StringBuilder("Objetivos financieros:\n");
        for (ObjetivoFinanciero objetivo : objetivos) {
            resultado.append("- ").append(objetivo.getDescripcion())
                    .append(": $").append(objetivo.getMonto())
                    .append("\n");
        }
        return resultado.toString();
    }


    /**
     * Consulta un objetivo financiero buscándolo por su descripción.
     *
     * @param descripcion Descripción del objetivo.
     * @return Texto con la información del objetivo o mensaje de no encontrado.
     */
    public String consultarObjetivoFinanciero(String descripcion) {
        if (descripcion == null || descripcion.trim().isEmpty()) {
            return "La descripción no puede estar vacía.";
        }
        for (ObjetivoFinanciero obj : objetivos) {
            if (obj != null && obj.getDescripcion().equalsIgnoreCase(descripcion)) {
                return "Descripción: " + obj.getDescripcion() +
                        "\nMonto: " + obj.getMonto() +
                        "\nFecha: " + obj.getFecha() +
                        "\nCategoría: " + (obj.getCategoria() != null ? obj.getCategoria().getNombreCategoria() : "Sin categoría");
            }
        }
        return "No se encontró un objetivo con la descripción: " + descripcion;
    }

    public void inicializarObjetivos() {
        this.objetivos = new ArrayList<>();
        try {
            Categoria viajes = new Categoria("Viajes", TipoMovimiento.GASTO);
            Categoria tecnologia = new Categoria("Tecnología", TipoMovimiento.GASTO);
            Categoria educacion = new Categoria("Educación", TipoMovimiento.GASTO);
            Categoria hogar = new Categoria("Hogar", TipoMovimiento.GASTO);
            Categoria transporte = new Categoria("Transporte", TipoMovimiento.GASTO);

            listaObjetivos.add(new ObjetivoFinanciero("Vacaciones en verano", 1200.0, "10/08/2025", viajes));
            listaObjetivos.add(new ObjetivoFinanciero("Nuevo celular", 800.0, "05/09/2025", tecnologia));
            listaObjetivos.add(new ObjetivoFinanciero("Curso Java avanzado", 450.0, "15/10/2025", educacion));
            listaObjetivos.add(new ObjetivoFinanciero("Reparación del hogar", 700.0, "30/11/2025", hogar));
            listaObjetivos.add(new ObjetivoFinanciero("Pasajes internacionales", 1500.0, "01/12/2025", transporte));

        } catch (Exception e) {
            System.out.println("Error inicializando objetivos: " + e.getMessage());
        }
    }

    /**
     * Valida si un objetivo ya existe en el arreglo de objetivos financieros.
     * @param obj Objetivo a verificar.
     * @return true si ya existe, false si no.
     */
    public boolean validarDuplicado(ObjetivoFinanciero obj) {
        for (ObjetivoFinanciero o : getObjetivos()) {
            if (o != null && o.equals(obj)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Devuelve los objetivos actuales como un arreglo seguro.
     * @return Arreglo de objetivos registrados.
     */
    public List<ObjetivoFinanciero> getObjetivos() {
        return Collections.unmodifiableList(objetivos);
    }
    @Override
    public String toString() {
        return String.format(
                "Presupuesto:\n" +
                        "\tMonto Presupuesto:      %.2f\n" +
                        "\tFecha:                 %s\n" +
                        "\tGasto Total:           %.2f\n" +
                        "\tIngreso Total:         %.2f\n" +
                        "\tNúmero de movimientos: %d\n" +
                        "\tTipo:                  %s",
                montoPresupuesto,
                fecha,
                gastoTotal,
                ingresoTotal,
                tipo
        );
    }
    @Override
    public boolean equals(Object o) {
        boolean result = false;
        if (o != null && o instanceof Presupuesto) {
            Presupuesto p = (Presupuesto) o;
            if (Double.compare(this.montoPresupuesto, p.montoPresupuesto) == 0 &&
                    ((this.fecha == null && p.fecha == null) ||
                            (this.fecha != null && this.fecha.equals(p.fecha)))) {
                result = true;
            }
        }
        return result;
    }
    @Override
    public String nuevo(Object obj) {
        if (obj instanceof ObjetivoFinanciero) {
            try {
                ObjetivoFinanciero objetivo = (ObjetivoFinanciero) obj;
                return agregarObjetivoFinanciero(objetivo);
            } catch (Exception e) {
                return "Error al agregar objetivo financiero: " + e.getMessage();
            }
        }
        return "Tipo de objeto no válido para agregar en Presupuesto.";
    }


    @Override
    public String editar(Object obj) {
        if (obj instanceof ObjetivoFinanciero objetivoEditado) {
            int indice = objetivos.indexOf(objetivoEditado);
            if (indice != -1) {
                objetivos.set(indice, objetivoEditado);
                return "Objetivo financiero editado correctamente.";
            }
            return "Objetivo financiero no encontrado.";
        }
        return "Tipo de objeto no válido para editar.";
    }
    @Override
    public String borrar(Object obj) {
        if (obj instanceof ObjetivoFinanciero objetivo) {
            try {
                eliminarObjetivoFinanciero(objetivo);  // método que lanza excepción
                return "Objetivo eliminado correctamente.";
            } catch (ExcepcionMifo.ObjetivoInvalidoExcepcion e) {
                return "Error al eliminar objetivo: " + e.getMessage();
            }
        }
        return "Tipo de objeto no válido para eliminar.";
    }
    @Override
    public Object buscarPorId(Integer id) {
        for (ObjetivoFinanciero o : objetivos) {
            if (o != null && o.getCodigo() == id) {
                return o;
            }
        }
        return null;
    }

    @Override
    public String listar() {
        StringBuilder sb = new StringBuilder("Objetivos Financieros:\n");
        for (ObjetivoFinanciero o : objetivos) {
            if (o != null) sb.append(o).append("\n");
        }
        return sb.toString();
    }

}