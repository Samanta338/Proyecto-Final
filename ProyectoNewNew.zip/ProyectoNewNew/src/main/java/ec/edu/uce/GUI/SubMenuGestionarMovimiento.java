/**
 * Clase que representa el submenú para gestionar movimientos financieros en el sistema MIFO.
 * Permite a los usuarios crear, editar, consultar y eliminar movimientos.
 */
package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.*;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import ec.edu.uce.Dominio.TipoMovimiento;
public class SubMenuGestionarMovimiento {
    private final Scanner entrada;

    /**
     * Usuario autenticado que gestionará los movimientos.
     */
    private final Usuario usuario;
    /**
     * Constructor que inicializa el submenú con un usuario autenticado.
     *
     * @param usuario Instancia del usuario actual.
     */
    public SubMenuGestionarMovimiento(Usuario usuario) {
        this.entrada = new Scanner(System.in);
        this.usuario = usuario;
    }

    /**
     * Muestra el menú de gestión de movimientos y procesa la opción elegida por el usuario.
     *
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si ocurre un error en la gestión del movimiento.
     */
    public void menuGestionarMovimiento() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        int seleccion;
        do {
            mostrarMenuGestionarMovimiento();
            seleccion = ComprobacionMenu.validarOpcionMenu(entrada, 7);
            if (seleccion == 6) {
                System.out.println();
                System.out.println("Volviendo al menú principal...");
                break;
            }
            procesarOpcionGestionarMovimiento(seleccion);
        } while (seleccion != 7);
    }

    /**
     * Muestra las opciones disponibles en el submenú de gestión de movimientos.
     */
    private void mostrarMenuGestionarMovimiento() {
        System.out.println();
        System.out.println("╔═══════════════════════════════════════════════╗");
        System.out.println("║            Gestionar Movimiento               ║");
        System.out.println("╠═══════════════════════════════════════════════╣");
        System.out.println("║                                               ║");
        System.out.println("║  1. Crear Movimiento                          ║");
        System.out.println("║  2. Editar Movimiento                         ║");
        System.out.println("║  3. Eliminar Movimiento                       ║");
        System.out.println("║  4. Consultar Movimiento                      ║");
        System.out.println("║  5. Ordenar movimientos por monto descendente ║");
        System.out.println("║  6. Volver al menú principal                  ║");
        System.out.println("║  7. Salir del programa                        ║");
        System.out.println("║                                               ║");
        System.out.println("╚═══════════════════════════════════════════════╝");
        System.out.println();
        System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
    }
    /**
     * Procesa la opción elegida en el menú e invoca la funcionalidad correspondiente.
     *
     * @param seleccion Opción elegida por el usuario.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si ocurre un error en la gestión del movimiento.
     */
    private void procesarOpcionGestionarMovimiento(int seleccion) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        switch (seleccion) {
            case 1:
                crearMovimiento();
                break;
            case 2:
                editarMovimiento();
                break;
            case 3:
                eliminarMovimiento();
                break;
            case 4:
                consultarMovimiento();
                break;
            case 5:
                ordenarMovimientosPorMontoDescendente();
                break;
            case 6:
                System.out.println();
                System.out.println("Volviendo al menú principal...");
                return;
            case 7:
                System.out.println();
                System.out.println("╔══════════════════════════════════════════════════════════════╗");
                System.out.println("║                     Cerrando el sistema                      ║");
                System.out.println("╠══════════════════════════════════════════════════════════════╣");
                System.out.println("║                                                              ║");
                System.out.println("║     ¡Gracias por haber confiado en MIFO!                     ║");
                System.out.println("║                                                              ║");
                System.out.println("║   Esperamos que nuestra plataforma te haya sido de gran      ║");
                System.out.println("║                     ayuda en tus finanzas.                   ║");
                System.out.println("║                                                              ║");
                System.out.println("║              ¡Hasta la próxima!                              ║");
                System.out.println("║                                                              ║");
                System.out.println("╚══════════════════════════════════════════════════════════════╝");
                System.exit(0);
                break;
            default:
                System.out.println("Opción inválida. Intente nuevamente.");
                break;
        }
    }

    /**
     * Valida que la descripción ingresada por el usuario cumpla con los requisitos mínimos.
     *
     * @return Descripción validada del movimiento.
     */
    private String validarDescripcion() {
        String descripcion;
        while (true) {
            descripcion = entrada.nextLine().trim();
            // Verificar que no esté vacía
            if (descripcion.isEmpty()) {
                System.out.print("La descripción no puede estar vacía. Intente de nuevo: ");
                continue;
            }
            // Verificar que contenga solo letras y espacios
            if (!descripcion.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
                System.out.print("La descripción solo puede contener letras y espacios. Intente de nuevo: ");
                continue;
            }
            // Contar cuántas letras tiene
            int letras = 0;
            for (char c : descripcion.toCharArray()) {
                if (Character.isLetter(c)) {
                    letras++;
                }
            }

            if (letras < 5) {
                System.out.print("La descripción debe tener al menos 5 letras. Intente de nuevo: ");
                continue;
            }

            return descripcion;
        }
    }
    /**
     * Valida que el monto ingresado por el usuario sea un número positivo.
     *
     * @return Monto validado del movimiento.
     */
    private double validarMonto() {
        while (true) {
            try {
                String input = entrada.nextLine().trim();
                double monto = Double.parseDouble(input);
                if (monto <= 0) {
                    System.out.print("Error: El monto debe ser un número positivo. Intenta de nuevo: ");
                } else {
                    return monto;
                }
            } catch (NumberFormatException e) {
                System.out.print("Error: Debe ingresar un número válido. Intenta de nuevo: ");
            }
        }
    }

    /**
     * Valida y convierte la fecha ingresada por el usuario en el formato correcto.
     *
     * @return Fecha validada en formato `Date`.
     */
    private Date validarFecha() {
        Date fecha = null;
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        formato.setLenient(false);
        while (fecha == null) {
            String fechaStr = entrada.nextLine().trim();
            try {
                fecha = formato.parse(fechaStr);
            } catch (ParseException e) {
                System.out.print("Error: Fecha inválida, ingrese en formato dd/MM/yyyy: ");
            }
        }
        return fecha;
    }

    /**
     * Clase que representa el submenú para gestionar movimientos financieros en el sistema MIFO.
     * Permite a los usuarios crear, editar, consultar y eliminar movimientos dentro de presupuestos definidos.
     */
    private void crearMovimiento() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        List<Presupuesto> presupuestos = usuario.getPresupuestos();
        if (presupuestos.isEmpty()) {
            System.out.println("No hay presupuestos guardados. Por favor, cree un presupuesto primero.");
            return;
        }

        // Selección de presupuesto
        System.out.println("Seleccione el presupuesto para este movimiento:");
        for (int i = 0; i < presupuestos.size(); i++) {
            Presupuesto p = presupuestos.get(i);
            System.out.println((i + 1) + ") Presupuesto: " + p.getMontoPresupuesto() + ", Fecha: " + p.getFecha());
        }

        int presupuestoIndex = ComprobacionMenu.validarOpcionMenu(entrada, presupuestos.size()) - 1;
        Presupuesto presupuestoSeleccionado = presupuestos.get(presupuestoIndex);

        // Selección del tipo de movimiento
        System.out.println("****************************");
        System.out.println("Seleccione el tipo de movimiento:");
        TipoMovimiento[] tipos = TipoMovimiento.values();
        for (int i = 0; i < tipos.length; i++) {
            System.out.println((i + 1) + ". " + tipos[i].name());
        }
        int tipoSeleccionado = ComprobacionMenu.validarOpcionMenu(entrada, tipos.length);
        TipoMovimiento tipoMovimiento = tipos[tipoSeleccionado - 1];

        entrada.nextLine(); // limpiar buffer

        System.out.print("Ingrese la descripción: ");
        String descripcion = validarDescripcion();

        System.out.print("Ingrese el monto: ");
        double monto = validarMonto();

        System.out.print("Ingrese la fecha (dd/MM/yyyy): ");
        Date fecha = validarFecha();

        Categoria categoria = new Categoria(tipoMovimiento.name(), tipoMovimiento);
        Movimiento movimiento = (tipoMovimiento == TipoMovimiento.INGRESO)
                ? new Ingreso(descripcion, monto, fecha, categoria)
                : new Gasto(descripcion, monto, fecha, categoria);

        presupuestoSeleccionado.agregarMovimiento(movimiento);
        System.out.println("Movimiento creado con éxito: " + movimiento);
    }

    /**
     * Permite al usuario editar un movimiento existente dentro de un presupuesto seleccionado.
     *
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si ocurre un error en la edición del movimiento.
     */
    private void editarMovimiento() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        List<Presupuesto> presupuestos = usuario.getPresupuestos();
        if (presupuestos.isEmpty()) {
            System.out.println("No hay presupuestos guardados.");
            return;
        }

        // Selección de presupuesto
        System.out.println("Seleccione el presupuesto:");
        for (int i = 0; i < presupuestos.size(); i++) {
            System.out.println((i + 1) + ") Presupuesto: " + presupuestos.get(i).getMontoPresupuesto());
        }

        int presupuestoIndex = ComprobacionMenu.validarOpcionMenu(entrada, presupuestos.size()) - 1;
        Presupuesto presupuestoSeleccionado = presupuestos.get(presupuestoIndex);

        List<Movimiento> movimientos = presupuestoSeleccionado.getMovimientos();
        if (movimientos.isEmpty()) {
            System.out.println("No hay movimientos.");
            return;
        }

        mostrarMovimientos(movimientos);

        System.out.print("Ingrese el número del movimiento: ");
        int indice = ComprobacionMenu.validarOpcionMenu(entrada, movimientos.size()) - 1;

        entrada.nextLine();
        System.out.print("Nueva descripción: ");
        String descripcion = validarDescripcion();

        System.out.print("Nuevo monto: ");
        double monto = validarMonto();

        System.out.print("Nueva fecha (dd/MM/yyyy): ");
        Date fecha = validarFecha();

        Movimiento mov = movimientos.get(indice);
        mov.setDescripcion(descripcion);
        mov.setMonto(monto);
        mov.setFecha(fecha);

        System.out.println("Movimiento actualizado.");
    }


    /**
     * Elimina un movimiento seleccionado por el usuario dentro de un presupuesto.
     */
    private void eliminarMovimiento() {
        try {
            List<Presupuesto> presupuestos = usuario.getPresupuestos();
            if (presupuestos.isEmpty()) {
                System.out.println("No hay presupuestos.");
                return;
            }

            // Selección de presupuesto
            System.out.println("Seleccione el presupuesto:");
            for (int i = 0; i < presupuestos.size(); i++) {
                System.out.println((i + 1) + ") Presupuesto: " + presupuestos.get(i).getMontoPresupuesto());
            }

            int presupuestoIndex = ComprobacionMenu.validarOpcionMenu(entrada, presupuestos.size()) - 1;
            Presupuesto presupuestoSeleccionado = presupuestos.get(presupuestoIndex);

            List<Movimiento> movimientos = presupuestoSeleccionado.getMovimientos();
            if (movimientos.isEmpty()) {
                System.out.println("No hay movimientos.");
                return;
            }

            mostrarMovimientos(movimientos);
            System.out.print("Número del movimiento a eliminar: ");
            int indice = ComprobacionMenu.validarOpcionMenu(entrada, movimientos.size()) - 1;

            presupuestoSeleccionado.eliminarMovimiento(indice);
            System.out.println("Movimiento eliminado con éxito.");
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            Logger.getLogger(SubMenuGestionarMovimiento.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    private void consultarMovimiento() {
        List<Presupuesto> presupuestos = usuario.getPresupuestos();
        if (presupuestos.isEmpty()) {
            System.out.println("No hay presupuestos.");
            return;
        }

        System.out.println("Seleccione el presupuesto:");
        for (int i = 0; i < presupuestos.size(); i++) {
            System.out.println((i + 1) + ") Presupuesto: " + presupuestos.get(i).getMontoPresupuesto());
        }

        int presupuestoIndex = ComprobacionMenu.validarOpcionMenu(entrada, presupuestos.size()) - 1;
        Presupuesto presupuestoSeleccionado = presupuestos.get(presupuestoIndex);
        List<Movimiento> movimientos = presupuestoSeleccionado.getMovimientos();
        if (movimientos.isEmpty()) {
            presupuestoSeleccionado.inicializarMovimientos();
            movimientos = presupuestoSeleccionado.getMovimientos();
        }

        if (movimientos.isEmpty()) {
            System.out.println("No hay movimientos.");
            return;
        }
        mostrarMovimientos(movimientos);
    }


    /**
     * Muestra en pantalla una lista de movimientos dentro de un presupuesto.
     *
     * @param movimientos Arreglo de movimientos a mostrar.
     */
    private void mostrarMovimientos(List<Movimiento> movimientos) {
        for (int i = 0; i < movimientos.size(); i++) {
            Movimiento m = movimientos.get(i);

            System.out.println("┌─────────────────────────────────────────────────────────┐");
            System.out.printf("│ %2d. %-50s │%n", (i + 1),
                    (m instanceof Ingreso ? "INGRESO" : "GASTO"));
            System.out.println("├─────────────────────────────────────────────────────────┤");
            System.out.printf("│ Descripción: %-42s │%n", m.getDescripcion());
            System.out.printf("│ Monto:       $%-41.2f │%n", m.getMonto());
            System.out.printf("│ Fecha:       %-42s │%n", m.getFecha());
            System.out.printf("│ Categoría:   %-42s │%n",
                    (m.getCategoria() != null ? m.getCategoria().getNombreCategoria() : "Sin categoría"));
            System.out.printf("│ Código único: %-41s │%n", m.getCodigoUnico());
            System.out.println("└─────────────────────────────────────────────────────────┘");
            System.out.println();
        }
    }
    public void ordenarMovimientosPorMontoDescendente() {
        List<Presupuesto> presupuestos = usuario.getPresupuestos();
        if (presupuestos.isEmpty()) {
            System.out.println("No hay presupuestos.");
            return;
        }

        System.out.println("Seleccione el presupuesto para ordenar sus movimientos:");
        for (int i = 0; i < presupuestos.size(); i++) {
            System.out.println((i + 1) + ") Presupuesto: " + presupuestos.get(i).getMontoPresupuesto() +
                    ", Fecha: " + presupuestos.get(i).getFecha());
        }

        int opcion = ComprobacionMenu.validarOpcionMenu(entrada, presupuestos.size()) - 1;
        Presupuesto presupuestoSeleccionado = presupuestos.get(opcion);

        List<Movimiento> movimientos = new ArrayList<>(presupuestoSeleccionado.getMovimientos());

        if (movimientos.isEmpty()) {
            System.out.println("No hay movimientos para ordenar en este presupuesto.");
            return;
        }

        Collections.sort(movimientos, new OrdenarMovimientoPorMontoDescendente());

        System.out.println("Movimientos ordenados por monto (descendente):");
        for (Movimiento m : movimientos) {
            System.out.printf("Movimiento [Descripción=%s, Monto=%.2f, Fecha=%s]%n",
                    m.getDescripcion(), m.getMonto(), m.getFecha());
        }
    }

}
