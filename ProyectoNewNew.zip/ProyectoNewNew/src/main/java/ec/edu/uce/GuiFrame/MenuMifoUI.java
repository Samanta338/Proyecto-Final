package ec.edu.uce.GuiFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;


public class MenuMifoUI extends JFrame {
    // Paleta de colores - SOLO verdes cálidos y suaves + negro
    private static final Color SOFT_GREEN = new Color(162, 194, 152);     // Verde suave principal
    private static final Color SAGE_GREEN = new Color(134, 167, 123);     // Verde salvia para botones
    private static final Color MINT_CREAM = new Color(247, 250, 245);     // Crema menta para fondo
    private static final Color DARK_GREEN = new Color(85, 107, 47);       // Verde oscuro para hover
    private static final Color LIGHT_GREEN = new Color(198, 219, 191);    // Verde claro para header
    private static final Color FOREST_GREEN = new Color(46, 84, 48);      // Verde bosque para texto
    private static final Color BLACK = new Color(0, 0, 0);               // Negro

    private JPanel mainPanel;
    private JButton a1IngresarAlSistemaButton;
    private JButton a2GestionarPresupuestoButton;
    private JButton a3GestionarCategoriaButton;
    private JButton a4GestionarEducaciónFinancieraButton;
    private JButton a5GestionarObjetivosFinancierosButton;
    private JButton a6GestionarMovimientoButton;
    private JButton a7SalirDelProgramaButton;

    public MenuMifoUI() {
        setTitle("MIFO - Mis Finanzas Foráneas ");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Configuración responsive
        setMinimumSize(new Dimension(700, 400));      // Tamaño mínimo más ancho y menos alto
        setSize(900, 800);                           // Tamaño inicial más ancho y menos alto
        setLocationRelativeTo(null);
        setResizable(true);
        setLocationRelativeTo(null);
        setResizable(true);                       // PERMITE REDIMENSIONAR
        // Panel principal con fondo simple
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_CREAM);

        // Crear componentes
        JPanel headerPanel = createHeaderPanel();
        JPanel buttonPanel = createButtonPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        setContentPane(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(LIGHT_GREEN);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(35, 30, 35, 30));

        // Título principal
        JLabel mainTitle = new JLabel("MIFO", SwingConstants.CENTER);
        mainTitle.setFont(new Font("Arial", Font.BOLD, 36));
        mainTitle.setForeground(FOREST_GREEN);
        mainTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Subtítulo
        JLabel subtitle = new JLabel("Mis Finanzas Foráneas", SwingConstants.CENTER);
        subtitle.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitle.setForeground(DARK_GREEN);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(mainTitle);
        headerPanel.add(Box.createVerticalStrut(8));
        headerPanel.add(subtitle);

        return headerPanel;
    }

    private JPanel createButtonPanel() {
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.setBackground(MINT_CREAM);
        containerPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50)); // Más margen

        // Panel con GridBagLayout para mejor control responsive
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBackground(MINT_CREAM);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 10, 8, 10); // Espaciado entre botones
        gbc.weightx = 1.0; // Permite que los botones se expandan horizontalmente

        // URLs de iconos profesionales y serios para finanzas
        String[] iconUrls = {
                "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",    // Login profesional
                "https://cdn-icons-png.flaticon.com/512/2942/2942813.png",    // Budget/Calculator
                "https://cdn-icons-png.flaticon.com/512/1055/1055687.png",    // Categories/Folders
                "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",    // Education/Book
                "https://cdn-icons-png.flaticon.com/512/2942/2942832.png",    // Goals/Target
                "https://cdn-icons-png.flaticon.com/512/1055/1055645.png",    // Movements/Transfer
                "https://cdn-icons-png.flaticon.com/512/1828/1828490.png"     // Exit/Door
        };

        String[] buttonTexts = {
                "Ingresar al Sistema",
                "Gestionar Presupuesto",
                "Gestionar Categorías",
                "Educación Financiera",
                "Objetivos Financieros",
                "Gestionar Movimientos",
                "Salir del Programa"
        };

        // Crear botones con iconos desde internet
        a1IngresarAlSistemaButton = createStyledButton(buttonTexts[0], iconUrls[0]);
        a2GestionarPresupuestoButton = createStyledButton(buttonTexts[1], iconUrls[1]);
        a3GestionarCategoriaButton = createStyledButton(buttonTexts[2], iconUrls[2]);
        a3GestionarCategoriaButton.addActionListener(e -> {
            SubCategoriaUI subCategoriaUI = new SubCategoriaUI();
            subCategoriaUI.setVisible(true);
        });
        a4GestionarEducaciónFinancieraButton = createStyledButton(buttonTexts[3], iconUrls[3]);
        a4GestionarEducaciónFinancieraButton.addActionListener(e -> {
            SubEducacionUI subEducacionUIUI = new SubEducacionUI();
            subEducacionUIUI.setVisible(true);
        });
        a5GestionarObjetivosFinancierosButton = createStyledButton(buttonTexts[4], iconUrls[4]);
        a6GestionarMovimientoButton = createStyledButton(buttonTexts[5], iconUrls[5]);
        a6GestionarMovimientoButton.addActionListener(e -> {
            SubMovimientoUI subMovimientoUI = new SubMovimientoUI();
            subMovimientoUI.setVisible(true);
        });
        a7SalirDelProgramaButton = createStyledButton(buttonTexts[6], iconUrls[6]);
        a7SalirDelProgramaButton.addActionListener(e -> mostrarDialogoSalida());
        // Agregar botones con GridBagConstraints para responsive
        JButton[] buttons = {
                a1IngresarAlSistemaButton, a2GestionarPresupuestoButton, a3GestionarCategoriaButton,
                a4GestionarEducaciónFinancieraButton, a5GestionarObjetivosFinancierosButton,
                a6GestionarMovimientoButton, a7SalirDelProgramaButton
        };

        for (int i = 0; i < buttons.length; i++) {
            gbc.gridy = i;
            buttonPanel.add(buttons[i], gbc);
        }

        containerPanel.add(buttonPanel, BorderLayout.CENTER);
        return containerPanel;
    }
    private JButton createStyledButton(String text, String iconUrl) {
        JButton button = new JButton(text);

        // Cargar icono desde internet
        ImageIcon icon = loadIconFromURL(iconUrl, 20);
        if (icon != null) {
            button.setIcon(icon);
        }

        // Configuración del botón RESPONSIVE
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(SAGE_GREEN);
        button.setForeground(BLACK);  // TEXTO EN NEGRO
        button.setMinimumSize(new Dimension(300, 50));    // Tamaño mínimo
        button.setPreferredSize(new Dimension(500, 60));  // Tamaño preferido
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 2),
                BorderFactory.createEmptyBorder(15, 25, 15, 25)  // Más padding
        ));
        button.setIconTextGap(15);
        button.setOpaque(true);

        // Efectos hover con verdes
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(DARK_GREEN);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(SAGE_GREEN);
            }
        });

        return button;
    }

    // Método para cargar iconos desde URL de internet
    private ImageIcon loadIconFromURL(String iconUrl, int size) {
        try {
            System.out.println("Cargando icono desde: " + iconUrl);
            URL url = new URL(iconUrl);
            BufferedImage img = ImageIO.read(url);

            if (img != null) {
                Image scaledImg = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
                return new ImageIcon(scaledImg);
            }
        } catch (Exception e) {
            System.err.println("Error cargando icono: " + iconUrl);
            System.err.println("Error: " + e.getMessage());

            // Crear un icono simple como fallback
            BufferedImage fallbackImg = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = fallbackImg.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(FOREST_GREEN);
            g2d.fillOval(2, 2, size-4, size-4);
            g2d.dispose();
            return new ImageIcon(fallbackImg);
        }
        return null;
    }
    private void mostrarDialogoSalida() {
        int opcion = JOptionPane.showOptionDialog(this,
                "¡Gracias por haber confiado en MIFO!\n\n" +
                        "Esperamos que nuestra plataforma te haya sido de gran\n" +
                        "ayuda en tus finanzas.\n\n" +
                        "¡Hasta la próxima!",
                "Cerrando el sistema",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"Salir", "Cancelar"},
                "Salir");

        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
    public static void main(String[] args) {
        // Configurar look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            MenuMifoUI menu = new MenuMifoUI();
            menu.setVisible(true);
        });
    }

    // Getters para los botones
    public JButton getA1IngresarAlSistemaButton() { return a1IngresarAlSistemaButton; }
    public JButton getA2GestionarPresupuestoButton() { return a2GestionarPresupuestoButton; }
    public JButton getA3GestionarCategoriaButton() { return a3GestionarCategoriaButton; }
    public JButton getA4GestionarEducaciónFinancieraButton() { return a4GestionarEducaciónFinancieraButton; }
    public JButton getA5GestionarObjetivosFinancierosButton() { return a5GestionarObjetivosFinancierosButton; }
    public JButton getA6GestionarMovimientoButton() { return a6GestionarMovimientoButton; }
    public JButton getA7SalirDelProgramaButton() { return a7SalirDelProgramaButton; }
}