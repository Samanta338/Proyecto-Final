/**
 * Clase que representa el submenú para gestionar objetivos financieros en el sistema MIFO.
 * Permite crear, editar, eliminar y consultar objetivos financieros dentro de la aplicación.
 */
package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.*;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import java.text.SimpleDateFormat;
import java.util.*;
public class SubMenuGestionarObjetivosFinancieros {
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    private Scanner entrada = new Scanner(System.in);
    private Usuario usuario;

    public SubMenuGestionarObjetivosFinancieros(Usuario usuario) {
        this.usuario = usuario;
    }
    /**
     * Arreglo que almacena los objetivos financieros registrados en el sistema.
     */
    private static List<ObjetivoFinanciero> objetivosTotales = new ArrayList<>();
    /**
     * Instancia de la empresa que administra los objetivos financieros.
     */
    private Empresa empresa = Empresa.getInstance();
    /**
     * Contador de objetivos financieros almacenados en el sistema.
     */
    private static int objetivoCount = 0;

    /**
     * Instancia del submenú de categorías para gestionar categorías.
     */
    private SubMenuGestionarCategoria subMenuCategoria = new SubMenuGestionarCategoria();

    /**
     * Muestra el menú de gestión de objetivos financieros y procesa la opción elegida por el usuario.
     */
    public void menuGestionarObjetivosFinancieros() {
        int seleccion;
        do {
            mostrarMenuGestionarObjetivosFinancieros();
            seleccion = ComprobacionMenu.validarOpcionMenu(entrada, 7);
            try {
                procesarOpcionGestionarObjetivosFinancieros(seleccion);
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (seleccion != 5 && seleccion != 6);
    }

    /**
     * Muestra las opciones disponibles en el submenú de gestión de objetivos financieros.
     */
    private void mostrarMenuGestionarObjetivosFinancieros() {
        System.out.println();
        System.out.println("╔═══════════════════════════════════════════════╗");
        System.out.println("║        Gestionar Objetivos Financieros        ║");
        System.out.println("╠═══════════════════════════════════════════════╣");
        System.out.println("║                                               ║");
        System.out.println("║  1. Crear Objetivos Financieros               ║");
        System.out.println("║  2. Editar Objetivos Financieros              ║");
        System.out.println("║  3. Eliminar Objetivos Financieros            ║");
        System.out.println("║  4. Consultar Objetivos Financieros           ║");
        System.out.println("║  5. Ordenar objetivos por monto               ║");
        System.out.println("║  6. Volver al menú principal                  ║");
        System.out.println("║  7. Salir del programa                        ║");
        System.out.println("║                                               ║");
        System.out.println("╚═══════════════════════════════════════════════╝");
        System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
    }
    /**
     * Procesa la opción elegida en el menú e invoca la funcionalidad correspondiente.
     *
     * @param seleccion Opción elegida por el usuario.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si se produce un error en la gestión de objetivos financieros.
     */
    private void procesarOpcionGestionarObjetivosFinancieros(int seleccion) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        switch (seleccion) {
            case 1:
                crearObjetivoFinanciero();
                break;
            case 2:
                editarObjetivoFinanciero();
                break;
            case 3:
                eliminarObjetivoFinanciero();
                break;
            case 4:
                consultarObjetivosFinancieros();
                break;
            case 5:
                ordenarObjetivosPorMontoAscendente();
                break;
            case 6:
                System.out.println();
                System.out.println("Volviendo al menú principal...");
                return;
            case 7:
                System.out.println();
                System.out.println("╔══════════════════════════════════════════════════════════════╗");
                System.out.println("║                     Cerrando el sistema                      ║");
                System.out.println("╠══════════════════════════════════════════════════════════════╣");
                System.out.println("║                                                              ║");
                System.out.println("║     ¡Gracias por haber confiado en MIFO!                     ║");
                System.out.println("║                                                              ║");
                System.out.println("║   Esperamos que nuestra plataforma te haya sido de gran      ║");
                System.out.println("║                     ayuda en tus finanzas.                   ║");
                System.out.println("║                                                              ║");
                System.out.println("║              ¡Hasta la próxima!                              ║");
                System.out.println("║                                                              ║");
                System.out.println("╚══════════════════════════════════════════════════════════════╝");
                System.exit(0);
                break;
            default:
                System.out.println("Opción no válida, por favor intente de nuevo.");
        }
    }

    /**
     * CRUD: Crear objetivo financiero
     * Crea un nuevo objetivo financiero verificando la validez de los datos ingresados.
     */
    private void crearObjetivoFinanciero() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        System.out.println(" --------------------------------------------------------");

        String descripcion;
        while (true) {
            System.out.print(" | Ingrese la descripción del objetivo financiero: ");
            descripcion = entrada.nextLine().trim();
            if (ComprobacionMenu.validarDescripcion(descripcion)) {
                if (buscarObjetivoPorDescripcion(descripcion) == null) {
                    break;
                } else {
                    System.out.println("Error: Ya existe un objetivo con esa descripción. Intente con otra.");
                }
            }
        }

        Double monto;
        while (true) {
            System.out.print(" | Ingrese el monto del objetivo financiero: ");
            String montoStr = entrada.nextLine();
            monto = ComprobacionMenu.validarMonto(montoStr);
            if (monto != null && monto > 0) {
                break;
            }
        }
        Date fecha;
        while (true) {
            System.out.print(" | Ingrese la fecha del objetivo financiero (dia/mes/año): ");
            String fechaStr = entrada.nextLine();
            fecha = ComprobacionMenu.validarFecha(fechaStr);
            if (fecha != null) {
                break;
            }
            System.out.println("Fecha inválida. Ingrese la fecha en formato correcto.");
        }

        Categoria categoria = pedirCategoriaExistente();

        // Agregar objetivo usando el método dedicado
        agregarObjetivoFinanciero(descripcion, monto, fecha, categoria);
    }

    /**
     * Agrega un objetivo financiero al sistema con redimensionamiento dinámico del arreglo.
     *
     * @param descripcion Descripción del objetivo financiero
     * @param monto Monto del objetivo financiero
     * @param fecha Fecha del objetivo financiero
     * @param categoria Categoría del objetivo financiero
     */
    public void agregarObjetivoFinanciero(String descripcion, Double monto, Date fecha, Categoria categoria) {
        // Validaciones iniciales
        if (descripcion == null || descripcion.trim().isEmpty()) {
            System.out.println(" Error: La descripción del objetivo no puede estar vacía.");
            return;
        }
        if (monto == null || monto <= 0) {
            System.out.println(" Error: El monto debe ser mayor a 0.");
            return;
        }
        if (fecha == null) {
            System.out.println(" Error: La fecha no puede ser nula.");
            return;
        }
        if (categoria == null) {
            System.out.println(" Error: La categoría no puede ser nula.");
            return;
        }

        // Verificar si ya existe un objetivo con la misma descripción
        if (buscarObjetivoPorDescripcion(descripcion) != null) {
            System.out.println(" Error: Ya existe un objetivo con esa descripción.");
            return;
        }
        ObjetivoFinanciero objetivo = new ObjetivoFinanciero(descripcion, monto, fecha, categoria);
        objetivosTotales.add(objetivo);
        List<Presupuesto> presupuestos = usuario.getPresupuestos();
        if (presupuestos != null && !presupuestos.isEmpty()) {
            Presupuesto presupuesto = presupuestos.get(0);
            presupuesto.getListaObjetivos().add(objetivo);
            System.out.println(" Objetivo asociado al presupuesto con éxito.");
        } else {
            System.out.println(" No hay presupuestos disponibles para asociar el objetivo.");
        }

        System.out.println(" Objetivo financiero creado exitosamente.");
    }


    /**
     * Agrega un objetivo financiero existente al sistema.
     *
     * @param objetivo Objetivo financiero a agregar
     */


    /**
     * CRUD: Editar objetivo financiero
     * Edita un objetivo financiero existente verificando su validez y permitiendo cambios en sus datos.
     */
    private void editarObjetivoFinanciero() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (objetivoCount == 0) {
            System.out.println("No hay objetivos financieros registrados.");
            return;
        }

        System.out.print(" | Ingrese la descripción del objetivo financiero que desea editar: ");
        String descripcionAntigua = entrada.nextLine().trim();

        int indiceObjetivo = buscarIndicePorDescripcion(descripcionAntigua);
        if (indiceObjetivo == -1) {
            System.out.println("No se encontró ningún objetivo financiero con la descripción especificada.");
            return;
        }

        String nuevaDescripcion;
        while (true) {
            System.out.print(" | Ingrese la nueva descripción: ");
            nuevaDescripcion = entrada.nextLine().trim();
            if (ComprobacionMenu.validarDescripcion(nuevaDescripcion)) {
                if (buscarObjetivoPorDescripcion(nuevaDescripcion) == null || nuevaDescripcion.equalsIgnoreCase(descripcionAntigua)) {
                    break;
                } else {
                    System.out.println("Ya existe otro objetivo con esa descripción.");
                }
            } else {
                System.out.println("La descripción no puede estar vacía.");
            }
        }

        Double nuevoMonto;
        while (true) {
            System.out.print(" | Ingrese el nuevo monto: ");
            String montoStr = entrada.nextLine();
            nuevoMonto = ComprobacionMenu.validarMonto(montoStr);
            if (nuevoMonto != null && nuevoMonto > 0) {
                break;
            }
            System.out.println("Monto inválido. Debe ser mayor a 0.");
        }

        Date nuevaFecha;
        while (true) {
            System.out.print(" | Ingrese la nueva fecha (dia/mes/año): ");
            String fechaStr = entrada.nextLine();
            nuevaFecha = ComprobacionMenu.validarFecha(fechaStr);
            if (nuevaFecha != null) {
                break;
            }
            System.out.println("Fecha inválida.");
        }

        Categoria nuevaCategoria = pedirCategoriaExistente();

        // Crear nuevo objetivo y editarlo
        ObjetivoFinanciero nuevoObjetivo = new ObjetivoFinanciero(nuevaDescripcion, nuevoMonto, nuevaFecha, nuevaCategoria);
        editarObjetivoFinanciero(indiceObjetivo, nuevoObjetivo);
    }

    /**
     * Edita los datos de un objetivo financiero existente.
     *
     * @param indice Índice del objetivo a editar
     * @param objetivo Nuevo objetivo con los datos actualizados
     */
    public void editarObjetivoFinanciero(int indice, ObjetivoFinanciero objetivo) {
        if (indice >= 0 && indice < objetivosTotales.size()) {
            objetivosTotales.set(indice, objetivo);
            System.out.println("-> Objetivo financiero editado exitosamente.");
        } else {
            System.out.println("Índice inválido para editar objetivo financiero.");
        }
    }
     /* CRUD: Eliminar objetivo financiero
     * Elimina un objetivo financiero existente del sistema.
     */
    private void eliminarObjetivoFinanciero() {
        if (objetivoCount == 0) {
            System.out.println("No hay objetivos financieros registrados.");
            return;
        }

        System.out.print(" | Ingrese la descripción del objetivo a eliminar: ");
        String descripcion = entrada.nextLine().trim();

        int indiceEliminar = buscarIndicePorDescripcion(descripcion);
        if (indiceEliminar == -1) {
            System.out.println("No se encontró ningún objetivo con esa descripción.");
            return;
        }

        eliminarObjetivoFinanciero(indiceEliminar);
    }

    /**
     * Elimina un objetivo financiero por índice.
     *
     * @param indice Índice del objetivo a eliminar
     */
    public void eliminarObjetivoFinanciero(int indice) {
        if (indice >= 0 && indice < objetivosTotales.size()) {
            objetivosTotales.remove(indice);
            System.out.println(" -> Objetivo financiero eliminado exitosamente.");
        } else {
            System.out.println("Índice inválido para eliminar objetivo financiero.");
        }
    }
    /**
     * CRUD: Consultar objetivo financiero
     * Consulta y muestra en pantalla la información de un objetivo financiero existente.
     */
    private void consultarObjetivoFinanciero() {
        if (objetivoCount == 0) {
            System.out.println("No hay objetivos financieros registrados.");
            return;
        }

        System.out.print(" | Ingrese la descripción del objetivo que desea consultar: ");
        String descripcion = entrada.nextLine().trim();

        ObjetivoFinanciero objetivoConsulta = buscarObjetivoPorDescripcion(descripcion);
        if (objetivoConsulta == null) {
            System.out.println("No se encontró ningún objetivo con esa descripción.");
            return;
        }

        System.out.println("Información del objetivo financiero:");
        System.out.println("Descripción: " + objetivoConsulta.getDescripcion());
        System.out.println("Monto: $" + objetivoConsulta.getMonto());
        System.out.println("Fecha: " + dateFormat.format(objetivoConsulta.getFecha()));
        System.out.println("Categoría: " + objetivoConsulta.getCategoria().getNombreCategoria());
    }
    /**
     * Consulta todos los objetivos financieros del sistema.
     *
     * @return Cadena con información de los objetivos financieros
     */
    public void consultarObjetivosFinancieros() {
        if (objetivosTotales.isEmpty()) {
            System.out.println("No hay objetivos financieros registrados.");
            return;
        }
        System.out.println("\n╔═══════════════════════════════════════════════════════════════╗");
        System.out.println("║                    OBJETIVOS FINANCIEROS                      ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════╝");

        int i = 1;
        for (ObjetivoFinanciero obj : objetivosTotales) {
            System.out.printf("Objetivo #%d%n", i++);
            System.out.printf("Descripción: %s%n", obj.getDescripcion());
            System.out.printf("Monto: $%.2f%n", obj.getMonto());
            System.out.printf("Fecha: %s%n", dateFormat.format(obj.getFecha()));
            System.out.printf("Categoría: %s%n", obj.getCategoria().getNombreCategoria());
            System.out.println("----------------------------------------------------------");
        }
    }

    /**
     * Busca un objetivo financiero por descripción dentro del arreglo.
     *
     * @param descripcion Descripción del objetivo a buscar.
     * @return El objetivo encontrado o null si no existe.
     */
    public ObjetivoFinanciero buscarObjetivoPorDescripcion(String descripcion) {
        for (ObjetivoFinanciero objetivo : objetivosTotales) {
            if (objetivo.getDescripcion().equalsIgnoreCase(descripcion)) {
                return objetivo;
            }
        }
        return null;
    }
    /**
     * Busca el índice de un objetivo financiero por su descripción.
     *
     * @param descripcion Descripción del objetivo a buscar
     * @return Índice del objetivo o -1 si no se encuentra
     */
    private int buscarIndicePorDescripcion(String descripcion) {
        for (int i = 0; i < objetivosTotales.size(); i++) {
            if (objetivosTotales.get(i).getDescripcion().equalsIgnoreCase(descripcion)) {
                return i;
            }
        }
        return -1;
    }
    /**
     * Solicita al usuario que ingrese el nombre de una categoría ya creada previamente.
     * Muestra las categorías disponibles y sólo acepta una categoría existente.
     *
     * @return La categoría seleccionada por el usuario.
     */
    private Categoria pedirCategoriaExistente() {
        while (true) {
            // Mostrar las categorías disponibles
            subMenuCategoria.mostrarCategoriasDisponibles();

            System.out.print("Ingrese el nombre exacto de la categoría que desea seleccionar: ");
            String nombreCategoria = entrada.nextLine().trim();

            // Buscar la categoría en el arreglo
            Categoria categoria = subMenuCategoria.buscarCategoriaPorNombreCategoria(nombreCategoria);

            if (categoria != null) {
                return categoria; // categoría válida seleccionada
            } else {
                System.out.println("Categoría no encontrada. Por favor, ingrese un nombre válido.");
            }
        }
    }
    public void ordenarObjetivosPorMontoAscendente() {
        if (objetivosTotales.isEmpty()) {
            System.out.println("No hay objetivos financieros para ordenar.");
            return;
        }
        objetivosTotales.sort(new OrdenarObjetivoPorMonto());

        System.out.println("Objetivos financieros ordenados por monto (ascendente):");
        for (ObjetivoFinanciero obj : objetivosTotales) {
            System.out.printf("Descripción: %s, Monto: $%.2f, Fecha: %s, Categoría: %s%n",
                    obj.getDescripcion(), obj.getMonto(),
                    dateFormat.format(obj.getFecha()),
                    obj.getCategoria().getNombreCategoria());
        }
    }

}