package ec.edu.uce.Dominio;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class ObjetivoFinanciero implements Comparable<ObjetivoFinanciero>  {
    private String descripcion;
    private Double monto;
    private Date fecha;
    private Categoria categoria;
    private static int contadorCodigo = 0;
    private final int codigo;
    // Bloque de inicialización de instancia
    {
        this.codigo = ++contadorCodigo;
    }
    // 1 Constructor por defecto
    public ObjetivoFinanciero() {
        this.descripcion = "Sin descripcion";
        this.monto = 0.0;
        this.fecha = new Date();
        this.categoria = new Categoria();
    }
    // 2 Constructor con parámetros
    public ObjetivoFinanciero(String descripcion, double monto, Date fecha, Categoria categoria) {
        this.descripcion = descripcion;
        this.monto = monto;
        this.fecha = fecha;
        this.categoria = categoria;
    }
    // 3 Constructor con descripción y monto, fecha actual, categoría por defecto
    public ObjetivoFinanciero(String descripcion, double monto) {
        this(descripcion, monto, new Date(), new Categoria());
    }

    // 4 Constructor con descripción, monto y fecha, categoría por defecto
    public ObjetivoFinanciero(String descripcion, double monto, Date fecha) {
        this(descripcion, monto, fecha, new Categoria());
    }
    // 5 Constructor con descripción y categoría, monto 0.0, fecha actual
    public ObjetivoFinanciero(String descripcion, Categoria categoria) {
        this(descripcion, 0.0, new Date(), categoria);
    }

    // 6 Constructor con monto y categoría, descripción por defecto, fecha actual
    public ObjetivoFinanciero(double monto, Categoria categoria) {
        this("Sin descripcion", monto, new Date(), categoria);
    }
    public ObjetivoFinanciero(String descripcion, double monto, String fechaStr, Categoria categoria) {
        this.descripcion = descripcion;
        this.monto = monto;
        this.fecha = convertirFecha(fechaStr);
        this.categoria = categoria;
    }
    private Date convertirFecha(String fechaStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            return sdf.parse(fechaStr);
        } catch (ParseException e) {
            e.printStackTrace();
            return new Date(); // fecha por defecto si hay error
        }
    }

    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getMonto() {
        return monto;
    }
    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Date getFecha() {
        return fecha;
    }
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Categoria getCategoria() {
        return categoria;
    }
    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;

    }
    public int getCodigo() {
        return codigo;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ObjetivoFinanciero otro = (ObjetivoFinanciero) o;
        return descripcion != null ? descripcion.equals(otro.descripcion) : otro.descripcion == null;
    }
    @Override
    public String toString() {
        return String.format("ObjetivoFinanciero {\n" +
                        "\tDescripcion: %s\n" +
                        "\tMonto:       %.2f\n" +
                        "\tFecha:       %s\n" +
                        "\tCategoria:   %s\n" +
                        "}",
                descripcion,
                monto,
                fecha,
                categoria);
    }
    public int compareTo(ObjetivoFinanciero obj1) {
        int resultado = this.monto.compareTo(obj1.getMonto());
        if (resultado > 0){
            return 1;
        } else if (resultado < 0){
            return -1;
        } else {
            return 0;
        }
    }
}
