package ec.edu.uce.GuiFrame;
import ec.edu.uce.Dominio.Empresa;
import ec.edu.uce.Dominio.Usuario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;
import java.util.List;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class SubIngresarUI extends JFrame {
    // Paleta de colores verdes cálidos
    private static final Color SOFT_GREEN = new Color(162, 194, 152);
    private static final Color SAGE_GREEN = new Color(134, 167, 123);
    private static final Color MINT_CREAM = new Color(247, 250, 245);
    private static final Color DARK_GREEN = new Color(85, 107, 47);
    private static final Color LIGHT_GREEN = new Color(198, 219, 191);
    private static final Color FOREST_GREEN = new Color(46, 84, 48);
    private static final Color BLACK = new Color(0, 0, 0);
    public SubIngresarUI () {
        setTitle("Menú de Ingreso al Sistema - MIFO");
        setSize(550, 580);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel principal
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(MINT_CREAM);

        // Título del sistema
        JLabel encabezado = new JLabel("Bienvenido a MIFO", SwingConstants.CENTER);
        encabezado.setFont(new Font("SansSerif", Font.BOLD, 24));
        encabezado.setForeground(FOREST_GREEN);
        encabezado.setBackground(LIGHT_GREEN);
        encabezado.setOpaque(true);
        encabezado.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        panelPrincipal.add(encabezado, BorderLayout.NORTH);

        // Panel de opciones
        JPanel panelBotones = new JPanel(new GridLayout(7, 1, 12, 12));
        panelBotones.setBackground(MINT_CREAM);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(30, 60, 30, 60));

        // Opciones del menú
        String[] opciones = {
                "Editar credenciales",
                "Eliminar credenciales",
                "Consultar credenciales",
                "Ordenar usuarios por nombre",
                "Consultar todos los usuarios",
                "Volver al menú principal",
                "Salir del programa"
        };

        for (String texto : opciones) {
            JButton boton = crearBoton(texto);
            panelBotones.add(boton);
        }

        panelPrincipal.add(panelBotones, BorderLayout.CENTER);
        add(panelPrincipal);
        setVisible(true);
    }

    // Crea un botón estilizado con acción simulada
    private JButton crearBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("SansSerif", Font.PLAIN, 16));
        boton.setBackground(SAGE_GREEN);
        boton.setForeground(BLACK);
        boton.setFocusPainted(false);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Hover
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(DARK_GREEN);
                boton.setForeground(Color.WHITE);
            }

            public void mouseExited(MouseEvent e) {
                boton.setBackground(SAGE_GREEN);
                boton.setForeground(BLACK);
            }
        });

        // Acción simulada (conexión visual)
        boton.addActionListener(e -> {
            switch (texto) {
                case "Editar credenciales":
                    JOptionPane.showMessageDialog(this, "Funcionalidad: Editar credenciales 🛠️");
                    break;
                case "Eliminar credenciales":
                    int confirm = JOptionPane.showConfirmDialog(this,
                            "¿Seguro que deseas eliminar tus credenciales?",
                            "Confirmación", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        JOptionPane.showMessageDialog(this, "Credenciales eliminadas correctamente. 🗑️");
                        System.exit(0);
                    }
                    break;
                case "Consultar credenciales":
                    JOptionPane.showMessageDialog(this, "Mostrando credenciales actuales 📋");
                    break;
                case "Ordenar usuarios por nombre":
                    JOptionPane.showMessageDialog(this, "Usuarios ordenados por nombre 📇");
                    break;
                case "Consultar todos los usuarios":
                    JOptionPane.showMessageDialog(this, "Mostrando lista de usuarios registrados 🧾");
                    break;
                case "Volver al menú principal":
                    JOptionPane.showMessageDialog(this, "Volviendo al menú principal 🔙");
                    break;
                case "Salir del programa":
                    JOptionPane.showMessageDialog(this,
                            "Gracias por confiar en MIFO \n¡Hasta la próxima!",
                            "Salida", JOptionPane.INFORMATION_MESSAGE);
                    System.exit(0);
                    break;
            }
        });

        return boton;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SubIngresarUI ::new);
    }
}