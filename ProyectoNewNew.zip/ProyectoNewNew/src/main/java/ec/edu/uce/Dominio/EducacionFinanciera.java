package ec.edu.uce.Dominio;
import java.util.*;
import ec.edu.uce.Util.ExcepcionMifo;
/**
 * Clase que representa un curso de Educación Financiera,
 * con sus atributos y manejo de solicitudes asociadas.
 */
public class EducacionFinanciera implements IAdministrarCRUD, Comparable<EducacionFinanciera> {
    private static int contadorCodigo = 0;
    private final int codigo;
    private String titulo;
    private String descripcion;
    private int duracionSemanas;
    private String nivel;
    private String modalidad;
    private Date fechaInicio;
    private String areaCurso;
    // Asociacion con Solicitud Curso
    private List<SolicitudCurso> solicitudes;
    // Bloque de inicialización de instancia
    {
        this.codigo = ++contadorCodigo;
    }
    /**
     * 1.- Constructor por defecto.
     * Inicializa con valores predeterminados y arreglo vacío de solicitudes.
     */
    // Constructor por defecto
    public EducacionFinanciera() {
        this("Sin título", "Sin descripción", 0, "Desconocido", "Desconocido",  "Desconocido", new Date());
    }
    /**
     * 2.- Constructor con parámetros.
     * Inicializa el curso con los valores proporcionados y arreglo vacío de solicitudes.
     */
    public EducacionFinanciera(String titulo, String descripcion, int duracionSemanas, String nivel,
                               String modalidad,  String areaCurso, Date fechaInicio) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.duracionSemanas = duracionSemanas;
        setNivel(nivel);
        this.modalidad = modalidad;
        this.areaCurso = areaCurso;
        this.fechaInicio = fechaInicio;
        this.solicitudes = new ArrayList<>();
        inicializarSolicitudes();

    }
    // 3 Constructor solo con título y nivel
    public EducacionFinanciera(String titulo, String nivel) {
        this(titulo, "Sin descripción", 0, nivel, "Desconocido", "Desconocido", new Date());
    }
    // 4 Constructor con título, descripción, categoria
    public EducacionFinanciera(String titulo, String descripcion, String areaCurso) {
        this(titulo, descripcion, 0, "Desconocido", "Desconocido", areaCurso, new Date());
    }
    // 5 Constructor con título, descripción, duración y modalidad
    public EducacionFinanciera(String titulo, String descripcion, int duracionSemanas, String modalidad) {
        this(titulo, descripcion, duracionSemanas, "Desconocido", modalidad,  "Desconocido", new Date());
    }
    // 6 Constructor con título, duración y nivel
    public EducacionFinanciera(String titulo, int duracionSemanas, String nivel) {
        this(titulo, "Sin descripción", duracionSemanas, nivel, "Desconocido", "Desconocido", new Date());
    }
    // 7 Constructor con título
    public EducacionFinanciera(String titulo) {
        this(titulo, "Sin descripción", 0, "Desconocido", "Desconocido",  "Desconocido", new Date());
    }
    // Getters y setters
    public int getCodigo() {
        return codigo;
    }
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public int getDuracionSemanas() {
        return duracionSemanas;
    }
    public void setDuracionSemanas(int duracionSemanas) {
        this.duracionSemanas = duracionSemanas;
    }
    public String getNivel() {
        return nivel;
    }
    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
    public String getModalidad() {
        return modalidad;
    }
    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }
    public Date getFechaInicio() {
        return fechaInicio;
    }
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }
    public String getAreaCurso() {
        return areaCurso;
    }

    public void setAreaCurso(String areaCurso) {
        this.areaCurso = areaCurso;
    }
    /**
     * Devuelve una copia del arreglo de solicitudes,
     * para evitar manipulación directa del arreglo original.
     *
     * @return Arreglo con las solicitudes actuales.
     */
    public List<SolicitudCurso> getSolicitudes() {
        return new ArrayList<>(solicitudes);
    }
    public void setSolicitudes(List<SolicitudCurso> solicitudes) {
        if (solicitudes != null) {
            this.solicitudes = new ArrayList<>(solicitudes);
            for (SolicitudCurso s : this.solicitudes) {
                s.setCursoSolicitado(this);
            }
        } else {
            this.solicitudes = new ArrayList<>();
        }
    }
    /**
     * Agrega una nueva solicitud al arreglo, redimensionándolo si es necesario,
     * siempre que no sea duplicada ni nula.
     *
     * @param solicitud Solicitud a agregar.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si la solicitud es nula.
     */
    public void agregarSolicitud(SolicitudCurso solicitud) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (solicitud == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La solicitud no puede ser nula.");
        }
        if (solicitudes.contains(solicitud)) {
            System.out.println("Error: Solicitud duplicada.");
            return;
        }
        solicitudes.add(solicitud);
        solicitud.setCursoSolicitado(this);
        System.out.println("Solicitud agregada con éxito.");
    }

    /**
     * Agrega una solicitud de curso a este curso.
     * @param nuevaSolicitud Objeto SolicitudCurso a agregar.
     * @return Mensaje confirmando la operación.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si la solicitud ya existe.
     */
    public String agregarSolicitudCurso(SolicitudCurso nuevaSolicitud) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (nuevaSolicitud == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La solicitud no puede ser null.");
        }
        if (solicitudes.contains(nuevaSolicitud)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Solicitud duplicada para este curso.");
        }
        solicitudes.add(nuevaSolicitud);
        nuevaSolicitud.setCursoSolicitado(this);

        return "Solicitud agregada correctamente para el curso: " + this.titulo;
    }

    public void agregarSolicitud(SolicitudCurso... nuevasSolicitudes) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        for (SolicitudCurso solicitud : nuevasSolicitudes) {
            if (solicitud == null) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La solicitud no puede ser nula.");
            }

            if (solicitudes.contains(solicitud)) {
                System.out.println("Error: Solicitud duplicada, no se agregó: " + solicitud);
                continue;
            }

            solicitudes.add(solicitud);
            solicitud.setCursoSolicitado(this);
            System.out.println("Solicitud agregada con éxito: " + solicitud);
        }
    }

    public String agregarSolicitudCurso(String nombre, String nombreCurso, String correo)
            throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Usuario usuario = new Usuario(nombre, correo);
        SolicitudCurso solicitud = new SolicitudCurso(this, usuario);
        solicitudes.add(solicitud);
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("│ Solicitante: %-42s │%n", nombre));
        sb.append(String.format("│ Curso:       %-42s │%n", nombreCurso));
        sb.append(String.format("│ Correo:      %-42s │%n", correo));
        sb.append("└─────────────────────────────────────────────────────────┘");

        return sb.toString();
    }
    public void agregarSolicitudes(SolicitudCurso[] nuevasSolicitudes) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (nuevasSolicitudes == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El arreglo de solicitudes no puede ser nulo.");
        }
        for (SolicitudCurso solicitud : nuevasSolicitudes) {
            if (solicitud == null) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La solicitud no puede ser nula.");
            }
            if (solicitudes.contains(solicitud)) {
                System.out.println("Error: Solicitud duplicada, no se agregó: " + solicitud);
                continue;
            }
            solicitudes.add(solicitud);
            solicitud.setCursoSolicitado(this);
            System.out.println("Solicitud agregada con éxito: " + solicitud);
        }
    }

    /**
     * Consulta la solicitud almacenada en un índice específico.
     *
     * @param indice Índice de la solicitud a consultar.
     * @return Solicitud en el índice dado.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el índice es inválido.
     */
    public SolicitudCurso consultarSolicitud(int indice) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indice < 0 || indice >= solicitudes.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice inválido para obtener solicitud.");
        }
        return solicitudes.get(indice);
    }


    /**
     * Consulta un conjunto de solicitudes de curso a partir de una lista de índices proporcionados.
     *
     * @param indices Lista de posiciones (índices) dentro de la colección de solicitudes del curso.
     *                Cada índice debe estar dentro del rango válido de la lista.
     * @return Una lista de objetos {@link SolicitudCurso} correspondientes a los índices indicados.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si la lista es nula, contiene valores nulos,
     *         o algún índice no está dentro del rango permitido.
     */

    public List<SolicitudCurso> consultarSolicitudes(List<Integer> indices) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indices == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La lista de índices no puede ser nula.");
        }

        List<SolicitudCurso> resultado = new ArrayList<>();
        for (Integer indice : indices) {
            if (indice == null || indice < 0 || indice >= solicitudes.size()) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice inválido: " + indice);
            }
            resultado.add(solicitudes.get(indice));
        }

        return resultado;
    }


    /**
     * Consulta todas las solicitudes almacenadas y las devuelve como una cadena de texto.
     *
     * @return Cadena con la información de todas las solicitudes no nulas, separadas por salto de línea.
     */
    public String consultarSolicitudes() {
        StringBuilder texto = new StringBuilder();
        for (SolicitudCurso solicitud : solicitudes) {
            if (solicitud != null) {
                texto.append(solicitud).append("\n");
            }
        }
        return texto.toString();
    }



    /**
     * Reemplaza la solicitud existente en la posición indicada por una nueva solicitud.
     *
     * @param indice          Posición dentro de la lista de solicitudes a modificar.
     * @param nuevaSolicitud  Objeto {@link SolicitudCurso} que reemplazará a la solicitud actual.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si la nueva solicitud es nula o el índice no está dentro del rango válido.
     */

    public void editarSolicitud(int indice, SolicitudCurso nuevaSolicitud) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (nuevaSolicitud == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La nueva solicitud no puede ser nula.");
        }

        if (indice < 0 || indice >= solicitudes.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice inválido para editar solicitud.");
        }

        solicitudes.set(indice, nuevaSolicitud);
        nuevaSolicitud.setCursoSolicitado(this);
        System.out.println(" Solicitud editada con éxito.");
    }
    /**
     * Elimina una solicitud por índice, haciendo corrimiento de los elementos posteriores
     * para mantener la integridad del arreglo, y actualiza el número de solicitudes.
     *
     * @param indices Índice de la solicitud a eliminar.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el índice es inválido.
     */
    public void editarSolicitudes(List<Integer> indices, List<SolicitudCurso> nuevasSolicitudes) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indices == null || nuevasSolicitudes == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Las listas no pueden ser nulas.");
        }
        if (indices.size() != nuevasSolicitudes.size()) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Las listas deben tener el mismo tamaño.");
        }

        for (int i = 0; i < indices.size(); i++) {
            int indice = indices.get(i);
            SolicitudCurso nueva = nuevasSolicitudes.get(i);

            if (nueva == null) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La solicitud en la posición " + i + " es nula.");
            }
            if (indice < 0 || indice >= solicitudes.size()) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice inválido: " + indice);
            }

            solicitudes.set(indice, nueva);
            nueva.setCursoSolicitado(this);
            System.out.println("Solicitud editada en la posición " + indice + ".");
        }
    }


    /**
     * Elimina múltiples solicitudes por sus índices, manteniendo la integridad del arreglo.
     *
     * @param indices Arreglo de índices de las solicitudes a eliminar.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el arreglo de índices es nulo o si algún índice es inválido.
     */
    public void eliminarSolicitud(List<Integer> indices) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (indices == null) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La lista de índices no puede ser nula.");
        }

        // Validar todos los índices antes de eliminar
        for (int indice : indices) {
            if (indice < 0 || indice >= solicitudes.size()) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice inválido para eliminar solicitud: " + indice);
            }
        }

        // Desvincular solicitudes eliminadas
        for (int indice : indices) {
            SolicitudCurso solicitud = solicitudes.get(indice);
            if (solicitud != null) {
                solicitud.setCursoSolicitado(null);
            }
        }

        // Eliminar de mayor a menor para mantener posiciones válidas
        indices.sort((a, b) -> Integer.compare(b, a));
        for (int indice : indices) {
            solicitudes.remove((int) indice);
        }

        System.out.println("Solicitudes eliminadas con éxito.");
    }

    /**
     * Elimina una sola solicitud a partir de su índice.
     *
     * @param indice Índice de la solicitud a eliminar.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el índice es inválido.
     */
    private void eliminarSolicitud(int indice) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        eliminarSolicitud(Collections.singletonList(indice));
    }



    /**
     * Busca recursivamente el índice de una solicitud en el arreglo.
     *
     * @param solicitud Solicitud a buscar.
     * @param indice Índice actual en la búsqueda.
     * @return Índice donde se encuentra la solicitud, o -1 si no existe.
     */
    private int buscarIndiceSolicitud(SolicitudCurso solicitud, int indice) {
        if (indice >= solicitudes.size()) return -1;
        SolicitudCurso actual = solicitudes.get(indice);
        if (actual != null && actual.equals(solicitud)) {
            return indice;
        }
        return buscarIndiceSolicitud(solicitud, indice + 1);
    }
    /**
     * Valida si una solicitud ya existe en el arreglo para evitar duplicados.
     */
    // AÑADIDO PARA VALIDAR LOS DUPLICADOS******
    public boolean validarDuplicado(SolicitudCurso solicitud) {
        for (SolicitudCurso s : solicitudes) {
            if (s != null && s.equals(solicitud)) {
                return true;
            }
        }
        return false;
    }
    // AÑADIDO PARA VALIDAR LOS DUPLICADOS******
    @Override
    public boolean equals(Object o) {
        boolean result = false;
        if (o != null && o instanceof EducacionFinanciera) {
            EducacionFinanciera otroCurso = (EducacionFinanciera) o;
            if (this.titulo.equalsIgnoreCase(otroCurso.titulo)) {
                result = true;
            }
        }
        return result;
    }
    public String inicializarSolicitudes() {
        StringBuilder resultado = new StringBuilder();
        try {
            resultado.append(agregarSolicitudCurso("Juan Pérez", "Curso de Ahorro Personal", "juan.perez@example.com")).append("\n");
            resultado.append(agregarSolicitudCurso("María Gómez", "Inversiones Básicas", "maria.gomez@example.com")).append("\n");
            resultado.append(agregarSolicitudCurso("Carlos Ruiz", "Finanzas para Jóvenes", "carlos.ruiz@example.com")).append("\n");
            resultado.append(agregarSolicitudCurso("Ana Torres", "Presupuesto Familiar", "ana.torres@example.com")).append("\n");
            resultado.append(agregarSolicitudCurso("Luis Méndez", "Gestión de Deudas", "luis.mendez@example.com")).append("\n");
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            e.printStackTrace();
            resultado.append("Error al inicializar las solicitudes: ").append(e.getMessage());
        }
        return resultado.toString();
    }
    @Override
    public String nuevo(Object obj) {
        if (obj instanceof SolicitudCurso solicitud) {
            try {
                return agregarSolicitudCurso(solicitud);
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                return "Error al agregar solicitud: " + e.getMessage();
            }
        }
        return "Tipo no soportado en nuevo() para EducacionFinanciera";
    }

    @Override
    public String editar(Object obj) {
        if (obj instanceof SolicitudCurso nueva) {
            int index = buscarIndiceSolicitud(nueva, 0);
            if (index != -1) {
                try {
                    editarSolicitud(index, nueva);
                    return "Solicitud editada correctamente.";
                } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                    return "Error al editar solicitud: " + e.getMessage();
                }
            } else {
                return "Solicitud no encontrada para editar.";
            }
        }
        return "Tipo no soportado en editar() para EducacionFinanciera";
    }

    @Override
    public String borrar(Object obj) {
        if (obj instanceof SolicitudCurso solicitud) {
            int index = buscarIndiceSolicitud(solicitud, 0);
            if (index != -1) {
                try {
                    eliminarSolicitud(index);  // Usa la sobrecarga que recibe un solo índice
                    return "Solicitud eliminada correctamente.";
                } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                    return "Error al eliminar solicitud: " + e.getMessage();
                }
            } else {
                return "Solicitud no encontrada para eliminar.";
            }
        }
        return "Tipo no soportado en borrar() para EducacionFinanciera";
    }

    @Override
    public Object buscarPorId(Integer id) {
        for (SolicitudCurso s : solicitudes) {
            if (s != null && s.getCodigo() == id) {
                return s;
            }
        }
        return null;
    }

    @Override
    public String listar() {
        return consultarSolicitudes();
    }
    /**
     * Representación en cadena del objeto EducacionFinanciera.
     */
    @Override
    public String toString() {
        String separador = "═══════════════════════════════════════════════════════════════════════════════";
        String linea = "───────────────────────────────────────────────────────────────────────────────";

        return String.format(
                "%s\n" +
                        "                        CURSO DE EDUCACIÓN FINANCIERA\n" +
                        "%s\n" +
                        "  Título               : %s\n" +
                        "  Descripción          : %s\n" +
                        "  Duración (semanas)   : %d\n" +
                        "  Nivel                : %s\n" +
                        "  Modalidad            : %s\n" +
                        "  Area del Curso       : %s\n" +
                        "  Fecha de inicio      : %s\n" +
                        "%s",
                separador,
                linea,
                titulo,
                descripcion,
                duracionSemanas,
                nivel,
                modalidad,
                areaCurso,
                fechaInicio,
                separador
        );
    }
    public int compareTo(EducacionFinanciera edu1) {
        int resultado = Integer.compare(this.duracionSemanas, edu1.getDuracionSemanas());
        if (resultado > 0) {
            return 1;
        } else if (resultado < 0) {
            return -1;
        } else {
            return 0;
        }
    }
}
