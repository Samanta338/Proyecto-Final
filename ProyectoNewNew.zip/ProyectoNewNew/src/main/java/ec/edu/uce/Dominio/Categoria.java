package ec.edu.uce.Dominio;
/**
 * Representa una categoría utilizada en el sistema.
 * Cada categoría tiene un nombre, un tipo de movimiento asociado y un ID único.
 */
public class Categoria implements Comparable<Categoria> {
    private String nombreCategoria;
    private TipoMovimiento tipoMovimiento;
    private static int contadorId;
    private final int id;
    // Bloque de inicialización de instancia
    static {
        contadorId = 1;
    }
    {
        id = contadorId++;
    }
    public Categoria() {
        this("Sin categoría", TipoMovimiento.GASTO);
    }
    public Categoria(String nombreCategoria) {
        this(nombreCategoria, TipoMovimiento.GASTO);
    }

    // Constructor con nombre y tipoMovimiento
    public Categoria(String nombreCategoria, TipoMovimiento tipoMovimiento) {
        this.nombreCategoria = nombreCategoria;
        this.tipoMovimiento = tipoMovimiento;
    }

    public int getId() {
        return id;
    }
    public String getNombreCategoria() {
        return nombreCategoria;
    }
    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public TipoMovimiento getTipoMovimiento() {
        return tipoMovimiento;
    }

    public void setTipoMovimiento(TipoMovimiento tipoMovimiento) {
        this.tipoMovimiento = tipoMovimiento;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Categoria)) return false;
        Categoria otra = (Categoria) o;
        return this.nombreCategoria != null &&
                otra.nombreCategoria != null &&
                this.nombreCategoria.trim().equalsIgnoreCase(otra.nombreCategoria.trim());
    }
    /**
     * Devuelve una representación en cadena de la categoría.
     *
     * @return Cadena con el ID, nombre y tipo de movimiento de la categoría.
     */
    @Override
    public String toString() {
        String icono = tipoMovimiento.toString().equals("INGRESO") ? "↗" : "↙";
        return String.format("║    %s      │ %-3d │ %-19s │ %-15s │ $%-23.2f║",
                icono,
                id,
                nombreCategoria.length() > 19 ? nombreCategoria.substring(0, 19) : nombreCategoria,
                tipoMovimiento.toString(),
                tipoMovimiento.getLimiteMensualSugerido());
    }
    public int compareTo(Categoria c1) {
        // Primero se compara por el nombre de la categoría (orden alfabético)
        int resultado = this.nombreCategoria.compareTo(c1.getNombreCategoria());
        if (resultado > 0) {
            return 1;
        } else if (resultado < 0) {
            return -1;
        } else {
            int resultadoId = Integer.compare(this.id, c1.getId());
            if (resultadoId > 0) {
                return 1;
            } else if (resultadoId < 0) {
                return -1;
            } else {
                return 0;
            }
        }
    }
}

