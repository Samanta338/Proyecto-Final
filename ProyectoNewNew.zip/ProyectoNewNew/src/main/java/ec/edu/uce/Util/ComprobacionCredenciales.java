package ec.edu.uce.Util;
/**
 * Clase que proporciona métodos para comprobar la validez de credenciales como contraseñas.
 */
public class ComprobacionCredenciales {

    /**
     * Método que valida si una contraseña es válida según los siguientes criterios:
     * - Debe tener al menos 8 caracteres
     * - Debe contener al menos una letra (mayúscula o minúscula)
     * - Debe contener al menos un número
     *
     * @param contrasena La contraseña a validar
     * @return true si cumple los requisitos, false si no
     */
    public static boolean esValida(String contrasena) {
        // Aserción para verificar que la contraseña no sea nula
        assert contrasena != null : "La contraseña no debe ser nula";

        // Aserción para verificar que tenga al menos 8 caracteres
        assert contrasena.length() >= 8 : "La contraseña debe tener al menos 8 caracteres";

        // Aserción para verificar que contenga al menos una letra
        assert contrasena.matches(".*[a-zA-Z].*") : "La contraseña debe contener al menos una letra";

        // Aserción para verificar que contenga al menos un número
        assert contrasena.matches(".*\\d.*") : "La contraseña debe contener al menos un número";

        // Validación completa usando expresión regular
        return contrasena.matches("^(?=.*[a-zA-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$");
    }
}
