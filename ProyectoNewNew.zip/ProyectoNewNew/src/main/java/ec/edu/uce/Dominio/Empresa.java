package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ExcepcionMifo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
public class Empresa implements IAdministrarCRUD {
    private Map<Integer, Usuario> usuariosPorCodigo = new HashMap<>();
    // Instancia única privada estática (Singleton)
    private static final Empresa instancia = new Empresa();
    private List<Usuario> usuarios;
    private List<Categoria> categorias;
    private List<EducacionFinanciera> educacionesFinancieras;
    private static int usuarioCodigoContador;
    private static int educacionCodigoContador;
    private List<SolicitudCurso> listaSolicitudesCurso;
    private List<Presupuesto> listaPresupuestos;

    static {
        usuarioCodigoContador = 0;
        educacionCodigoContador = 0;
    }

    public static Empresa getInstance() {
        return instancia;
    }

    // Getters y setters
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }

    public List<EducacionFinanciera> getEducacionesFinancieras() {
        return educacionesFinancieras;
    }

    public void setEducacionesFinancieras(List<EducacionFinanciera> educacionesFinancieras) {
        this.educacionesFinancieras = educacionesFinancieras;
    }

    //**
    public List<SolicitudCurso> getListaSolicitudesCurso() {
        return listaSolicitudesCurso;
    }

    public void setListaSolicitudesCurso(List<SolicitudCurso> listaSolicitudesCurso) {
        this.listaSolicitudesCurso = listaSolicitudesCurso;
    }

    public List<Presupuesto> getListaPresupuestos() {
        return listaPresupuestos;
    }

    public void setListaPresupuestos(List<Presupuesto> listaPresupuestos) {
        this.listaPresupuestos = listaPresupuestos;
    }

    private Empresa() {
        usuarios = new ArrayList<>();
        categorias = new ArrayList<>();
        educacionesFinancieras = new ArrayList<>();
        listaSolicitudesCurso = new ArrayList<>();
        listaPresupuestos = new ArrayList<>();
        inicializarCategorias();
        inicializarUsuarios();
        inicializarEducacionesFinancieras();
    }

    public int generarCodigoUsuario() {
        usuarioCodigoContador = usuarioCodigoContador + 1;
        return usuarioCodigoContador;
    }

    public int generarCodigoEducacionFinanciera() {
        educacionCodigoContador = educacionCodigoContador + 1;
        return educacionCodigoContador;
    }

    // Validar duplicado para Usuario
    public boolean validarDuplicado(Usuario usuario) {
        for (Usuario u : usuarios) {
            if (u != null && u.equals(usuario)) {
                return true;
            }
        }
        return false;
    }

    // Validar duplicado para Categoria
    public boolean validarDuplicado(Categoria categoria) {
        for (Categoria c : categorias) {
            if (c != null && c.equals(categoria)) {
                return true;
            }
        }
        return false;
    }

    // Validar duplicado para EducacionFinanciera
    public boolean validarDuplicado(EducacionFinanciera educacion) {
        for (EducacionFinanciera e : educacionesFinancieras) {
            if (e != null && e.equals(educacion)) {
                return true;
            }
        }
        return false;
    }

    public String agregarUsuarioConCodigo(String nombre, String contrasena, String correo) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        for (Usuario usuario : usuarios) {
            if (usuario.getNombre().equalsIgnoreCase(nombre)) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un usuario con este nombre.");
            }
        }
        int nuevoCodigo = usuarios.size() + 1;
        Usuario nuevoUsuario = new Usuario(nuevoCodigo, nombre, contrasena, correo);

        if (usuariosPorCodigo.containsKey(nuevoCodigo)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un usuario con este código.");
        }

        usuarios.add(nuevoUsuario);
        usuariosPorCodigo.put(nuevoCodigo, nuevoUsuario);

        return "Código: " + nuevoCodigo +
                "\nNombre: " + nombre +
                "\nContraseña: " + contrasena +
                "\nCorreo: " + correo;
    }

    // Agregar usuario directamente validando duplicado
    public String agregarUsuario(Usuario nuevoUsuario) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (validarDuplicado(nuevoUsuario) || usuariosPorCodigo.containsKey(nuevoUsuario.getCodigo())) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un usuario con este nombre o código.");
        }

        usuarios.add(nuevoUsuario);
        usuariosPorCodigo.put(nuevoUsuario.getCodigo(), nuevoUsuario);

        return "Usuario creado con éxito.\nNombre: " + nuevoUsuario.getNombre() +
                "\nContraseña: " + nuevoUsuario.getContrasena() +
                "\nCorreo: " + nuevoUsuario.getCorreo();
    }

    /**
     * Agrega un usuario nuevo al sistema con nombre y contraseña (sin correo).
     *
     * @param nombre     Nombre del usuario.
     * @param contrasena Contraseña del usuario.
     * @return Mensaje de confirmación con los datos del usuario creado.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el usuario ya existe o los datos son inválidos.
     *                                                   MOD
     */
    public String agregarUsuario(String nombre, String contrasena) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        String correo = "correo_no_proporcionado";
        Usuario nuevoUsuario = new Usuario(nombre, contrasena, correo);
        if (validarDuplicado(nuevoUsuario)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un usuario con este nombre.");
        }

        usuarios.add(nuevoUsuario);

        return "Código: " + nuevoUsuario.getCodigo() +
                "\nNombre: " + nombre +
                "\nContraseña: " + contrasena +
                "\nCorreo: " + correo;
    }

    // Consultar usuarios (todos)
    public String consultarUsuario() {
        StringBuilder texto = new StringBuilder();
        for (Usuario usuario : usuarios) {
            if (usuario != null) {
                texto.append(usuario).append("\n");
            }
        }
        return texto.toString();
    }

    public String consultarUsuario(Usuario nuevoUsuario) throws ExcepcionMifo.UsuarioNoEncontradoExcepcion {
        System.out.println("Buscando usuario: " + nuevoUsuario);
        for (Usuario usuario : usuarios) {
            if (usuario != null) {
                System.out.println("Comparando con usuario: " + usuario);
                System.out.println("Comparando nombre: " + usuario.getNombre() + " == " + nuevoUsuario.getNombre());
                System.out.println("Comparando contraseña: " + usuario.getContrasena() + " == " + nuevoUsuario.getContrasena());
                System.out.println("Comparando correo: " + usuario.getCorreo() + " == " + nuevoUsuario.getCorreo());
                if (usuario.getNombre().equalsIgnoreCase(nuevoUsuario.getNombre())
                        && usuario.getContrasena().equals(nuevoUsuario.getContrasena())
                        && usuario.getCorreo().equalsIgnoreCase(nuevoUsuario.getCorreo())) {
                    return usuario.toString();
                }
            }
        }
        throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion(nuevoUsuario.getNombre());
    }

    /**
     * Consulta los usuarios cuyo correo electrónico pertenece a un dominio específico.
     *
     * @param dominio Dominio del correo electrónico a filtrar (por ejemplo, "empresa.com").
     * @return Cadena con la información de los usuarios que coincidan con el dominio.
     */
    public String consultarUsuario(String dominio) {
        String texto = "";
        for (Usuario usuario : usuarios) {
            if (usuario != null && usuario.getCorreo().endsWith("@" + dominio)) {
                texto += usuario + "\r\n";
            }
        }
        if (texto.isEmpty()) {
            texto = "No se encontraron usuarios con el dominio: " + dominio;
        }
        return texto;
    }

    // Eliminar usuario por índice
    public void eliminarUsuario(int indice) throws ExcepcionMifo.UsuarioNoEncontradoExcepcion {
        if (indice < 0 || indice >= usuarios.size()) {
            throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("Usuario no encontrado con índice: " + indice);
        }

        usuarios.remove(indice);

        System.out.println("Usuario eliminado con éxito.");
    }


    /**
     * Elimina un usuario por su nombre de usuario.
     *
     * @param nombre Nombre del usuario a eliminar.
     * @throws ExcepcionMifo.UsuarioNoEncontradoExcepcion si no se encuentra un usuario con el nombre especificado.
     */
    public void eliminarUsuario(String nombre) throws ExcepcionMifo.UsuarioNoEncontradoExcepcion {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("El nombre de usuario no puede estar vacío.");
        }

        for (int i = 0; i < usuarios.size(); i++) {
            Usuario u = usuarios.get(i);
            if (u.getNombre().equalsIgnoreCase(nombre)) {
                usuarios.remove(i);
                usuariosPorCodigo.remove(u.getCodigo());
                System.out.println("Usuario eliminado con éxito.");
                return;
            }
        }

        throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("Usuario no encontrado con nombre: " + nombre);
    }

    public void editarUsuario(int indice, Usuario usuarioEditado)
            throws ExcepcionMifo.UsuarioNoEncontradoExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {

        if (indice < 0 || indice >= usuarios.size()) {
            throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("Índice inválido para editar usuario: " + indice);
        }

        for (int i = 0; i < usuarios.size(); i++) {
            if (i != indice && usuarios.get(i).equals(usuarioEditado)) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un usuario con este nombre.");
            }
        }
        Usuario usuarioExistente = usuarios.get(indice);
        usuarioExistente.setNombre(usuarioEditado.getNombre());
        usuarioExistente.setContrasena(usuarioEditado.getContrasena());
        usuarioExistente.setCorreo(usuarioEditado.getCorreo());
        usuariosPorCodigo.put(usuarioExistente.getCodigo(), usuarioExistente);

        System.out.println("Usuario editado con éxito.");
    }

    /**
     * Edita un usuario existente buscándolo por su nombre.
     *
     * @param nombreUsuario  Nombre del usuario a editar.
     * @param usuarioEditado Datos actualizados del usuario.
     * @throws ExcepcionMifo.UsuarioNoEncontradoExcepcion si no se encuentra el usuario.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion  si ya existe un usuario duplicado.
     */
    public void editarUsuario(String nombreUsuario, Usuario usuarioEditado)
            throws ExcepcionMifo.UsuarioNoEncontradoExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {

        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) {
            throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("El nombre de usuario no puede estar vacío.");
        }

        int posicionEncontrada = -1;
        for (int i = 0; i < usuarios.size(); i++) {
            if (usuarios.get(i).getNombre().equalsIgnoreCase(nombreUsuario)) {
                posicionEncontrada = i;
                break;
            }
        }

        if (posicionEncontrada == -1) {
            throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("Usuario no encontrado: " + nombreUsuario);
        }

        // Verificar duplicado, excluyendo la posición actual
        for (int i = 0; i < usuarios.size(); i++) {
            if (i != posicionEncontrada && usuarios.get(i).equals(usuarioEditado)) {
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un usuario con este nombre.");
            }
        }
        // Actualizar datos del usuario encontrado
        Usuario usuarioExistente = usuarios.get(posicionEncontrada);
        usuarioExistente.setNombre(usuarioEditado.getNombre());
        usuarioExistente.setContrasena(usuarioEditado.getContrasena());
        usuarioExistente.setCorreo(usuarioEditado.getCorreo());
        usuariosPorCodigo.put(usuarioExistente.getCodigo(), usuarioExistente);

        System.out.println("Usuario editado con éxito.");
    }


    /**
     * Inicializa un conjunto de usuarios predeterminados.
     *
     * @return Mensaje resumen de la creación de los usuarios.
     */
    public String inicializarUsuarios() {
        usuarios.clear();
        usuariosPorCodigo.clear();
        usuarioCodigoContador = 0;
        Usuario.reiniciarContador();
        StringBuilder resultado = new StringBuilder();
        try {
            resultado.append(agregarUsuarioConCodigo("Marianela", "Marianela1234", "marianlea@gmail.com")).append("\n");
            resultado.append(agregarUsuarioConCodigo("Rosalia", "Rosalia1234", "rosalia@gmail.com")).append("\n");
            resultado.append(agregarUsuarioConCodigo("Erick", "Erick1234", "erick@gmail.com")).append("\n");
            resultado.append(agregarUsuarioConCodigo("Daniela", "Daniela1234", "daniela@gmail.com")).append("\n");
            resultado.append(agregarUsuarioConCodigo("Usuario", "Contraseña1", "usuario1@example.com")).append("\n");
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            e.printStackTrace();
            resultado.append("Error al inicializar los usuarios: ").append(e.getMessage());
        }
        return resultado.toString();
    }

    // Validar credenciales
    public boolean validarCredenciales(String nombreUsuario, String contrasena) {
        for (Usuario usuario : usuarios) {
            if (usuario.getNombre().equalsIgnoreCase(nombreUsuario) &&
                    usuario.getContrasena().equals(contrasena)) {
                return true;
            }
        }
        return false;
    }


    // Agregar categoría con código y validación
    public String agregarCategoriaConCodigo(String nombreCategoria) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Categoria nuevaCategoria = new Categoria(nombreCategoria);

        if (validarDuplicado(nuevaCategoria)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe una categoría con este nombre.");
        }

        categorias.add(nuevaCategoria);

        return "Código: " + nuevaCategoria.getId() + // Usa el ID real de la categoría
                "\nNombre Categoría: " + nombreCategoria;
    }

    public String agregarCategoria(Categoria nuevaCategoria) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (validarDuplicado(nuevaCategoria)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe una categoría con este nombre.");
        }
        categorias.add(nuevaCategoria);
        return "Nombre Categoría: " + nuevaCategoria.getNombreCategoria();
    }

    public String agregarCategoria(String nombreCategoria) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Categoria nuevaCategoria = new Categoria(nombreCategoria);
        return agregarCategoria(nuevaCategoria);
    }

    public String agregarCategoria(String nombreCategoria, TipoMovimiento tipoMovimiento) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Categoria nuevaCategoria = new Categoria(nombreCategoria, tipoMovimiento);
        return agregarCategoria(nuevaCategoria);
    }

    // Consultar categorías
    public String consultarCategoria(Categoria nuevaCategoria) {
        StringBuilder texto = new StringBuilder();
        for (Categoria categoria : categorias) {
            if (categoria != null && categoria.getNombreCategoria().equalsIgnoreCase(nuevaCategoria.getNombreCategoria())) {
                texto.append(categoria).append("\n");
            }
        }
        return texto.length() > 0 ? texto.toString() : "Categoria no encontrada";
    }

    /**
     * Consulta todas las categorías almacenadas.
     *
     * @return Texto con la información de las categorías.
     */
    public String consultarCategorias() {
        StringBuilder texto = new StringBuilder();
        for (Categoria c : categorias) {
            if (c != null) {
                texto.append(c).append("\r\n");
            }
        }
        return texto.toString();
    }

    /**
     * Edita una categoría en el índice especificado.
     *
     * @param indice         Índice de la categoría a editar.
     * @param nuevaCategoria Nueva categoría que reemplaza la anterior.
     */
    public void editarCategoria(int indice, Categoria nuevaCategoria) {
        if (indice < 0 || indice >= categorias.size()) {
            System.out.println("Índice inválido para editar categoría.");
            return;
        }
        if (nuevaCategoria == null) {
            System.out.println("La categoría nueva no puede ser nula.");
            return;
        }

        categorias.set(indice, nuevaCategoria);
        System.out.println("Categoría editada exitosamente.");
    }

    /**
     * Edita una categoría buscando por nombre.
     *
     * @param nombreCategoria Nombre de la categoría a editar.
     * @param nuevaCategoria  Nueva categoría que reemplaza a la anterior.
     */
    public void editarCategoria(String nombreCategoria, Categoria nuevaCategoria) {
        if (nombreCategoria == null || nombreCategoria.trim().isEmpty()) {
            System.out.println("El nombre de la categoría no puede estar vacío.");
            return;
        }
        if (nuevaCategoria == null) {
            System.out.println("La categoría nueva no puede ser nula.");
            return;
        }

        for (int i = 0; i < categorias.size(); i++) {
            Categoria c = categorias.get(i);
            if (c.getNombreCategoria().equalsIgnoreCase(nombreCategoria)) {
                categorias.set(i, nuevaCategoria);
                System.out.println("Categoría editada exitosamente.");
                return;
            }
        }

        System.out.println("No se encontró la categoría con nombre: " + nombreCategoria);
    }

    /**
     * Elimina una categoría por índice, realizando corrimiento de elementos.
     *
     * @param indice Índice de la categoría a eliminar.
     */
    public void eliminarCategoria(int indice) {
        if (indice < 0 || indice >= categorias.size()) {
            System.out.println("Índice inválido para eliminar categoría.");
            return;
        }

        categorias.remove(indice);
        System.out.println("Categoría eliminada exitosamente.");
    }


    /**
     * Elimina una categoría por nombre, realizando corrimiento de elementos.
     *
     * @param nombreCategoria Nombre de la categoría a eliminar.
     */
    public void eliminarCategoria(String nombreCategoria) {
        if (nombreCategoria == null || nombreCategoria.trim().isEmpty()) {
            System.out.println("El nombre de la categoría no puede estar vacío.");
            return;
        }

        for (int i = 0; i < categorias.size(); i++) {
            Categoria c = categorias.get(i);
            if (c.getNombreCategoria().equalsIgnoreCase(nombreCategoria)) {
                categorias.remove(i);
                System.out.println("Categoría eliminada exitosamente.");
                return;
            }
        }

        System.out.println("No se encontró la categoría con nombre: " + nombreCategoria);
    }

    /**
     * Inicializa el arreglo de categorías con valores predeterminados.
     * Cada categoría se crea con un nombre y un tipo de movimiento asociado.
     * Se agregan cinco categorías iniciales al sistema.
     *
     * @return Una cadena con los mensajes de resultado de la adición de cada categoría,
     * o un mensaje de error si ocurre alguna excepción durante la inicialización.
     */
    public String inicializarCategorias() {
        StringBuilder resultado = new StringBuilder();
        try {
            resultado.append(agregarCategoria("Salario", TipoMovimiento.INGRESO)).append("\n");
            resultado.append(agregarCategoria("Alimentacion", TipoMovimiento.GASTO)).append("\n");
            resultado.append(agregarCategoria("Trabajo extra", TipoMovimiento.INGRESO)).append("\n");
            resultado.append(agregarCategoria("Movilidad", TipoMovimiento.GASTO)).append("\n");
            resultado.append(agregarCategoria("Ocio", TipoMovimiento.GASTO)).append("\n");
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            e.printStackTrace();
            resultado.append("Error al inicializar las categorías: ").append(e.getMessage());
        }
        return resultado.toString();
    }

    public Categoria buscarCategoriaPorNombre(String nombreCategoria) {
        for (Categoria c : categorias) {
            if (c.getNombreCategoria().equalsIgnoreCase(nombreCategoria)) {
                return c;
            }
        }
        return null;
    }

    public String agregarEducacionFinancieraConCodigo(
            String titulo, String descripcion, int duracion, String nivel,
            String modalidad, String area, String fechaInicioStr
    ) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaInicio;
        try {
            fechaInicio = formatoFecha.parse(fechaInicioStr);
        } catch (ParseException e) {
            return "Fecha inválida: " + fechaInicioStr;
        }

        EducacionFinanciera curso = new EducacionFinanciera(
                titulo, descripcion, duracion, nivel, modalidad, area, fechaInicio
        );

        // Solo agregar a la lista
        educacionesFinancieras.add(curso);

        return "Curso agregado: " + titulo + " con código: ";
    }

    // Agregar educación financiera directamente validando duplicado
    public String agregarEducacionFinanciera(EducacionFinanciera nuevaEducacion) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (validarDuplicado(nuevaEducacion)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe una educación financiera con el mismo título.");
        }

        educacionesFinancieras.add(nuevaEducacion);

        return "Título: " + nuevaEducacion.getTitulo() +
                "\nContenido: " + nuevaEducacion.getDescripcion();
    }

    // Consultar todas las educaciones financieras
    public String consultarEducacionFinanciera() {
        StringBuilder texto = new StringBuilder();
        for (int i = 0; i < educacionesFinancieras.size(); i++) {
            texto.append("Código: ").append(i + 1).append("\n");
            texto.append(educacionesFinancieras.get(i).toString()).append("\n");
        }
        return texto.toString();
    }
    /**
     * Consulta todas las educaciones financieras que pertenecen a una categoría específica.
     *
     * @param categoria Nombre de la categoría a filtrar.
     * @return Información de los cursos que pertenecen a la categoría, o mensaje si no hay ninguno.
     */
    public String consultarEducacionFinancieraPorCategoria(String categoria) {
        if (categoria == null || categoria.trim().isEmpty()) {
            return "La categoría no puede estar vacía.";
        }
        StringBuilder resultado = new StringBuilder();
        for (EducacionFinanciera edu : educacionesFinancieras) {
            if (edu != null && edu.getAreaCurso() != null &&
                    edu.getAreaCurso().equalsIgnoreCase(categoria)) {
                resultado.append(edu.toString()).append("\n");
            }
        }
        if (resultado.length() == 0) {
            return "No se encontraron cursos para la categoría: " + categoria;
        }
        return resultado.toString();
    }

    /**
     * Consulta una educación financiera por título.
     *
     * @param titulo Título del curso a buscar.
     * @return Información del curso si se encuentra, o mensaje indicando que no existe.
     */
    public String consultarEducacionFinanciera(String titulo) {
        if (titulo == null || titulo.trim().isEmpty()) {
            return "El título no puede estar vacío.";
        }
        for (EducacionFinanciera edu : educacionesFinancieras) {
            if (edu != null && edu.getTitulo().equalsIgnoreCase(titulo)) {
                return edu.toString();
            }
        }
        return "No se encontró una educación financiera con el título: " + titulo;
    }

    /**
     * Edita una educación financiera buscándola por título.
     *
     * @param tituloOriginal Título del curso a editar.
     * @param nuevaEducacion Nueva información del curso.
     */
    public void editarEducacionFinanciera(String tituloOriginal, EducacionFinanciera nuevaEducacion) {
        if (tituloOriginal == null || tituloOriginal.trim().isEmpty()) {
            System.out.println("El título original no puede estar vacío.");
            return;
        }
        if (nuevaEducacion == null) {
            System.out.println("La nueva educación financiera no puede ser nula.");
            return;
        }

        for (int i = 0; i < educacionesFinancieras.size(); i++) {
            EducacionFinanciera edu = educacionesFinancieras.get(i);
            if (edu.getTitulo().equalsIgnoreCase(tituloOriginal)) {
                educacionesFinancieras.set(i, nuevaEducacion);
                System.out.println("Educación financiera editada exitosamente.");
                return;
            }
        }

        System.out.println("No se encontró una educación financiera con el título: " + tituloOriginal);
    }


    /**
     * CRUD: Editar educación financiera
     */

    /**
     * Edita la educación financiera en la posición indicada.
     *
     * @param indice         Índice del curso a editar.
     * @param nuevaEducacion Nueva información del curso.
     */
    public void editarEducacionFinanciera(int indice, EducacionFinanciera nuevaEducacion) {
        if (indice >= 0 && indice < educacionesFinancieras.size() && nuevaEducacion != null) {
            educacionesFinancieras.set(indice, nuevaEducacion);
            System.out.println("Educación financiera editada exitosamente.");
        } else {
            System.out.println("Índice inválido o educación nula.");
        }
    }

    /**
     * Edita la descripción de una educación financiera buscándola por título.
     *
     * @param tituloOriginal   Título del curso a editar.
     * @param nuevaDescripcion Nueva descripción para el curso.
     */
    public void editarEducacionFinanciera(String tituloOriginal, String nuevaDescripcion) {
        if (tituloOriginal == null || tituloOriginal.trim().isEmpty()) {
            System.out.println("El título original no puede estar vacío.");
            return;
        }
        if (nuevaDescripcion == null || nuevaDescripcion.trim().isEmpty()) {
            System.out.println("La nueva descripción no puede estar vacía.");
            return;
        }

        boolean editada = false;
        for (EducacionFinanciera edu : educacionesFinancieras) {
            if (edu != null && edu.getTitulo().equalsIgnoreCase(tituloOriginal)) {
                edu.setDescripcion(nuevaDescripcion);
                System.out.println("Descripción de la educación financiera actualizada exitosamente.");
                editada = true;
                break;
            }
        }

        if (!editada) {
            System.out.println("No se encontró una educación financiera con el título: " + tituloOriginal);
        }
    }

    /**
     * CRUD: Eliminar educación financiera
     */

    /**
     * Elimina una educación financiera del sistema.
     *
     * @param indice Índice del curso a eliminar.
     */
    public void eliminarEducacionFinanciera(int indice) {
        if (indice >= 0 && indice < educacionesFinancieras.size()) {
            educacionesFinancieras.remove(indice);
            System.out.println("Educación financiera eliminada exitosamente.");
        } else {
            System.out.println("Índice inválido para eliminar educación financiera.");
        }
    }

    /**
     * Elimina una educación financiera a partir de un objeto.
     *
     * @param educacion EducacionFinanciera a eliminar.
     */
    public void eliminarEducacionFinanciera(EducacionFinanciera educacion) {
        if (educacion == null) {
            System.out.println("La educación financiera no puede ser nula.");
            return;
        }

        int indice = -1;
        int i = 0;
        for (EducacionFinanciera ef : educacionesFinancieras) {
            if (ef != null && ef.equals(educacion)) { // asumiendo que equals está bien definido
                indice = i;
                break;
            }
            i++;
        }

        if (indice == -1) {
            System.out.println("No se encontró la educación financiera para eliminar.");
            return;
        }

        eliminarEducacionFinanciera(indice);
    }

    /**
     * Elimina una educación financiera por título.
     *
     * @param titulo Título del curso a eliminar.
     */
    public void eliminarEducacionFinanciera(String titulo) {
        if (titulo == null || titulo.trim().isEmpty()) {
            System.out.println("El título no puede estar vacío.");
            return;
        }

        int indice = -1;
        int i = 0;
        for (EducacionFinanciera ef : educacionesFinancieras) {
            if (ef != null && ef.getTitulo().equalsIgnoreCase(titulo)) {
                indice = i;
                break;
            }
            i++;
        }

        if (indice == -1) {
            System.out.println("No se encontró la educación financiera con título: " + titulo);
            return;
        }

        eliminarEducacionFinanciera(indice);
    }

    public void registrarSolicitud(SolicitudCurso nueva) {
        if (nueva == null) {
            System.out.println("La solicitud no puede ser nula.");
            return;
        }

        listaSolicitudesCurso.add(nueva);

        if (nueva.getCursoSolicitado() != null) {
            try {
                nueva.getCursoSolicitado().agregarSolicitud(nueva); // vincula con el curso
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                System.out.println("Error al asociar solicitud con el curso: " + e.getMessage());
            }
        }
    }


    /**
     * Inicializa un conjunto de cursos de educación financiera predeterminados con títulos comprensibles para público general.
     *
     * @return Mensaje resumen de la creación de los cursos.
     */
    public String inicializarEducacionesFinancieras() {
        StringBuilder resultado = new StringBuilder();
        try {
            resultado.append(agregarEducacionFinancieraConCodigo("Domina tu dinero", "Aprende las bases...", 4, "BASICO", "Online", "Inversión", "14/05/2025")).append("\n");
            resultado.append(agregarEducacionFinancieraConCodigo("Errores comunes...", "Evita fallas...", 3, "INTERMEDIO", "Presencial", "Ahorro", "15/05/2025")).append("\n");
            resultado.append(agregarEducacionFinancieraConCodigo("Técnicas para ahorrar", "Descubre métodos...", 5, "BASICO", "Online", "Ahorro", "16/05/2025")).append("\n");
            resultado.append(agregarEducacionFinancieraConCodigo("Guía de inversiones", "Cómo invertir...", 6, "AVANZADO", "Presencial", "Inversión", "17/05/2025")).append("\n");
            resultado.append(agregarEducacionFinancieraConCodigo("Organiza tu dinero", "Planifica ingresos...", 4, "INTERMEDIO", "Online", "Gastos", "18/05/2025")).append("\n");
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            e.printStackTrace();
            resultado.append("Error al inicializar los cursos: ").append(e.getMessage());
        }
        return resultado.toString();
    }

    public List<EducacionFinanciera> buscarCursosPorCategoria(List<EducacionFinanciera> cursos, String categoriaBuscada) {
        List<EducacionFinanciera> resultados = new ArrayList<>();
        if (categoriaBuscada == null || categoriaBuscada.isEmpty()) {
            return resultados;
        }
        for (EducacionFinanciera curso : cursos) {
            if (curso.getAreaCurso() != null &&
                    curso.getAreaCurso().equalsIgnoreCase(categoriaBuscada.trim())) {
                resultados.add(curso);
            }
        }
        return resultados;
    }

    public Usuario buscarUsuarioPorNombre(String nombre) {
        for (Usuario u : usuarios) {
            if (u.getNombre().equalsIgnoreCase(nombre)) {
                return u;
            }
        }
        return null;
    }

    public List<SolicitudCurso> obtenerSolicitudesPorUsuario(Usuario usuario) {
        List<SolicitudCurso> solicitudesUsuario = new ArrayList<>();

        for (SolicitudCurso solicitud : listaSolicitudesCurso) {
            if (solicitud.getUsuario().equals(usuario)) {
                solicitudesUsuario.add(solicitud);
            }
        }

        return solicitudesUsuario;
    }

    @Override
    public String nuevo(Object obj) {
        try {
            if (obj instanceof Usuario) {
                Usuario usuarioNuevo = (Usuario) obj;
                return agregarUsuario(usuarioNuevo);
            } else if (obj instanceof Categoria) {
                Categoria categoriaNueva = (Categoria) obj;
                return agregarCategoria(categoriaNueva);
            } else if (obj instanceof EducacionFinanciera) {
                EducacionFinanciera eduNueva = (EducacionFinanciera) obj;
                return agregarEducacionFinanciera(eduNueva);
            }
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            return "Error al agregar: " + e.getMessage();
        }
        return "Tipo de objeto no soportado para agregar.";
    }

    @Override
    public String editar(Object obj) {
        try {
            if (obj instanceof Usuario usuarioEditado) {
                for (int i = 0; i < usuarios.size(); i++) {
                    if (usuarios.get(i).getCodigo() == usuarioEditado.getCodigo()) {
                        editarUsuario(i, usuarioEditado);
                        return "Usuario editado con éxito.";
                    }
                }
                throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion(usuarioEditado.getNombre());
            } else if (obj instanceof Categoria categoriaEditada) {
                for (int i = 0; i < categorias.size(); i++) {
                    if (categorias.get(i).getId() == categoriaEditada.getId()) {
                        editarCategoria(i, categoriaEditada);
                        return "Categoría editada con éxito.";
                    }
                }
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Categoría no encontrada para editar.");
            } else if (obj instanceof EducacionFinanciera eduEditada) {
                for (int i = 0; i < educacionesFinancieras.size(); i++) {
                    if (educacionesFinancieras.get(i).getTitulo().equalsIgnoreCase(eduEditada.getTitulo())
                            && educacionesFinancieras.get(i).getFechaInicio().equals(eduEditada.getFechaInicio())) {
                        editarEducacionFinanciera(i, eduEditada);
                        return "Educación financiera editada con éxito.";
                    }

                }
                throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Educación financiera no encontrada para editar.");
            } else {
                return "Tipo de objeto no soportado para editar.";
            }
        } catch (ExcepcionMifo e) {
            return "Error al editar: " + e.getMessage();
        }
    }

    @Override
    public String borrar(Object obj) {
        try {
            if (obj instanceof Usuario usuarioBorrar) {
                for (int i = 0; i < usuarios.size(); i++) {
                    if (usuarios.get(i).getCodigo() == usuarioBorrar.getCodigo()) {
                        eliminarUsuario(i);
                        return "Usuario eliminado con éxito.";
                    }
                }
                return "Usuario no encontrado para eliminar.";
            } else if (obj instanceof Categoria categoriaBorrar) {
                for (int i = 0; i < categorias.size(); i++) {
                    if (categorias.get(i).getId() == categoriaBorrar.getId()) {
                        eliminarCategoria(i);
                        return "Categoría eliminada con éxito.";
                    }
                }
                return "Categoría no encontrada para eliminar.";
            } else if (obj instanceof EducacionFinanciera eduBorrar) {
                for (int i = 0; i < educacionesFinancieras.size(); i++) {
                    EducacionFinanciera actual = educacionesFinancieras.get(i);
                    if (actual.getTitulo().equalsIgnoreCase(eduBorrar.getTitulo())
                            && actual.getFechaInicio().equals(eduBorrar.getFechaInicio())) {
                        eliminarEducacionFinanciera(i);
                        return "Educación financiera eliminada con éxito.";
                    }
                }
                return "Educación financiera no encontrada para eliminar.";
            }
            return "Tipo de objeto no soportado para eliminar.";
        } catch (Exception e) {
            return "Error al eliminar: " + e.getMessage();
        }
    }
    @Override
    public Object buscarPorId(Integer id) {
        for (Usuario u : usuarios) if (u != null && u.getCodigo() == id) return u;
        for (Categoria c : categorias) if (c != null && c.getId() == id) return c;
        for (EducacionFinanciera e : educacionesFinancieras)  return e;
        return null;
    }

    @Override
    public String listar() {
        StringBuilder sb = new StringBuilder();
        sb.append("Usuarios:\n");
        for (Usuario u : usuarios) if (u != null) sb.append(u).append("\n");
        sb.append("\nCategorías:\n");
        for (Categoria c : categorias) if (c != null) sb.append(c).append("\n");
        sb.append("\nEducación Financiera:\n");
        for (EducacionFinanciera e : educacionesFinancieras) if (e != null) sb.append(e).append("\n");
        return sb.toString();
    }
}
