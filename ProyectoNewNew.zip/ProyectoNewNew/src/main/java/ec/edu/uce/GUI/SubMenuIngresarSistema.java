/**
 * Clase que representa el submenú de ingreso al sistema en MIFO.
 * Permite al usuario gestionar sus credenciales, incluyendo edición, eliminación y consulta.
 */
package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.Empresa;
import ec.edu.uce.Dominio.OrdenarUsuarioPorNombre;
import ec.edu.uce.Dominio.Usuario;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class SubMenuIngresarSistema {
    private Scanner entrada = new Scanner(System.in);
    private Empresa empresa = Empresa.getInstance();
    /**
     * Usuario actualmente autenticado en el sistema.
     */
    private Usuario usuario;


    /**
     * Constructor que inicializa el usuario actual y la lista de usuarios registrados.
     *
     * @param usuario  Usuario autenticado actualmente
     * @param usuario Arreglo de usuarios registrados
     */
    public SubMenuIngresarSistema(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * Muestra el submenú de ingreso al sistema y procesa la opción elegida por el usuario.
     */
    public void menuIngresarSistema() {
        mostrarMenuIngresarSistema();
        int seleccion = ComprobacionMenu.validarOpcionMenu(entrada, 7);
        procesarOpcionIngresarSistema(seleccion);
    }
    /**
     * Muestra las opciones disponibles dentro del submenú de ingreso al sistema.
     */
    private void mostrarMenuIngresarSistema() {
        System.out.println();
        System.out.println("╔═══════════════════════════════════════════════╗");
        System.out.println("║            Ingresar al Sistema                ║");
        System.out.println("╠═══════════════════════════════════════════════╣");
        System.out.println("║                                               ║");
        System.out.println("║  1. Editar credenciales                       ║");
        System.out.println("║  2. Eliminar credenciales                     ║");
        System.out.println("║  3. Consultar credenciales                    ║");
        System.out.println("║  4. Ordenar usuarios por nombre               ║");
        System.out.println("║  5. Consultar todos los usuarios registrados  ║");
        System.out.println("║  6. Volver al menú principal                  ║");
        System.out.println("║  7. Salir del programa                        ║");
        System.out.println("║                                               ║");
        System.out.println("╚═══════════════════════════════════════════════╝");
        System.out.println();
        System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
    }

    /**
     * Procesa la opción elegida en el menú e invoca la funcionalidad correspondiente.
     *
     * @param seleccion Opción elegida por el usuario.
     */
    private void procesarOpcionIngresarSistema(int seleccion) {
        switch (seleccion) {
            case 1:
                try {
                    if (validarCredenciales()) {
                        editarCredenciales();
                    } else {
                        System.out.println("Contraseña incorrecta. No se pueden editar las credenciales.");
                    }
                } catch (ExcepcionMifo.CredencialesInvalidasExcepcion e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 2:
                try {
                    if (validarCredenciales()) {
                        eliminarCredenciales();
                        System.exit(0);
                    } else {
                        System.out.println("Contraseña incorrecta. No se pueden eliminar las credenciales.");
                    }
                } catch (ExcepcionMifo.CredencialesInvalidasExcepcion e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 3:
                try {
                    if (validarCredenciales()) {
                        consultarCredenciales();
                    } else {
                        System.out.println("Contraseña incorrecta. No se pueden consultar las credenciales.");
                    }
                } catch (ExcepcionMifo.CredencialesInvalidasExcepcion e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 4:
                ordenarUsuariosPorNombre();
                break;
            case 5:
                consultarTodosLosUsuarios();
                break;
            case 6:
                System.out.println();
                System.out.println("Volviendo al menú principal...");
                return;
            case 7:
                System.out.println();
                System.out.println("╔══════════════════════════════════════════════════════════════╗");
                System.out.println("║                     Cerrando el sistema                      ║");
                System.out.println("╠══════════════════════════════════════════════════════════════╣");
                System.out.println("║                                                              ║");
                System.out.println("║     ¡Gracias por haber confiado en MIFO!                     ║");
                System.out.println("║                                                              ║");
                System.out.println("║   Esperamos que nuestra plataforma te haya sido de gran      ║");
                System.out.println("║                     ayuda en tus finanzas.                   ║");
                System.out.println("║                                                              ║");
                System.out.println("║              ¡Hasta la próxima!                              ║");
                System.out.println("║                                                              ║");
                System.out.println("╚══════════════════════════════════════════════════════════════╝");
                System.exit(0);
                break;
        }
    }

    /**
     * Valida las credenciales del usuario solicitando su contraseña actual.
     *
     * @return true si la contraseña es válida, false en caso contrario.
     * @throws ExcepcionMifo.CredencialesInvalidasExcepcion Si la contraseña ingresada es incorrecta.
     */
    private boolean validarCredenciales() throws ExcepcionMifo.CredencialesInvalidasExcepcion {
        System.out.print(" | Ingrese su contraseña actual: ");
        String contrasena = entrada.nextLine();
        if (usuario.getContrasena().equals(contrasena)) {
            return true;
        } else {
            throw new ExcepcionMifo.CredencialesInvalidasExcepcion("Contraseña incorrecta. No se pueden validar las credenciales.");
        }
    }

    /**
     * Permite al usuario editar su nombre y contraseña verificando su validez.
     */
    private void editarCredenciales() {
        String nuevoNombre;
        String nuevaContrasena;

        // Validación del nombre de usuario
        do {
            System.out.print(" | Ingrese nuevo nombre (solo letras): ");
            nuevoNombre = entrada.nextLine();
            if (!nuevoNombre.matches("[a-zA-Z]+")) {
                System.out.println("Error: El nombre debe contener solo letras.");
            }
        } while (!nuevoNombre.matches("[a-zA-Z]+"));

        // Validación de la nueva contraseña
        do {
            System.out.print(" | Ingrese nueva contraseña (mínimo 8 caracteres con al menos una letra): ");
            nuevaContrasena = entrada.nextLine();
            if (nuevaContrasena.length() < 8 || !nuevaContrasena.matches(".*[a-zA-Z].*")) {
                System.out.println(" La contraseña debe tener al menos 8 caracteres con al menos una letra.");
            }
        } while (nuevaContrasena.length() < 8 || !nuevaContrasena.matches(".*[a-zA-Z].*"));

        usuario.setNombre(nuevoNombre);
        usuario.setContrasena(nuevaContrasena);
        System.out.println("Credenciales editadas correctamente.");
    }

    /**
     * Elimina las credenciales del usuario borrando su nombre y contraseña.
     */
    private void eliminarCredenciales() {
        usuario.setNombre("");
        usuario.setContrasena("");
        System.out.println("Credenciales eliminadas correctamente.");
        System.out.println("Para volver a utilizar Mifo, deberá crear una nueva cuenta.");
    }

    /**
     * Consulta y muestra en pantalla las credenciales del usuario actual.
     */
    private void consultarCredenciales() {
        System.out.println(" | Código: " + usuario.getCodigo());
        System.out.println(" | Nombre: " + usuario.getNombre());
        System.out.println(" | Contraseña: " + usuario.getContrasena());
    }
    private void consultarTodosLosUsuarios() {
        List<Usuario> listaUsuarios = empresa.getUsuarios();
        if (listaUsuarios.isEmpty()) {
            System.out.println("┌─────────────────────────────────────────────────────────┐");
            System.out.println("│                No hay usuarios registrados             │");
            System.out.println("└─────────────────────────────────────────────────────────┘");
            return;
        }
        System.out.println("┌─────────────────────────────────────────────────────────┐");
        System.out.println("│                   LISTA DE USUARIOS                     │");
        System.out.println("└─────────────────────────────────────────────────────────┘");
        for (Usuario u : listaUsuarios) {
            if (u != null) {
                System.out.println("┌─────────────────────────────────────────────────────────┐");
                System.out.printf("│ Código:      %-42d │%n", u.getCodigo());
                System.out.printf("│ Nombre:      %-42s │%n", u.getNombre());
                System.out.printf("│ Correo:      %-42s │%n", u.getCorreo());
                System.out.printf("│ Contraseña:  %-42s │%n", u.getContrasena());
                System.out.println("└─────────────────────────────────────────────────────────┘");
                System.out.println();
            }
        }
    }
    /**
     * Ordena los usuarios por nombre en orden alfabético ascendente.
     */
    /**
     * Ordena los usuarios por nombre en orden alfabético ascendente.
     */
    public void ordenarUsuariosPorNombre() {
        List<Usuario> listaUsuarios = new ArrayList<>(empresa.getUsuarios());
        if (listaUsuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados para ordenar.");
            return;
        }

        Collections.sort(listaUsuarios, new OrdenarUsuarioPorNombre());

        System.out.println("\n╔═════════════════════════════════════════════════════════╗");
        System.out.println("║                  USUARIOS ORDENADOS POR NOMBRE          ║");
        System.out.println("╠═════════════════════════════════════════════════════════╣");

        for (Usuario u : listaUsuarios) {
            System.out.println("┌─────────────────────────────────────────────────────────┐");
            System.out.printf("│ Código: %-47d │%n", u.getCodigo());
            System.out.printf("│ Nombre: %-47s │%n", u.getNombre());
            System.out.printf("│ Correo: %-47s │%n", u.getCorreo());
            if (u.getContrasena() != null && !u.getContrasena().isEmpty()) {
                System.out.printf("│ Contraseña: %-43s │%n", u.getContrasena());
            }
            System.out.println("└─────────────────────────────────────────────────────────┘");
        }
    }

}