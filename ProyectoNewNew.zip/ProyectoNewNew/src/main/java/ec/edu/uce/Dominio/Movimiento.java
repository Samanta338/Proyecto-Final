package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import java.util.Date;
/**
 * Clase abstracta que representa un movimiento financiero.
 */
public abstract class Movimiento implements Comparable<Movimiento> {
    protected String descripcion;
    protected Double monto;
    protected Date fecha;
    protected Categoria categoria;
    private static int contadorGlobal;
    private final int codigoUnico;
    static {
        contadorGlobal = 1;
    }
    {
        codigoUnico = contadorGlobal++;
    }
     // 1.- Constructor por defecto
    public Movimiento() {
        this("Sin descripción", 0.0, new Date(), new Categoria("Otro"));
    }
     //2.-Constructor que inicializa todos los atributos.
    public Movimiento(String descripcion, double monto, Date fecha, Categoria categoria) {
        this.descripcion = descripcion;
        this.monto = monto;
        this.fecha = fecha;
        this.categoria = categoria;
    }
     // 3.- Constructor que inicializa descripción, monto y categoría,
    public Movimiento(String descripcion, double monto, Categoria categoria) {
        this(descripcion, monto, new Date(), categoria);
    }
     //4.- Constructor que inicializa descripción y categoría,
    public Movimiento(String descripcion, Categoria categoria) {
        this(descripcion, 0.0, new Date(), categoria);
    }
    // 5.- Constructor con monto y categoría
    public Movimiento(double monto, Categoria categoria) {
        this("Sin descripción", monto, new Date(), categoria);
    }
    // 6.- Constructor con solo monto
    public Movimiento(double monto) {
        this("Sin descripción", monto, new Date(), new Categoria("Otro"));
    }
    public int getCodigoUnico() {
        return codigoUnico;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public double getMonto() {
        return monto;
    }
    public void setMonto(double monto) {
        this.monto = monto;
    }
    public Date getFecha() {
        return fecha;
    }
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    public Categoria getCategoria() {
        return categoria;
    }
    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
    /**
     * Compara dos movimientos para determinar si son iguales.
     * Dos movimientos son iguales si tienen igual descripción, monto, fecha y categoría.
     *
     * @param object Objeto a comparar
     * @return true si son iguales, false en caso contrario
     */
    @Override
    public boolean equals(Object object) {
        if (object == null || !(object instanceof Movimiento)) {
            return false;
        }
        Movimiento otroMovimiento = (Movimiento) object;
        boolean resp = Double.compare(this.monto, otroMovimiento.monto) == 0
                && (this.fecha == null ? otroMovimiento.fecha == null : this.fecha.equals(otroMovimiento.fecha))
                && (this.descripcion == null ? otroMovimiento.descripcion == null : this.descripcion.equals(otroMovimiento.descripcion))
                && (this.categoria == null ? otroMovimiento.categoria == null : this.categoria.equals(otroMovimiento.categoria));
        return resp;
    }
    /**
     * Representación en texto del movimiento.
     * Muestra descripción, monto, fecha y categoría.
     *
     * @return Cadena con la información del movimiento
     */
    @Override
    public String toString() {
        return String.format("Detalle:\n" +
                        "\tDescripción: %s\n" +
                        "\tMonto:       %.2f\n" +
                        "\tFecha:       %s\n" +
                        "\tCategoría:   %s",
                descripcion,
                monto,
                fecha,
                categoria.getNombreCategoria());
    }
     // Registra el movimiento.
    public abstract boolean registrar();
    public abstract void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion;
    public abstract boolean validarDuplicado(Movimiento otroMovimiento);
    public int compareTo(Movimiento mov1) {
        int resultado = this.monto.compareTo(mov1.getMonto());
        if (resultado > 0){
            return 1;
        } else if (resultado < 0){
            return -1;
        } else {
            return 0;
        }
    }

}
