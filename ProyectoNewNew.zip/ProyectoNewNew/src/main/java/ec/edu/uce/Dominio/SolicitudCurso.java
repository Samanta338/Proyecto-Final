package ec.edu.uce.Dominio;
import java.util.Date;
/**
 * Representa una solicitud para inscribirse a un curso de educación financiera.
 * Mantiene una relación de asociación con EducacionFinanciera:
 * 1 SolicitudCurso está asociada a 1 EducacionFinanciera (1 a 1).
 * Desde el lado de EducacionFinanciera: 1 EducacionFinanciera puede tener 0..n SolicitudCurso.
 */
public class SolicitudCurso {
    // Relación de asociación: 1 SolicitudCurso a 1 EducacionFinanciera
    private EducacionFinanciera cursoSolicitado;
    private Usuario usuario;
    private Date fechaSolicitud;
    private static int contadorCodigo = 0;
    private final int codigo;
    /**
     * 1.- Constructor por defecto.
     * Inicializa la fecha de solicitud con la fecha actual,
     * y deja el curso solicitado y usuario en null.
     */
    public SolicitudCurso() {
        this.codigo = ++contadorCodigo;
        this.fechaSolicitud = new Date();
        this.usuario = null;
        this.cursoSolicitado = null;
    }

    /**
     * 2.- Constructor con curso solicitado.
     * Inicializa el curso solicitado y establece la fecha de solicitud a la fecha actual.
     * El usuario queda en null.
     *
     * @param cursoSolicitado Curso al que se solicita inscripción.
     */
    public SolicitudCurso(EducacionFinanciera cursoSolicitado) {
        this.codigo = ++contadorCodigo;
        this.cursoSolicitado = cursoSolicitado;
        this.fechaSolicitud = new Date();
        this.usuario = null;
    }

    /**
     * 3.- Constructor con usuario.
     * Inicializa el usuario que hace la solicitud y establece la fecha de solicitud a la fecha actual.
     * El curso solicitado queda en null.
     *
     * @param usuario Usuario que hace la solicitud.
     */
    public SolicitudCurso(Usuario usuario) {
        this.codigo = ++contadorCodigo;
        this.usuario = usuario;
        this.fechaSolicitud = new Date();
        this.cursoSolicitado = null;
    }

    /**
     * 4.- Constructor completo.
     * Inicializa el curso solicitado y el usuario, asignando la fecha de solicitud a la fecha actual.
     *
     * @param cursoSolicitado Curso al que se solicita inscripción.
     * @param usuario Usuario que hace la solicitud.
     */
    public SolicitudCurso(EducacionFinanciera cursoSolicitado, Usuario usuario) {
        this.codigo = ++contadorCodigo;
        this.cursoSolicitado = cursoSolicitado;
        this.usuario = usuario;
        this.fechaSolicitud = new Date();
    }
    /**
     * 5.-Constructor completo con fecha específica.
     * Inicializa todos los campos con los valores proporcionados.
     *
     * @param cursoSolicitado Curso al que se solicita inscripción.
     * @param usuario Usuario que hace la solicitud.
     * @param fechaSolicitud Fecha específica de la solicitud.
     */
    public SolicitudCurso(EducacionFinanciera cursoSolicitado, Usuario usuario, Date fechaSolicitud) {
        this.codigo = ++contadorCodigo;
        this.cursoSolicitado = cursoSolicitado;
        this.usuario = usuario;
        this.fechaSolicitud = fechaSolicitud;
    }

    // Getters y Setters

    public EducacionFinanciera getCursoSolicitado() {
        return cursoSolicitado;
    }

    /**
     * Establece el curso solicitado para esta solicitud.
     * @param cursoSolicitado El curso de educación financiera solicitado.
     */
    public void setCursoSolicitado(EducacionFinanciera cursoSolicitado) {
        this.cursoSolicitado = cursoSolicitado;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Date fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }
    public int getCodigo() {
        return codigo;
    }

    /**
     * Equals para comparar dos solicitudes.
     */
    @Override
    public boolean equals(Object o) {
        boolean result = false;
        if (o != null && o instanceof SolicitudCurso) {
            SolicitudCurso that = (SolicitudCurso) o;

            // Compara los campos importantes
            boolean cursoIgual = (this.cursoSolicitado == null && that.cursoSolicitado == null) ||
                    (this.cursoSolicitado != null && this.cursoSolicitado.equals(that.cursoSolicitado));

            boolean usuarioIgual = (this.usuario == null && that.usuario == null) ||
                    (this.usuario != null && this.usuario.equals(that.usuario));

            boolean fechaIgual = (this.fechaSolicitud == null && that.fechaSolicitud == null) ||
                    (this.fechaSolicitud != null && this.fechaSolicitud.equals(that.fechaSolicitud));

            if (cursoIgual && usuarioIgual && fechaIgual) {
                result = true;
            }
        }
        return result;
    }

    /**
     * toString con información completa de la solicitud.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Solicitud de curso:\n");

        if (cursoSolicitado != null) {
            sb.append("Curso: ").append(cursoSolicitado.getTitulo()).append("\n");
        } else {
            sb.append("Curso: No especificado\n");
        }

        if (usuario != null) {
            sb.append("Usuario: ").append(usuario.toString()).append("\n");
        } else {
            sb.append("Usuario: No especificado\n");
        }

        sb.append("Fecha de solicitud: ").append(fechaSolicitud);

        return sb.toString();
    }

}
