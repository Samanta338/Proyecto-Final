package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ExcepcionMifo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 * Clase que representa un usuario del sistema financiero.
 * Contiene información personal y arreglos dinámicos de presupuestos y solicitudes de curso.
 */
public class Usuario implements IAdministrarCRUD {
    private String nombre;
    private String correo;
    private String cedula;
    private String contrasena;
    public static void reiniciarContador() {
        contadorUsuarios = 0;
    }
    // Contador estático para IDs automáticos
    private static int contadorUsuarios = 0;
    private final int codigo;
    private List<Presupuesto> presupuestos = new ArrayList<>();
    /**
     * Arreglo de solicitudes de cursos asociadas a este usuario.
     * Relación: Un Usuario puede tener cero o más SolicitudCurso.
     * Multiplicidad: 1 Usuario --- 0..n SolicitudCurso
     */
    private List<SolicitudCurso> solicitudes = new ArrayList<>();
    /**
     * Constructor principal para crear un usuario con nombre, contraseña, correo,
     * número inicial de presupuestos y código.
     *
     * @param nombre          nombre del usuario
     * @param contrasena      contraseña del usuario
     * @param correo          correo electrónico del usuario
     */
    public Usuario(String nombre, String contrasena, String correo) {
        this.codigo = ++contadorUsuarios;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.correo = correo;
    }
    public Usuario(String nombre, String correo) {
        this.codigo = ++contadorUsuarios;
        this.nombre = nombre;
        this.correo = correo;
    }
    public Usuario(String nombre, String contrasena, String correo, boolean esInvitado) {
        if (esInvitado) {
            this.codigo = 0;
        } else {
            this.codigo = ++contadorUsuarios;
        }
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.correo = correo;
    }
    public Usuario(int codigo, String nombre, String contrasena, String correo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.correo = correo;
    }
    /**
     * Obtiene el nombre del usuario.
     *
     * @return nombre del usuario
     */
    public String getNombre() {
        return nombre;
    }
    /**
     * Establece el nombre del usuario.
     *
     * @param nombre nuevo nombre a establecer
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    /**
     * Obtiene el código identificador del usuario.
     *
     * @return código del usuario
     */
    public int getCodigo() {
        return codigo;
    }
    /**
     * Obtiene el correo electrónico del usuario.
     *
     * @return correo electrónico
     */
    public String getCorreo() {
        return correo;
    }
    /**
     * Establece el correo electrónico del usuario.
     *
     * @param correo nuevo correo a establecer
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    /**
     * Obtiene la cédula del usuario.
     *
     * @return cédula del usuario
     */
    public String getCedula() {
        return cedula;
    }
    /**
     * Establece la cédula del usuario.
     *
     * @param cedula nueva cédula a establecer
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
    /**
     * Obtiene la contraseña del usuario.
     *
     * @return contraseña del usuario
     */
    public String getContrasena() {
        return contrasena;
    }
    /**
     * Establece la contraseña del usuario.
     *
     * @param contrasena nueva contraseña a establecer
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    /**
     * Obtiene una copia del arreglo de presupuestos.
     *
     * @return arreglo con los presupuestos actuales
     */
    public List<Presupuesto> getPresupuestos() {
        return presupuestos;
    }
    public void setPresupuestos(List<Presupuesto> presupuestos) {
        if (presupuestos != null) {
            this.presupuestos = new ArrayList<>(presupuestos);
        }
    }
    public List<SolicitudCurso> getSolicitudes() {
        return new ArrayList<>(solicitudes);
    }
    public void setSolicitudes(List<SolicitudCurso> solicitudes) {
        if (solicitudes != null) {
            this.solicitudes = new ArrayList<>(solicitudes);
        }
    }
    public void agregarPresupuesto(Double presupuesto, Date fecha) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Presupuesto nuevoPresupuesto = new Presupuesto(presupuesto, fecha);

        if (validarDuplicado(nuevoPresupuesto)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un presupuesto con el mismo valor y fecha.");
        }

        // Inicializa movimientos si es el primer presupuesto
        if (presupuestos.isEmpty()) {
            nuevoPresupuesto.inicializarMovimientos();
        }

        presupuestos.add(nuevoPresupuesto);
    }

    public String agregarPresupuesto(double monto, String fechaStr, double gastoTotal, double ingresoTotal) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date fecha = sdf.parse(fechaStr);

            Presupuesto nuevo = new Presupuesto(monto, fecha, gastoTotal, ingresoTotal);
            agregarPresupuesto(nuevo);

            return "Presupuesto agregado correctamente para la fecha: " + fechaStr;
        } catch (ParseException e) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Fecha inválida: " + fechaStr);
        }
    }

    public String agregarPresupuesto(Presupuesto nuevoPresupuesto) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        if (validarDuplicado(nuevoPresupuesto)) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Ya existe un presupuesto con el mismo valor y fecha.");
        }

        // List se encarga del crecimiento dinámico internamente
        presupuestos.add(nuevoPresupuesto);

        return "Presupuesto: " + nuevoPresupuesto.getMontoPresupuesto() + "\nFecha: " + nuevoPresupuesto.getFecha();
    }
    /**
     * Agrega un nuevo presupuesto con todos los datos sin necesidad de crear el objeto manualmente.
     *
     * @param monto Monto del presupuesto.
     * @param fecha Fecha del presupuesto.
     * @param gastoTotal Gasto total del presupuesto.
     * @param ingresoTotal Ingreso total del presupuesto.
     * @return Mensaje de confirmación.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si ya existe un presupuesto igual.
     */
    public String agregarPresupuesto(double monto, Date fecha, double gastoTotal, double ingresoTotal) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        Presupuesto nuevo = new Presupuesto(monto, fecha, gastoTotal, ingresoTotal);
        agregarPresupuesto(nuevo);
        return "Presupuesto agregado correctamente.";
    }
    public Usuario(String nombre, String contrasena, String correo, String cedula) {
        this.codigo = ++contadorUsuarios;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.correo = correo;
        this.cedula = cedula;

    }
    /**
     * CRUD: consultar presupuestos
     *
     * Consulta todos los presupuestos almacenados y devuelve su información
     * en formato de texto concatenado.
     *
     * @return Cadena con la información de todos los presupuestos
     */
    public String consultarPresupuestos() {
        String texto = "";
        for (Presupuesto p : presupuestos) {
            if (p != null) {
                texto += p + "\r\n";
            }
        }
        return texto;
    }
    public String consultarPresupuesto() {
        StringBuilder texto = new StringBuilder();
        for (Presupuesto presupuesto : presupuestos) {
            if (presupuesto != null) {
                texto.append(presupuesto).append("\n");
            }
        }
        return texto.toString();
    }
    public void editarPresupuesto(int indice, double presupuesto, Date fecha, double gastoTotal, double ingresoTotal) {
        if (indice >= 0 && indice < presupuestos.size()) {
            Presupuesto p = presupuestos.get(indice);
            if (p != null) {
                p.setMontoPresupuesto(presupuesto);
                p.setFecha(fecha);
                p.setGastoTotal(gastoTotal);
                p.setIngresoTotal(ingresoTotal);
            } else {
                System.out.println("El presupuesto en el índice " + indice + " es nulo.");
            }
        } else {
            System.out.println("Índice fuera de rango: " + indice);
        }
    }
    /**
     * Edita un presupuesto existente en el arreglo según el índice dado, actualizando sus datos individuales.
     *
     * @param indice      Posición del presupuesto a editar
     * @param monto       Nuevo monto del presupuesto
     * @param fecha       Nueva fecha del presupuesto
     * @param gastoTotal  Nuevo gasto total
     * @param ingresoTotal Nuevo ingreso total
     */
    public void editarPresupuesto(int indice, double monto, String fecha, double gastoTotal, double ingresoTotal) {
        if (indice >= 0 && indice < presupuestos.size()) {
            Presupuesto p = presupuestos.get(indice);
            if (p != null) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); // O "yyyy-MM-dd" según el formato de entrada
                    Date fechaConvertida = sdf.parse(fecha);
                    p.setMontoPresupuesto(monto);
                    p.setFecha(fechaConvertida);
                    p.setGastoTotal(gastoTotal);
                    p.setIngresoTotal(ingresoTotal);
                    System.out.println("Presupuesto editado exitosamente.");
                } catch (ParseException e) {
                    System.out.println("Error al convertir la fecha: " + fecha);
                }
            } else {
                System.out.println("El presupuesto en el índice " + indice + " es nulo.");
            }
        } else {
            System.out.println("Índice inválido para editar presupuesto.");
        }
    }
    public void editarPresupuesto(int indice, Presupuesto nuevoPresupuesto) {
        if (indice >= 0 && indice < presupuestos.size()) {
            Presupuesto actual = presupuestos.get(indice);
            if (actual != null && nuevoPresupuesto != null) {
                actual.setMontoPresupuesto(nuevoPresupuesto.getMontoPresupuesto());
                actual.setFecha(nuevoPresupuesto.getFecha());
                actual.setGastoTotal(nuevoPresupuesto.getGastoTotal());
                actual.setIngresoTotal(nuevoPresupuesto.getIngresoTotal());
            }
        } else {
            System.out.println("Índice inválido para editar presupuesto.");
        }
    }
    /**
     * CRUD: Eliminar presupuesto por objeto
     *
     * Elimina un presupuesto específico comparando la referencia del objeto.
     *
     * @param presupuesto Objeto presupuesto a eliminar
     * @return true si se eliminó exitosamente, false si no se encontró
     */
    public boolean eliminarPresupuesto(Presupuesto presupuesto) {
        if (presupuesto == null) {
            System.out.println("El presupuesto no puede ser null.");
            return false;
        }
        boolean eliminado = presupuestos.remove(presupuesto);
        if (eliminado) {
            return true;
        } else {
            System.out.println("El presupuesto especificado no se encontró en la lista.");
            return false;
        }
    }
    /**
     * CRUD: Eliminar presupuesto por monto exacto
     *
     * Busca y elimina el primer presupuesto que tenga el monto especificado.
     *
     * @param monto Monto del presupuesto a eliminar
     * @return true si se eliminó exitosamente, false si no se encontró
     */
    public boolean eliminarPresupuesto(double monto) {
        for (int i = 0; i < presupuestos.size(); i++) {
            Presupuesto p = presupuestos.get(i);
            if (p != null && Double.compare(p.getMontoPresupuesto(), monto) == 0) {
                presupuestos.remove(i);
                return true;
            }
        }
        System.out.println("No se encontró un presupuesto con monto: " + monto);
        return false;
    }


    public void eliminarPresupuesto(int indice) {
        if (indice >= 0 && indice < presupuestos.size()) {
            presupuestos.remove(indice);
            System.out.println("Presupuesto eliminado en el índice " + indice);
        } else {
            System.out.println("Índice fuera de rango: " + indice);
        }
    }

    public Presupuesto buscarPresupuesto(int indice) {
        if (indice >= 0 && indice < presupuestos.size()) {
            return presupuestos.get(indice);
        } else {
            return null;
        }
    }


    /**
     * Inicializa el arreglo de presupuestos del usuario con datos de ejemplo.
     * Cada presupuesto incluye monto, fecha, gasto total e ingreso total.
     * Se agregan tres presupuestos con valores predeterminados para uso inicial.
     *
     * Este método utiliza el método agregarPresupuesto para añadir los presupuestos
     * y maneja la excepción MovimientoInvalidoExcepcion en caso de duplicados o errores.
     */
    public void inicializarPresupuestos() {
        try {
            agregarPresupuesto(2000.0, "14/05/2025", 100.0, 50.0);
            agregarPresupuesto(3000.0, "15/05/2025", 150.0, 75.0);
            agregarPresupuesto(2000.0, "16/05/2025", 120.0, 60.0);
            agregarPresupuesto(2200.0, "17/05/2025", 130.0, 65.0);
            agregarPresupuesto(2700.0, "18/05/2025", 100.0, 70.0);
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al inicializar presupuestos: " + e.getMessage());
        }
    }
    // AÑADIDO PARA VALIDAR DUPLICADOS DE PRESUPUESTOS EN USUARIO
    public boolean validarDuplicado(Presupuesto nuevoPresupuesto) {
        for (Presupuesto p : presupuestos) {
            if (p != null &&
                    Double.compare(p.getMontoPresupuesto(), nuevoPresupuesto.getMontoPresupuesto()) == 0 &&
                    ((p.getFecha() == null && nuevoPresupuesto.getFecha() == null) ||
                            (p.getFecha() != null && p.getFecha().equals(nuevoPresupuesto.getFecha())))) {
                return true;
            }
        }
        return false;
    }
    public void cambiarContrasena(String contrasenaActual, String nuevaContrasena) throws ExcepcionMifo.ContrasenaInvalidaExcepcion {
        if (this.contrasena.equals(contrasenaActual)) {
            this.contrasena = nuevaContrasena;
            System.out.println("Contraseña cambiada correctamente.");
        } else {
            throw new ExcepcionMifo.ContrasenaInvalidaExcepcion("La contraseña actual no coincide. No se pudo cambiar la contraseña.");
        }
    }
    // AÑADIDO PARA COMPARAR USUARIOS (equals)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario)) return false;
        Usuario usuario = (Usuario) o;
        return codigo == usuario.codigo;
    }
    /*
     * Método toString sobrescrito para mostrar una representación en cadena
     * de la instancia de Usuario, mostrando atributos básicos y cantidades de arreglos.
     *
     * @return cadena representativa del usuario
     */
    @Override
    public String toString() {
        return String.format(
                "Usuario:\n" +
                        "\tNombre:        %s\n" +
                        "\tCorreo:        %s\n" +
                        "\tCédula:        %s\n" +
                        "\tNum Presupuestos: %d\n" +
                        "\tNum Solicitudes:  %d",
                nombre,
                correo,
                cedula,
                presupuestos.size(),
                solicitudes.size()
        );
    }
    // CRUD: ***************************************************
    // NUEVO
    @Override
    public String nuevo(Object obj) {
        if (obj instanceof Presupuesto) {
            try {
                Presupuesto presupuestoNuevo = (Presupuesto) obj;
                return agregarPresupuesto(presupuestoNuevo);
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                return "Error al agregar presupuesto: " + e.getMessage();
            }
        }
        return "Tipo de objeto no válido para agregar en Usuario.";
    }
    @Override
    public String editar(Object obj) {
        if (obj instanceof Presupuesto presupuesto) {
            for (int i = 0; i < presupuestos.size(); i++) {
                Presupuesto actual = presupuestos.get(i);
                if (actual != null && actual.equals(presupuesto)) {
                    presupuestos.set(i, presupuesto);
                    return "Presupuesto editado correctamente.";
                }
            }
            return "Presupuesto no encontrado.";
        }
        return "Tipo de objeto no válido para editar.";
    }


    @Override
    public String borrar(Object obj) {
        if (obj instanceof Presupuesto presupuesto) {
            boolean eliminado = eliminarPresupuesto(presupuesto);
            return eliminado ? "Presupuesto eliminado correctamente." : "Presupuesto no encontrado.";
        }
        return "Tipo de objeto no válido para eliminar.";
    }
    public int compareTo(Usuario usu1) {
        int resultado = this.nombre.compareTo(usu1.getNombre());
        if (resultado > 0){
            return 1;
        } else if (resultado < 0){
            return -1;
        } else {
            return 0;
        }
    }
    @Override
    public Object buscarPorId(Integer id) {
        if (id != null && id >= 0 && id < presupuestos.size()) {
            return presupuestos.get(id);
        } else {
            return null;
        }
    }

    @Override
    public String listar() {
        return consultarPresupuesto();
    }
}
