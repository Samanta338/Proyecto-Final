package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ExcepcionMifo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Ingreso extends Movimiento {
    private static final TipoMovimiento tipoMovimiento = TipoMovimiento.INGRESO;
    // 1.- Constructor por defecto
    public Ingreso() {
        super("Sin descripción", 0.0, new Date(), new Categoria("Otro"));
    }
    // 2.- Constructor con todos los parámetros excepto tipoMovimiento (es propio)
    public Ingreso(String descripcion, double monto, Date fecha, Categoria categoria) {
        super(descripcion, monto, fecha, categoria);
    }
    // 3.- Constructor con descripción, monto y categoría (fecha actual)
    public Ingreso(String descripcion, double monto, Categoria categoria) {
        super(descripcion, monto, new Date(), categoria);
    }
    // 4.- Constructor con descripción y categoría (monto 0.0, fecha actual)
    public Ingreso(String descripcion, Categoria categoria) {
        super(descripcion, 0.0, new Date(), categoria);
    }
    // 5.- Constructor con descripción, monto y fecha (categoría "Otro")
    public Ingreso(String descripcion, double monto, Date fecha) {
        this(descripcion, monto, fecha, new Categoria("Otro"));
    }
    // 6.- Constructor con descripción y monto (fecha actual y categoría "Otro")
    public Ingreso(String descripcion, double monto) {
        this(descripcion, monto, new Date(), new Categoria("Otro"));
    }
    public TipoMovimiento getTipoMovimiento() {
        return tipoMovimiento;
    }
    @Override
    public boolean validarDuplicado(Movimiento otroMovimiento) {
        if (otroMovimiento instanceof Ingreso) {
            return this.equals(otroMovimiento);
        }
        return false;
    }
    // Sobreescritura del método registrar para representar el objeto como texto
    @Override
    public boolean registrar() {
        if (this.monto <= 0.0) {
            return false;
        } else {
            System.out.println("Ingreso registrado: "
                    + "\nDescripción: " + descripcion
                    + "\nMonto: " + monto
                    + "\nFecha: " + fecha
                    + "\nCategoría: " + categoria.getNombreCategoria()
                    + "\nTipo de Movimiento: " + tipoMovimiento.getDescripcion()
                    + "\nCódigo único: " + getCodigoUnico()  // <---- código único del movimiento
                    + "\nPrioridad: " + tipoMovimiento.getPrioridad()
                    + "\nLímite mensual sugerido: " + tipoMovimiento.getLimiteMensualSugerido());
            return true;
        }
    }
    @Override
    public void realizar() throws ExcepcionMifo.SaldoInsuficienteExcepcion, ExcepcionMifo.MovimientoInvalidoExcepcion {
        System.out.println("Realizando ingreso: "
                + "\nDescripción: " + descripcion
                + "\nMonto: " + monto
                + "\nFecha: " + fecha
                + "\nCategoría: " + categoria.getNombreCategoria()
                + "\nTipo de Movimiento: " + tipoMovimiento.getDescripcion()
                + "\nCódigo único: " + getCodigoUnico()
                + "\nPrioridad: " + tipoMovimiento.getPrioridad());
    }
    @Override
    public String toString() {
        return String.format("Ingreso:\n%s\n" +
                        "\tCódigo único:            %d\n" +
                        "\tTipo de Movimiento:      %s\n" +
                        "\tPrioridad:               %s\n" +
                        "\tLímite mensual sugerido: %.2f",
                super.toString(),
                getCodigoUnico(),
                tipoMovimiento.getDescripcion(),
                tipoMovimiento.getPrioridad(),
                tipoMovimiento.getLimiteMensualSugerido());
    }

}
