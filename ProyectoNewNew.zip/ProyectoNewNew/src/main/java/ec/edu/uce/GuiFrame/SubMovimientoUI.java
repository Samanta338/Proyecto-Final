package ec.edu.uce.GuiFrame;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
public class SubMovimientoUI extends JFrame {
    private static final Color SOFT_GREEN = new Color(162, 194, 152);
    private static final Color SAGE_GREEN = new Color(134, 167, 123);
    private static final Color MINT_CREAM = new Color(247, 250, 245);
    private static final Color DARK_GREEN = new Color(85, 107, 47);
    private static final Color LIGHT_GREEN = new Color(198, 219, 191);
    private static final Color FOREST_GREEN = new Color(46, 84, 48);

    private JTable movimientosTable;
    private DefaultTableModel tableModel;
    private JButton crearButton, editarButton, eliminarButton, consultarButton, ordenarButton, volverButton;
    private JComboBox<String> presupuestoSelector;
    private List<PresupuestoData> presupuestos;
    private List<MovimientoData> movimientos;
    private PresupuestoData presupuestoSeleccionado;

    // Clases internas simplificadas
    private static class PresupuestoData {
        private int id;
        private double monto;
        private Date fecha;
        private List<MovimientoData> movimientos;

        public PresupuestoData(int id, double monto, Date fecha) {
            this.id = id;
            this.monto = monto;
            this.fecha = fecha;
            this.movimientos = new ArrayList<>();
        }

        public int getId() { return id; }
        public double getMonto() { return monto; }
        public Date getFecha() { return fecha; }
        public List<MovimientoData> getMovimientos() { return movimientos; }

        @Override
        public String toString() {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            return "Presupuesto $" + String.format("%.2f", monto) + " - " + sdf.format(fecha);
        }
    }

    private static class MovimientoData {
        private int id;
        private String descripcion;
        private double monto;
        private Date fecha;
        private String tipo;
        private String categoria;
        private String codigoUnico;

        public MovimientoData(int id, String descripcion, double monto, Date fecha, String tipo, String categoria) {
            this.id = id;
            this.descripcion = descripcion;
            this.monto = monto;
            this.fecha = fecha;
            this.tipo = tipo;
            this.categoria = categoria;
            this.codigoUnico = "MOV" + String.format("%06d", id);
        }

        // Getters y Setters
        public int getId() { return id; }
        public String getDescripcion() { return descripcion; }
        public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
        public double getMonto() { return monto; }
        public void setMonto(double monto) { this.monto = monto; }
        public Date getFecha() { return fecha; }
        public void setFecha(Date fecha) { this.fecha = fecha; }
        public String getTipo() { return tipo; }
        public void setTipo(String tipo) { this.tipo = tipo; }
        public String getCategoria() { return categoria; }
        public void setCategoria(String categoria) { this.categoria = categoria; }
        public String getCodigoUnico() { return codigoUnico; }
    }

    public SubMovimientoUI() {
        setTitle("MIFO - Gestionar Movimientos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 700));
        setSize(1300, 900);
        setLocationRelativeTo(null);

        initializeTestData();
        initializeComponents();
        configurarEventos();
    }

    private void initializeTestData() {
        presupuestos = new ArrayList<>();
        Calendar cal = Calendar.getInstance();

        PresupuestoData p1 = new PresupuestoData(1, 5000.0, cal.getTime());
        p1.getMovimientos().add(new MovimientoData(1, "Salario", 2500.0, cal.getTime(), "INGRESO", "Trabajo"));
        p1.getMovimientos().add(new MovimientoData(2, "Compras", 150.0, cal.getTime(), "GASTO", "Comida"));

        presupuestos.add(p1);
        presupuestoSeleccionado = p1;
        movimientos = p1.getMovimientos();
    }

    private void initializeComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_CREAM);

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(LIGHT_GREEN);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        JLabel title = new JLabel("GESTIÓN DE MOVIMIENTOS", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(FOREST_GREEN);
        headerPanel.add(title);

        // Selector
        JPanel selectorPanel = new JPanel(new FlowLayout());
        selectorPanel.setBackground(MINT_CREAM);
        JLabel selectorLabel = new JLabel("Seleccionar Presupuesto:");
        selectorLabel.setFont(new Font("Arial", Font.BOLD, 16));
        presupuestoSelector = new JComboBox<>();
        presupuestoSelector.setPreferredSize(new Dimension(300, 35));
        for (PresupuestoData p : presupuestos) {
            presupuestoSelector.addItem(p.toString());
        }
        selectorPanel.add(selectorLabel);
        selectorPanel.add(presupuestoSelector);

        // Tabla
        String[] columns = {"ID", "Tipo", "Descripción", "Monto", "Fecha", "Categoría", "Código"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        movimientosTable = new JTable(tableModel);
        configurarTabla();

        JScrollPane scrollPane = new JScrollPane(movimientosTable);
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Lista de Movimientos"));
        tablePanel.add(scrollPane);

        // Botones
        JPanel buttonPanel = createButtonPanel();

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(selectorPanel, BorderLayout.PAGE_START);
        mainPanel.add(tablePanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
        actualizarTabla();
    }

    private void configurarTabla() {
        movimientosTable.setFont(new Font("Arial", Font.PLAIN, 12));
        movimientosTable.setRowHeight(35);
        movimientosTable.setSelectionBackground(LIGHT_GREEN);

        JTableHeader header = movimientosTable.getTableHeader();
        header.setBackground(SAGE_GREEN);
        header.setFont(new Font("Arial", Font.BOLD, 12));

        // Centrar columnas numéricas
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        movimientosTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        movimientosTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 3, 10, 10));
        panel.setBackground(MINT_CREAM);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        crearButton = createButton("Crear");
        editarButton = createButton("Editar");
        eliminarButton = createButton("Eliminar");
        consultarButton = createButton("Consultar");
        ordenarButton = createButton("Ordenar");
        volverButton = createButton("Volver");

        panel.add(crearButton);
        panel.add(editarButton);
        panel.add(eliminarButton);
        panel.add(consultarButton);
        panel.add(ordenarButton);
        panel.add(volverButton);

        return panel;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(SAGE_GREEN);
        button.setPreferredSize(new Dimension(150, 50));
        button.setFocusPainted(false);

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(DARK_GREEN);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(SAGE_GREEN);
            }
        });

        return button;
    }

    private void configurarEventos() {
        presupuestoSelector.addActionListener(e -> {
            int index = presupuestoSelector.getSelectedIndex();
            if (index >= 0) {
                presupuestoSeleccionado = presupuestos.get(index);
                movimientos = presupuestoSeleccionado.getMovimientos();
                actualizarTabla();
            }
        });

        crearButton.addActionListener(e -> mostrarDialogoCrear());
        editarButton.addActionListener(e -> mostrarDialogoEditar());
        eliminarButton.addActionListener(e -> eliminarMovimiento());
        consultarButton.addActionListener(e -> consultarMovimiento());
        ordenarButton.addActionListener(e -> ordenarPorMonto());
        volverButton.addActionListener(e -> dispose());
    }

    private void actualizarTabla() {
        tableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        for (MovimientoData m : movimientos) {
            Object[] row = {
                    m.getId(),
                    m.getTipo(),
                    m.getDescripcion(),
                    String.format("%.2f", m.getMonto()),
                    sdf.format(m.getFecha()),
                    m.getCategoria(),
                    m.getCodigoUnico()
            };
            tableModel.addRow(row);
        }
    }
    private void mostrarDialogoCrear() {
        JDialog dialog = new JDialog(this, "Crear Movimiento", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JComboBox<String> tipoCombo = new JComboBox<>(new String[]{"INGRESO", "GASTO"});
        JTextField descripcionField = new JTextField(20);
        JTextField montoField = new JTextField(20);
        JTextField categoriaField = new JTextField(20);
        gbc.gridx = 0; gbc.gridy = 0; panel.add(new JLabel("Tipo:"), gbc);
        gbc.gridx = 1; panel.add(tipoCombo, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panel.add(new JLabel("Descripción:"), gbc);
        gbc.gridx = 1; panel.add(descripcionField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; panel.add(new JLabel("Monto:"), gbc);
        gbc.gridx = 1; panel.add(montoField, gbc);
        gbc.gridx = 0; gbc.gridy = 3; panel.add(new JLabel("Categoría:"), gbc);
        gbc.gridx = 1; panel.add(categoriaField, gbc);
        JPanel buttonPanel = new JPanel();
        JButton crear = new JButton("Crear");
        JButton cancelar = new JButton("Cancelar");
        crear.addActionListener(e -> {
            try {
                String tipo = (String) tipoCombo.getSelectedItem();
                String descripcion = descripcionField.getText().trim();
                double monto = Double.parseDouble(montoField.getText());
                String categoria = categoriaField.getText().trim();
                if (descripcion.isEmpty() || monto <= 0) {
                    JOptionPane.showMessageDialog(dialog, "Datos inválidos");
                    return;
                }
                int nuevoId = movimientos.stream().mapToInt(MovimientoData::getId).max().orElse(0) + 1;
                MovimientoData nuevo = new MovimientoData(nuevoId, descripcion, monto, new Date(), tipo, categoria);
                movimientos.add(nuevo);
                actualizarTabla();
                dialog.dispose();
                JOptionPane.showMessageDialog(this, "Movimiento creado exitosamente");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
            }
        });
        cancelar.addActionListener(e -> dialog.dispose());
        buttonPanel.add(crear);
        buttonPanel.add(cancelar);
        dialog.add(panel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }
    private void mostrarDialogoEditar() {
        int row = movimientosTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un movimiento");
            return;
        }
        MovimientoData movimiento = movimientos.get(row);
        String descripcion = JOptionPane.showInputDialog(this, "Nueva descripción:", movimiento.getDescripcion());
        if (descripcion != null && !descripcion.trim().isEmpty()) {
            movimiento.setDescripcion(descripcion.trim());
            actualizarTabla();
            JOptionPane.showMessageDialog(this, "Movimiento actualizado");
        }
    }
    private void eliminarMovimiento() {
        int row = movimientosTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un movimiento");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar movimiento?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            movimientos.remove(row);
            actualizarTabla();
            JOptionPane.showMessageDialog(this, "Movimiento eliminado");
        }
    }
    private void consultarMovimiento() {
        int row = movimientosTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un movimiento");
            return;
        }
        MovimientoData m = movimientos.get(row);
        String info = String.format("ID: %d\nTipo: %s\nDescripción: %s\nMonto: %.2f\nCategoría: %s\nCódigo: %s",
                m.getId(), m.getTipo(), m.getDescripcion(), m.getMonto(), m.getCategoria(), m.getCodigoUnico());
        JOptionPane.showMessageDialog(this, info, "Información del Movimiento", JOptionPane.INFORMATION_MESSAGE);
    }
    private void ordenarPorMonto() {
        movimientos.sort((a, b) -> Double.compare(b.getMonto(), a.getMonto()));
        actualizarTabla();
        JOptionPane.showMessageDialog(this, "Movimientos ordenados por monto (mayor a menor)");
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new SubMovimientoUI().setVisible(true);
        });
    }
}

