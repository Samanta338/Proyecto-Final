package ec.edu.uce.GuiFrame;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.text.ParseException;
import java.util.*;
import javax.swing.border.TitledBorder;
import javax.swing.border.EmptyBorder;
public class SubPresupuestoUI extends JFrame {
        // Color Palette
        private static final Color SOFT_GREEN = new Color(162, 194, 152);     // Verde suave principal
        private static final Color SAGE_GREEN = new Color(134, 167, 123);     // Verde salvia para botones
        private static final Color MINT_CREAM = new Color(247, 250, 245);     // Crema menta para fondo
        private static final Color DARK_GREEN = new Color(85, 107, 47);       // Verde oscuro para hover
        private static final Color LIGHT_GREEN = new Color(198, 219, 191);    // Verde claro para header
        private static final Color FOREST_GREEN = new Color(46, 84, 48);      // Verde bosque para texto
        private static final Color BLACK = new Color(0, 0, 0);

        private Usuario usuario; // The authenticated user with their budgets
        private JTable budgetTable;
        private DefaultTableModel tableModel;
        private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        // --- Mock Classes for demonstration purposes ---
        // You should replace these with your actual classes.
        public static class Presupuesto {
            private double montoPresupuesto;
            private Date fecha;

            public Presupuesto(double montoPresupuesto, Date fecha) {
                this.montoPresupuesto = montoPresupuesto;
                this.fecha = fecha;
            }

            public double getMontoPresupuesto() { return montoPresupuesto; }
            public void setMontoPresupuesto(double montoPresupuesto) { this.montoPresupuesto = montoPresupuesto; }
            public Date getFecha() { return fecha; }
            public void setFecha(Date fecha) { this.fecha = fecha; }
        }

        public static class Usuario {
            private List<Presupuesto> presupuestos;
            private String nombre; // Added for display/context

            public Usuario(String nombre) {
                this.nombre = nombre;
                this.presupuestos = new ArrayList<>();
                // Add some dummy budgets for testing
                try {
                    presupuestos.add(new Presupuesto(1500.00, new SimpleDateFormat("dd/MM/yyyy").parse("01/07/2025")));
                    presupuestos.add(new Presupuesto(2000.50, new SimpleDateFormat("dd/MM/yyyy").parse("15/06/2025")));
                    presupuestos.add(new Presupuesto(1200.00, new SimpleDateFormat("dd/MM/yyyy").parse("20/07/2025")));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

            public String getNombre() { return nombre; }
            public List<Presupuesto> getPresupuestos() { return presupuestos; }

            public void agregarPresupuesto(double monto, Date fecha) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
                if (monto <= 0) {
                    throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El monto del presupuesto debe ser positivo.");
                }
                if (fecha == null) {
                    throw new ExcepcionMifo.MovimientoInvalidoExcepcion("La fecha del presupuesto no puede ser nula.");
                }
                presupuestos.add(new Presupuesto(monto, fecha));
            }

            public void eliminarPresupuesto(int index) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
                if (index < 0 || index >= presupuestos.size()) {
                    throw new ExcepcionMifo.MovimientoInvalidoExcepcion("Índice de presupuesto inválido.");
                }
                presupuestos.remove(index);
            }
        }

        public static class ExcepcionMifo extends Exception {
            public ExcepcionMifo(String message) { super(message); }
            public static class MovimientoInvalidoExcepcion extends ExcepcionMifo {
                public MovimientoInvalidoExcepcion(String message) { super(message); }
            }
        }

        public static class ComprobacionMenu {
            // Mock methods - replace with your actual validation logic
            public static double validarMonto(String input) {
                try {
                    double monto = Double.parseDouble(input);
                    return monto > 0 ? monto : 0;
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
            public static double validarMonto(java.util.Scanner scanner) { // Overload for Scanner
                try {
                    String input = scanner.nextLine();
                    double monto = Double.parseDouble(input);
                    return monto > 0 ? monto : 0;
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
            public static Date validarFecha(String fechaStr) {
                try {
                    return new SimpleDateFormat("dd/MM/yyyy").parse(fechaStr);
                } catch (ParseException e) {
                    return null;
                }
            }
        }
        // --- End of Mock Classes ---

        public SubMenuGestionarPresupuestoUI(Usuario usuario) {
            this.usuario = usuario;
            setTitle("MIFO - Gestionar Presupuesto");
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setMinimumSize(new Dimension(800, 600));
            setSize(1000, 700);
            setLocationRelativeTo(null); // Center the window

            initializeComponents();
            updateTable(); // Load initial data
        }

        private void initializeComponents() {
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBackground(MINT_CREAM);
            mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

            // Header Panel
            JPanel headerPanel = new JPanel();
            headerPanel.setBackground(LIGHT_GREEN);
            headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
            JLabel mainTitle = new JLabel("GESTIÓN DE PRESUPUESTO", SwingConstants.CENTER);
            mainTitle.setFont(new Font("Arial", Font.BOLD, 28));
            mainTitle.setForeground(FOREST_GREEN);
            headerPanel.add(mainTitle);

            // Table Panel
            String[] columnNames = {"No.", "Monto ($)", "Fecha"};
            tableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Table cells are not directly editable
                }
            };

            budgetTable = new JTable(tableModel);
            configureTable();

            JPanel tableDisplayPanel = new JPanel(new BorderLayout());
            tableDisplayPanel.setBackground(MINT_CREAM);
            TitledBorder titledBorder = BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(SOFT_GREEN, 2),
                    "Detalle de Presupuestos",
                    TitledBorder.CENTER, TitledBorder.TOP,
                    new Font("Arial", Font.BOLD, 16), FOREST_GREEN);
            tableDisplayPanel.setBorder(titledBorder);

            JScrollPane scrollPane = new JScrollPane(budgetTable);
            scrollPane.setBorder(BorderFactory.createLineBorder(SOFT_GREEN, 1));
            tableDisplayPanel.add(scrollPane, BorderLayout.CENTER);

            // Buttons Panel
            JPanel buttonPanel = createButtonPanel();

            mainPanel.add(headerPanel, BorderLayout.NORTH);
            mainPanel.add(tableDisplayPanel, BorderLayout.CENTER);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);

            setContentPane(mainPanel);
        }

        private void configureTable() {
            budgetTable.setFont(new Font("Arial", Font.PLAIN, 14));
            budgetTable.setRowHeight(30);
            budgetTable.setSelectionBackground(LIGHT_GREEN);
            budgetTable.setSelectionForeground(FOREST_GREEN);
            budgetTable.setGridColor(SOFT_GREEN);

            budgetTable.getTableHeader().setBackground(SAGE_GREEN);
            budgetTable.getTableHeader().setForeground(BLACK);
            budgetTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
            budgetTable.getTableHeader().setPreferredSize(new Dimension(0, 40));

            // Column Widths
            budgetTable.getColumnModel().getColumn(0).setPreferredWidth(50); // No.
            budgetTable.getColumnModel().getColumn(1).setPreferredWidth(150); // Monto
            budgetTable.getColumnModel().getColumn(2).setPreferredWidth(150); // Fecha

            // Center align "No." column
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(JLabel.CENTER);
            budgetTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

            // Right align "Monto" column
            DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
            rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
            budgetTable.getColumnModel().getColumn(1).setCellRenderer(rightRenderer);
        }

        private JPanel createButtonPanel() {
            JPanel containerPanel = new JPanel(new BorderLayout());
            containerPanel.setBackground(MINT_CREAM);
            containerPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 30, 40));

            JPanel buttonPanel = new JPanel(new GridBagLayout());
            buttonPanel.setBackground(MINT_CREAM);

            String[] buttonTexts = {
                    "Ingresar Presupuesto",
                    "Editar Presupuesto",
                    "Eliminar Presupuesto",
                    "Consultar Presupuesto",
                    "Volver al Menú Principal", // Closes this UI
                    "Salir del Programa" // Exits application
            };
            JButton[] buttons = new JButton[buttonTexts.length];

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(10, 15, 10, 15);
            gbc.weightx = 1.0;

            for (int i = 0; i < buttonTexts.length; i++) {
                buttons[i] = createStyledButton(buttonTexts[i]);
                gbc.gridx = i % 3; // 3 buttons per row
                gbc.gridy = i / 3;
                buttonPanel.add(buttons[i], gbc);
            }

            // Action Listeners
            buttons[0].addActionListener(e -> showIngresarPresupuestoDialog());
            buttons[1].addActionListener(e -> showEditarPresupuestoDialog());
            buttons[2].addActionListener(e -> showEliminarPresupuestoDialog());
            buttons[3].addActionListener(e -> updateTableAndShowSummary()); // Just refresh and show summary in dialog/console
            buttons[4].addActionListener(e -> this.dispose()); // Close this JFrame
            buttons[5].addActionListener(e -> showExitConfirmation());

            containerPanel.add(buttonPanel, BorderLayout.CENTER);
            return containerPanel;
        }

        private JButton createStyledButton(String text) {
            JButton button = new JButton(text);
            button.setFocusPainted(false);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBackground(SAGE_GREEN);
            button.setForeground(BLACK);
            button.setPreferredSize(new Dimension(220, 60)); // Slightly wider buttons
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(SOFT_GREEN, 2),
                    BorderFactory.createEmptyBorder(15, 20, 15, 20)));

            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setBackground(DARK_GREEN);
                    button.setForeground(Color.WHITE);
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    button.setBackground(SAGE_GREEN);
                    button.setForeground(BLACK);
                }
            });

            return button;
        }

        // --- Core Budget Management Functions (adapted for UI) ---

        private void showIngresarPresupuestoDialog() {
            JTextField montoField = new JTextField(10);
            JTextField fechaField = new JTextField(dateFormat.format(new Date()), 10); // Default to current date

            JPanel panel = new JPanel(new GridLayout(0, 1));
            panel.add(new JLabel("Monto del Presupuesto ($):"));
            panel.add(montoField);
            panel.add(new JLabel("Fecha (dd/MM/yyyy):"));
            panel.add(fechaField);

            int result = JOptionPane.showConfirmDialog(this, panel,
                    "Ingresar Nuevo Presupuesto", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                String montoStr = montoField.getText().trim();
                String fechaStr = fechaField.getText().trim();

                double monto = ComprobacionMenu.validarMonto(montoStr);
                Date fecha = ComprobacionMenu.validarFecha(fechaStr);

                if (monto <= 0) {
                    JOptionPane.showMessageDialog(this, "Monto inválido. Por favor, ingrese un número positivo.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (fecha == null) {
                    JOptionPane.showMessageDialog(this, "Fecha inválida. Use el formato dd/MM/yyyy.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    usuario.agregarPresupuesto(monto, fecha);
                    updateTable();
                    JOptionPane.showMessageDialog(this, "Presupuesto guardado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                    JOptionPane.showMessageDialog(this, "Hubo un error al ingresar el presupuesto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        private void showEditarPresupuestoDialog() {
            List<Presupuesto> presupuestos = usuario.getPresupuestos();
            if (presupuestos.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay presupuestos guardados para editar.", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            // Get selected row index
            int selectedRow = budgetTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione un presupuesto de la tabla para editar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Presupuesto presupuestoToEdit = presupuestos.get(selectedRow);

            JTextField montoField = new JTextField(String.valueOf(presupuestoToEdit.getMontoPresupuesto()), 10);
            JTextField fechaField = new JTextField(dateFormat.format(presupuestoToEdit.getFecha()), 10);

            JPanel panel = new JPanel(new GridLayout(0, 1));
            panel.add(new JLabel("Nuevo Monto ($):"));
            panel.add(montoField);
            panel.add(new JLabel("Nueva Fecha (dd/MM/yyyy):"));
            panel.add(fechaField);

            int result = JOptionPane.showConfirmDialog(this, panel,
                    "Editar Presupuesto", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                String montoStr = montoField.getText().trim();
                String fechaStr = fechaField.getText().trim();

                double nuevoMonto = ComprobacionMenu.validarMonto(montoStr);
                Date nuevaFecha = ComprobacionMenu.validarFecha(fechaStr);

                if (nuevoMonto <= 0) {
                    JOptionPane.showMessageDialog(this, "Monto inválido. Por favor, ingrese un número positivo.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (nuevaFecha == null) {
                    JOptionPane.showMessageDialog(this, "Fecha inválida. Use el formato dd/MM/yyyy.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                presupuestoToEdit.setMontoPresupuesto(nuevoMonto);
                presupuestoToEdit.setFecha(nuevaFecha);
                updateTable();
                JOptionPane.showMessageDialog(this, "Presupuesto editado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        private void showEliminarPresupuestoDialog() {
            List<Presupuesto> presupuestos = usuario.getPresupuestos();
            if (presupuestos.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay presupuestos guardados para eliminar.", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            int selectedRow = budgetTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione un presupuesto de la tabla para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Presupuesto presupuestoToDelete = presupuestos.get(selectedRow);

            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro que desea eliminar el presupuesto del " + dateFormat.format(presupuestoToDelete.getFecha()) + " con monto $" + String.format("%,.2f", presupuestoToDelete.getMontoPresupuesto()) + "?",
                    "Confirmar Eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    usuario.eliminarPresupuesto(selectedRow);
                    updateTable();
                    JOptionPane.showMessageDialog(this, "Presupuesto eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                    JOptionPane.showMessageDialog(this, "Error al eliminar presupuesto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        private void updateTableAndShowSummary() {
            updateTable(); // Ensure the table is up-to-date
            List<Presupuesto> presupuestos = usuario.getPresupuestos();

            if (presupuestos.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay presupuestos registrados.\n¡Crea tu primer presupuesto para comenzar a gestionar tus finanzas!", "Información de Presupuesto", JOptionPane.INFORMATION_MESSAGE);
            } else {
                double montoTotal = presupuestos.stream()
                        .mapToDouble(Presupuesto::getMontoPresupuesto)
                        .sum();
                String summary = String.format(
                        "Total de presupuestos: %d\nMonto total acumulado: $%,.2f",
                        presupuestos.size(), montoTotal
                );
                JOptionPane.showMessageDialog(this, summary, "Resumen de Presupuesto", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        private void showExitConfirmation() {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro que desea salir del programa?",
                    "Cerrar Programa", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this,
                        "<html><div style='text-align: center;'>" +
                                "<h2>Cerrando el sistema</h2>" +
                                "<p>¡Gracias por haber confiado en MIFO!</p>" +
                                "<p>Esperamos que nuestra plataforma te haya sido de gran<br> ayuda en tus finanzas.</p>" +
                                "<p><b>¡Hasta la próxima!</b></p>" +
                                "</div></html>",
                        "Adiós", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        }

        private void updateTable() {
            tableModel.setRowCount(0); // Clear existing rows
            List<Presupuesto> presupuestos = usuario.getPresupuestos();
            if (presupuestos != null) {
                for (int i = 0; i < presupuestos.size(); i++) {
                    Presupuesto p = presupuestos.get(i);
                    tableModel.addRow(new Object[]{
                            i + 1, // "No." column for display
                            String.format("%,.2f", p.getMontoPresupuesto()), // Format currency
                            dateFormat.format(p.getFecha())
                    });
                }
            }
        }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            // Simular un usuario para testing
            Usuario testUser = new Usuario("TestUser");
            // ¡Aquí está el cambio! Usa el nombre correcto de la clase
            new SubPresupuestoUI(testUser).setVisible(true);
        });
    }
}