package ec.edu.uce.GuiFrame;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;
import java.util.List;
public class SubEducacionUI extends JFrame  {
    private static final Color SOFT_GREEN = new Color(162, 194, 152);
    private static final Color SAGE_GREEN = new Color(134, 167, 123);
    private static final Color MINT_CREAM = new Color(247, 250, 245);
    private static final Color DARK_GREEN = new Color(85, 107, 47);
    private static final Color LIGHT_GREEN = new Color(198, 219, 191);
    private static final Color FOREST_GREEN = new Color(46, 84, 48);
    private static final Color BLACK = new Color(0, 0, 0);

    private JTable cursosTable;
    private DefaultTableModel tableModel;
    private List<CursoData> cursos;

    private static class CursoData {
        private int id;
        private String titulo, descripcion, nivel, modalidad, categoria;
        private int duracion;

        public CursoData(int id, String titulo, String descripcion, int duracion,
                         String nivel, String modalidad, String categoria) {
            this.id = id; this.titulo = titulo; this.descripcion = descripcion;
            this.duracion = duracion; this.nivel = nivel; this.modalidad = modalidad;
            this.categoria = categoria;
        }

        // Getters
        public int getId() { return id; }
        public String getTitulo() { return titulo; }
        public String getDescripcion() { return descripcion; }
        public int getDuracion() { return duracion; }
        public String getNivel() { return nivel; }
        public String getModalidad() { return modalidad; }
        public String getCategoria() { return categoria; }

        // Setters
        public void setTitulo(String titulo) { this.titulo = titulo; }
        public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
        public void setDuracion(int duracion) { this.duracion = duracion; }
        public void setNivel(String nivel) { this.nivel = nivel; }
        public void setModalidad(String modalidad) { this.modalidad = modalidad; }
        public void setCategoria(String categoria) { this.categoria = categoria; }
    }

    public SubEducacionUI() {
        setTitle("MIFO - Gestionar Educación Financiera");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 700));
        setSize(1200, 800);
        setLocationRelativeTo(null);

        initializeTestData();
        initializeComponents();
    }

    private void initializeTestData() {
        cursos = new ArrayList<>();
        cursos.add(new CursoData(1, "Finanzas Personales", "Aprende a manejar tu dinero", 4, "BASICO", "Virtual", "Finanzas"));
        cursos.add(new CursoData(2, "Inversiones Avanzadas", "Estrategias de inversión", 8, "AVANZADO", "Presencial", "Inversiones"));
        cursos.add(new CursoData(3, "Presupuesto Familiar", "Planificación financiera del hogar", 6, "INTERMEDIO", "Híbrido", "Presupuesto"));
        cursos.add(new CursoData(4, "Criptomonedas Básico", "Introducción al mundo crypto", 3, "BASICO", "Virtual", "Inversiones"));
        cursos.add(new CursoData(5, "Emprendimiento", "Finanzas para emprendedores", 10, "INTERMEDIO", "Presencial", "Negocios"));
    }

    private void initializeComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_CREAM);
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(LIGHT_GREEN);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        JLabel mainTitle = new JLabel("GESTIÓN DE EDUCACIÓN FINANCIERA", SwingConstants.CENTER);
        mainTitle.setFont(new Font("Arial", Font.BOLD, 28));
        mainTitle.setForeground(FOREST_GREEN);
        headerPanel.add(mainTitle);
        // Table
        String[] columnNames = {"ID", "Título", "Descripción", "Duración", "Nivel", "Modalidad", "Categoría"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        cursosTable = new JTable(tableModel);
        configureTable();

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(MINT_CREAM);
        TitledBorder titledBorder = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 2),
                "Lista de Cursos de Educación Financiera",
                TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 16), FOREST_GREEN);
        tablePanel.setBorder(titledBorder);

        JScrollPane scrollPane = new JScrollPane(cursosTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(SOFT_GREEN, 1));
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = createButtonPanel();

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tablePanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
        updateTable();
    }

    private void configureTable() {
        cursosTable.setFont(new Font("Arial", Font.PLAIN, 13));
        cursosTable.setRowHeight(35);
        cursosTable.setSelectionBackground(LIGHT_GREEN);
        cursosTable.setSelectionForeground(FOREST_GREEN);
        cursosTable.setGridColor(SOFT_GREEN);

        cursosTable.getTableHeader().setBackground(SAGE_GREEN);
        cursosTable.getTableHeader().setForeground(BLACK);
        cursosTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        cursosTable.getTableHeader().setPreferredSize(new Dimension(0, 40));

        int[] columnWidths = {50, 200, 250, 80, 100, 100, 120};
        for (int i = 0; i < columnWidths.length; i++) {
            cursosTable.getColumnModel().getColumn(i).setPreferredWidth(columnWidths[i]);
        }

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        cursosTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        cursosTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        cursosTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
    }

    private JPanel createButtonPanel() {
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.setBackground(MINT_CREAM);
        containerPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 30, 40));

        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBackground(MINT_CREAM);

        String[] buttonTexts = {"Crear Curso", "Editar Curso", "Eliminar Curso", "Consultar Curso", "Ordenar", "Volver"};
        JButton[] buttons = new JButton[buttonTexts.length];

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 15, 10, 15);
        gbc.weightx = 1.0;

        for (int i = 0; i < buttonTexts.length; i++) {
            buttons[i] = createStyledButton(buttonTexts[i]);
            if (i < 4) {
                gbc.gridx = i;
                gbc.gridy = 0;
            } else {
                gbc.gridx = i - 3;
                gbc.gridy = 1;
            }
            buttonPanel.add(buttons[i], gbc);
        }

        // Event listeners
        buttons[0].addActionListener(e -> showCreateDialog());
        buttons[1].addActionListener(e -> showEditDialog());
        buttons[2].addActionListener(e -> deleteCourse());
        buttons[3].addActionListener(e -> showCourseInfo());
        buttons[4].addActionListener(e -> showSortDialog());
        buttons[5].addActionListener(e -> this.dispose());

        containerPanel.add(buttonPanel, BorderLayout.CENTER);
        return containerPanel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(SAGE_GREEN);
        button.setForeground(Color.BLACK);
        button.setPreferredSize(new Dimension(200, 60));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 2),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(DARK_GREEN);
                button.setForeground(Color.WHITE);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(SAGE_GREEN);
                button.setForeground(BLACK);
            }
        });

        return button;
    }

    private void showCreateDialog() {
        JDialog dialog = createFormDialog("Crear Nuevo Curso", null);
        dialog.setVisible(true);
    }

    private void showEditDialog() {
        int selectedRow = cursosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un curso para editar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JDialog dialog = createFormDialog("Editar Curso", cursos.get(selectedRow));
        dialog.setVisible(true);
    }

    private JDialog createFormDialog(String title, CursoData curso) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_CREAM);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        // Form fields
        JTextField tituloField = new JTextField(20);
        JTextArea descripcionArea = new JTextArea(3, 20);
        JSpinner duracionSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 52, 1));
        JComboBox<String> nivelCombo = new JComboBox<>(new String[]{"BASICO", "INTERMEDIO", "AVANZADO"});
        JTextField modalidadField = new JTextField(20);
        JTextField categoriaField = new JTextField(20);

        if (curso != null) {
            tituloField.setText(curso.getTitulo());
            descripcionArea.setText(curso.getDescripcion());
            duracionSpinner.setValue(curso.getDuracion());
            nivelCombo.setSelectedItem(curso.getNivel());
            modalidadField.setText(curso.getModalidad());
            categoriaField.setText(curso.getCategoria());
        }

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(MINT_CREAM);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        addFormField(formPanel, gbc, 0, "Título:", tituloField);
        addFormField(formPanel, gbc, 1, "Descripción:", new JScrollPane(descripcionArea));
        addFormField(formPanel, gbc, 2, "Duración:", duracionSpinner);
        addFormField(formPanel, gbc, 3, "Nivel:", nivelCombo);
        addFormField(formPanel, gbc, 4, "Modalidad:", modalidadField);
        addFormField(formPanel, gbc, 5, "Categoría:", categoriaField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(MINT_CREAM);

        JButton saveBtn = new JButton(curso == null ? "Crear" : "Guardar");
        JButton cancelBtn = new JButton("Cancelar");

        saveBtn.addActionListener(e -> {
            if (validateForm(tituloField, descripcionArea, modalidadField, categoriaField, curso)) {
                if (curso == null) {
                    int newId = cursos.stream().mapToInt(CursoData::getId).max().orElse(0) + 1;
                    cursos.add(new CursoData(newId, tituloField.getText().trim(),
                            descripcionArea.getText().trim(), (Integer) duracionSpinner.getValue(),
                            (String) nivelCombo.getSelectedItem(), modalidadField.getText().trim(),
                            categoriaField.getText().trim()));
                } else {
                    curso.setTitulo(tituloField.getText().trim());
                    curso.setDescripcion(descripcionArea.getText().trim());
                    curso.setDuracion((Integer) duracionSpinner.getValue());
                    curso.setNivel((String) nivelCombo.getSelectedItem());
                    curso.setModalidad(modalidadField.getText().trim());
                    curso.setCategoria(categoriaField.getText().trim());
                }
                updateTable();
                JOptionPane.showMessageDialog(dialog, "Operación exitosa!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        dialog.add(mainPanel);

        return dialog;
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, int row, String labelText, JComponent component) {
        gbc.gridx = 0; gbc.gridy = row; gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel(labelText), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(component, gbc);
    }

    private boolean validateForm(JTextField titulo, JTextArea descripcion, JTextField modalidad, JTextField categoria, CursoData currentCurso) {
        String tituloText = titulo.getText().trim();
        if (tituloText.length() < 3 || tituloText.length() > 50) {
            JOptionPane.showMessageDialog(this, "El título debe tener entre 3 y 50 caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        boolean exists = cursos.stream().anyMatch(curso ->
                (currentCurso == null || curso.getId() != currentCurso.getId()) &&
                        curso.getTitulo().equalsIgnoreCase(tituloText));

        if (exists) {
            JOptionPane.showMessageDialog(this, "Ya existe un curso con ese título.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    private void deleteCourse() {
        int selectedRow = cursosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un curso para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        CursoData curso = cursos.get(selectedRow);
        int option = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el curso '" + curso.getTitulo() + "'?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (option == JOptionPane.YES_OPTION) {
            cursos.remove(selectedRow);
            updateTable();
            JOptionPane.showMessageDialog(this, "Curso eliminado.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void showCourseInfo() {
        int selectedRow = cursosTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un curso.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        CursoData curso = cursos.get(selectedRow);
        String info = String.format(
                "ID: %d\nTítulo: %s\nDescripción: %s\nDuración: %d semanas\nNivel: %s\nModalidad: %s\nCategoría: %s",
                curso.getId(), curso.getTitulo(), curso.getDescripcion(), curso.getDuracion(),
                curso.getNivel(), curso.getModalidad(), curso.getCategoria()
        );

        JOptionPane.showMessageDialog(this, info, "Información del Curso", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showSortDialog() {
        String[] options = {"Duración (Asc)", "Duración (Desc)", "Nivel", "Título (A-Z)", "Título (Z-A)"};
        String selection = (String) JOptionPane.showInputDialog(this, "Ordenar por:", "Ordenamiento",
                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (selection != null) {
            switch (selection) {
                case "Duración (Asc)": cursos.sort(Comparator.comparingInt(CursoData::getDuracion)); break;
                case "Duración (Desc)": cursos.sort(Comparator.comparingInt(CursoData::getDuracion).reversed()); break;
                case "Nivel":
                    cursos.sort((c1, c2) -> {
                        String[] orden = {"BASICO", "INTERMEDIO", "AVANZADO"};
                        return Integer.compare(Arrays.asList(orden).indexOf(c1.getNivel()),
                                Arrays.asList(orden).indexOf(c2.getNivel()));
                    }); break;
                case "Título (A-Z)": cursos.sort(Comparator.comparing(CursoData::getTitulo)); break;
                case "Título (Z-A)": cursos.sort(Comparator.comparing(CursoData::getTitulo).reversed()); break;
            }
            updateTable();
        }
    }

    private void updateTable() {
        tableModel.setRowCount(0);
        for (CursoData curso : cursos) {
            tableModel.addRow(new Object[]{
                    curso.getId(), curso.getTitulo(), curso.getDescripcion(),
                    curso.getDuracion() + " sem", curso.getNivel(), curso.getModalidad(), curso.getCategoria()
            });
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new SubEducacionUI().setVisible(true);
        });
    }
}
