/**
 * Clase que representa el submenú para gestionar categorías en el sistema MIFO.
 * Permite crear, editar, eliminar y consultar categorías dentro de la aplicación.
 */
package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.*;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import java.util.*;
public class SubMenuGestionarCategoria {
    private Scanner entrada = new Scanner(System.in);
    private List<Categoria> categorias = new ArrayList<>();
    /**
     * Instancia de la empresa que administra las categorías.
     */
    private Empresa empresa = Empresa.getInstance();

    /**
     * Contador de categorías almacenadas en el sistema.
     */
    private static int numCategorias = 0;

    /**
     * Muestra el menú de gestión de categorías y procesa la opción elegida por el usuario.
     */
    public void menuGestionarCategoria() {
        int seleccion;
        do {
            mostrarMenuGestionarCategorias();
            seleccion = ComprobacionMenu.validarOpcionMenu(entrada, 7);
            try {
                procesarOpcionGestionarCategorias(seleccion);
            } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (seleccion != 5 && seleccion != 6);
    }

    /**
     * Muestra las opciones disponibles en el submenú de gestión de categorías.
     */
    private void mostrarMenuGestionarCategorias() {
        System.out.println();
        System.out.println("╔═══════════════════════════════════════════════╗");
        System.out.println("║           Gestionar Categoría                 ║");
        System.out.println("╠═══════════════════════════════════════════════╣");
        System.out.println("║                                               ║");
        System.out.println("║   1. Crear Categoría                          ║");
        System.out.println("║   2. Editar Categoría                         ║");
        System.out.println("║   3. Eliminar Categoría                       ║");
        System.out.println("║   4. Consultar Categoría                      ║");
        System.out.println("║   5. Ordenar Categorías por nombre            ║");
        System.out.println("║   6. Volver al menú principal                 ║");
        System.out.println("║   7. Salir del programa                       ║");
        System.out.println("║                                               ║");
        System.out.println("╚═══════════════════════════════════════════════╝");
        System.out.println();
        System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
    }

    /**
     * Procesa la opción elegida en el menú e invoca la funcionalidad correspondiente.
     *
     * @param seleccion Opción elegida por el usuario.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion Si se produce un error en la gestión de movimientos de categoría.
     */
    private void procesarOpcionGestionarCategorias(int seleccion) throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        switch (seleccion) {
            case 1:
                crearCategoria();
                break;
            case 2:
                editarCategoria();
                break;
            case 3:
                eliminarCategoria();
                break;
            case 4:
                consultarCategorias();
                break;
            case 5:
                ordenarCategorias(new OrdenarCategoriaPorNombre());
                break;
            case 6:
                System.out.println();
                System.out.println("Volviendo al menú principal...");
                return;

            case 7:
                System.out.println();
                System.out.println("╔══════════════════════════════════════════════════════════════╗");
                System.out.println("║                     Cerrando el sistema                      ║");
                System.out.println("╠══════════════════════════════════════════════════════════════╣");
                System.out.println("║                                                              ║");
                System.out.println("║     ¡Gracias por haber confiado en MIFO!                     ║");
                System.out.println("║                                                              ║");
                System.out.println("║   Esperamos que nuestra plataforma te haya sido de gran      ║");
                System.out.println("║                     ayuda en tus finanzas.                   ║");
                System.out.println("║                                                              ║");
                System.out.println("║              ¡Hasta la próxima!                              ║");
                System.out.println("║                                                              ║");
                System.out.println("╚══════════════════════════════════════════════════════════════╝");
                System.exit(0);
                break;
            default:
                System.out.println("Opción no válida, por favor intente de nuevo.");
        }
    }

    /**
     * CRUD: Crear categoría
     * Crea una nueva categoría verificando la validez de los datos ingresados.
     */
    private void crearCategoria() {
        System.out.println(" --------------------------------------------------------");
        String nombreCategoria;
        TipoMovimiento tipoMovimiento;

        while (true) {
            System.out.print(" | Ingrese el nombre de la categoría: ");
            nombreCategoria = entrada.nextLine().trim();
            if (nombreCategoria == null || nombreCategoria.isEmpty()) {
                System.out.println("Error: El nombre no puede estar vacío.");
                continue;
            }
            if (empresa.validarDuplicado(new Categoria(nombreCategoria))) {
                System.out.println("Error: La categoría ya existe. Intente con otro nombre.");
                continue;
            }
            break;
        }
        // Selección del tipo de movimiento
        while (true) {
            System.out.println(" | Seleccione el tipo de movimiento:");
            TipoMovimiento[] movimientos = TipoMovimiento.values();
            for (int i = 0; i < movimientos.length; i++) {
                System.out.println("   " + (i + 1) + ". " + movimientos[i]);
            }
            System.out.print("Ingrese la opción: ");
            if (entrada.hasNextInt()) {
                int opcionMovimiento = entrada.nextInt();
                entrada.nextLine(); // Limpiar buffer
                if (opcionMovimiento >= 1 && opcionMovimiento <= movimientos.length) {
                    tipoMovimiento = movimientos[opcionMovimiento - 1];
                    break;
                } else {
                    System.out.println("Opción no válida, intente nuevamente.");
                }
            } else {
                System.out.println("Debe ingresar un número válido.");
                entrada.nextLine();
            }
        }

        // Agregar categoría usando el método dedicado
        agregarCategoria(nombreCategoria, tipoMovimiento);
    }

    /**
     * Agrega una categoría al sistema con redimensionamiento dinámico del arreglo.
     *
     * @param nombreCategoria Nombre de la categoría
     * @param tipoMovimiento Tipo de movimiento de la categoría
     */
    public void agregarCategoria(String nombreCategoria, TipoMovimiento tipoMovimiento) {
        if (nombreCategoria == null || nombreCategoria.trim().isEmpty()) {
            System.out.println("Error: El nombre de la categoría no puede estar vacío.");
            return;
        }
        if (tipoMovimiento == null) {
            System.out.println("Error: El tipo de movimiento no puede ser nulo.");
            return;
        }
        Categoria categoria = new Categoria(nombreCategoria, tipoMovimiento);

        if (verificarCategoria(categoria)) {
            System.out.println("Error: Categoría ya existe.");
            return;
        }
        categorias.add(categoria);
        try {
            empresa.agregarCategoria(categoria);
            System.out.println("-> Categoría creada exitosamente.");
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println("Error al agregar la categoría: " + e.getMessage());
        }
    }
    /**
     * Agrega una categoría existente al sistema.
     *
     * @param categoria Categoría a agregar
     */
    public void agregarCategoria(Categoria categoria) {
        if (categoria == null) {
            System.out.println("No se puede agregar una categoría nula.");
            return;
        }
        categorias.add(categoria);
        System.out.println("Categoría agregada exitosamente.");
    }

    /**
     * CRUD: Editar categoría
     * Edita una categoría existente verificando su validez y permitiendo cambios en su nombre y tipo de movimiento.
     */
    private void editarCategoria() {
        // Verifica si hay categorías registradas antes de proceder.
        if (numCategorias == 0) {
            System.out.println("No hay categorías registradas.");
            return;
        }

        System.out.print(" | Ingrese el nombre de la categoría que desea editar: ");
        String nombreCategoriaAntiguo = entrada.nextLine().trim();

        // Busca el índice de la categoría por su nombre.
        int indiceCategoria = buscarIndicePorNombre(nombreCategoriaAntiguo);
        if (indiceCategoria == -1) {
            System.out.println("No se encontró ninguna categoría con el nombre especificado.");
            return;
        }

        String nuevoNombreCategoria;
        TipoMovimiento nuevoTipoMovimiento;

        // Validación del nuevo nombre de la categoría
        while (true) {
            System.out.print(" | Ingrese el nuevo nombre de la categoría: ");
            nuevoNombreCategoria = entrada.nextLine().trim();
            if (ComprobacionMenu.validarDescripcion(nuevoNombreCategoria)) {
                if (buscarCategoriaPorNombreCategoria(nuevoNombreCategoria) == null || nuevoNombreCategoria.equalsIgnoreCase(nombreCategoriaAntiguo)) {
                    break;
                } else {
                    System.out.println("Ya existe otra categoría con ese nombre.");
                }
            } else {
                System.out.println("El nombre no puede estar vacío.");
            }
        }

        // Selección del nuevo tipo de movimiento
        while (true) {
            System.out.println(" | Seleccione el nuevo tipo de movimiento:");
            TipoMovimiento[] movimientos = TipoMovimiento.values();
            for (int i = 0; i < movimientos.length; i++) {
                System.out.println("   " + (i + 1) + ". " + movimientos[i]);
            }
            System.out.print("Ingrese la opción: ");
            if (entrada.hasNextInt()) {
                int opcionMovimiento = entrada.nextInt();
                entrada.nextLine(); // Limpia el buffer
                if (opcionMovimiento >= 1 && opcionMovimiento <= movimientos.length) {
                    nuevoTipoMovimiento = movimientos[opcionMovimiento - 1];
                    break;
                } else {
                    System.out.println("Opción no válida.");
                }
            } else {
                System.out.println("Debe ingresar un número.");
                entrada.nextLine(); // Limpia el buffer
            }
        }
        // Crear nueva categoría y editarla
        Categoria nuevaCategoria = new Categoria(nuevoNombreCategoria, nuevoTipoMovimiento);
        editarCategoria(indiceCategoria, nuevaCategoria);
    }

    /**
     * Edita los datos de una categoría existente.
     *
     * @param indice Índice de la categoría a editar
     * @param categoria Nueva categoría con los datos actualizados
     */
    public void editarCategoria(int indice, Categoria categoria) {
        if (indice >= 0 && indice < categorias.size()) {
            categorias.set(indice, categoria);
            System.out.println(" -> Categoría editada exitosamente.");
        } else {
            System.out.println("Índice inválido para editar categoría.");
        }
    }
    /**
     * CRUD: Eliminar categoría
     * Elimina una categoría existente del sistema.
     */
    private void eliminarCategoria() {
        // Verifica si hay categorías registradas antes de proceder.
        if (numCategorias == 0) {
            System.out.println("No hay categorías registradas.");
            return;
        }

        System.out.print(" | Ingrese el nombre de la categoría que desea eliminar: ");
        String nombreCategoriaEliminar = entrada.nextLine().trim();
        // Busca el índice de la categoría por su nombre.
        int indiceEliminar = buscarIndicePorNombre(nombreCategoriaEliminar);
        if (indiceEliminar == -1) {
            System.out.println("No se encontró ninguna categoría con ese nombre.");
            return;
        }

        eliminarCategoria(indiceEliminar);
    }

    /**
     * Elimina una categoría por índice.
     *
     * @param indice Índice de la categoría a eliminar
     */
    public void eliminarCategoria(int indice) {
        if (indice >= 0 && indice < categorias.size()) {
            categorias.remove(indice);
            System.out.println(" -> Categoría eliminada exitosamente.");
        } else {
            System.out.println("Índice inválido para eliminar categoría.");
        }
    }
    /**
     * CRUD: Consultar categoría
     * Consulta y muestra en pantalla la información de una categoría existente.
     */
    private void consultarCategoria(String nombreCategoriaConsulta ) {
        if (numCategorias == 0) {
            System.out.println("No hay categorías registradas.");
            return;
        }
        System.out.print(" | Ingrese el nombre de la categoría que desea consultar: ");
        Categoria categoriaConsulta = buscarCategoriaPorNombreCategoria(nombreCategoriaConsulta);
        if (categoriaConsulta == null) {
            System.out.println("No se encontró ninguna categoría con ese nombre.");
            return;
        }
        System.out.println("Información de la categoría:");
        System.out.println("Nombre: " + categoriaConsulta.getNombreCategoria());
        System.out.println("Tipo Movimiento: " + categoriaConsulta.getTipoMovimiento());
    }
    /**
     * Consulta todas las categorías del sistema.
     *
     * @return Cadena con información de las categorías
     */
    public void consultarCategorias() {
        List<Categoria> listaCategorias = empresa.getCategorias();
        if (listaCategorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
            return;
        }
        listaCategorias.sort(Comparator.comparingInt(Categoria::getId));

        System.out.println("══════════════════════════════════════════════════════");
        System.out.println("                LISTA DE CATEGORÍAS");
        System.out.println("══════════════════════════════════════════════════════");

        for (int i = 0; i < listaCategorias.size(); i++) {
            Categoria c = listaCategorias.get(i);
            System.out.printf("║  %-7d │ %-18s │ %-14s ║%n",
                    i + 1,
                    c.getNombreCategoria(),
                    c.getTipoMovimiento());
        }
    }

    /**
     * Busca una categoría por nombre dentro del arreglo de categorías.
     *
     * @param nombreCategoria Nombre de la categoría a buscar.
     * @return La categoría encontrada o null si no existe.
     */
     public Categoria buscarCategoriaPorNombreCategoria(String nombreCategoria) {
        if (nombreCategoria == null) {
            return null;
        }
        List<Categoria> listaEmpresa = empresa.getCategorias();
        if (listaEmpresa == null || listaEmpresa.isEmpty()) {
            return null;
        }
        for (Categoria categoria : listaEmpresa) {
            if (categoria.getNombreCategoria().equalsIgnoreCase(nombreCategoria)) {
                return categoria;
            }
        }
        return null;
    }
    /**
     * Busca el índice de una categoría por su nombre.
     *
     * @param nombreCategoria Nombre de la categoría a buscar
     * @return Índice de la categoría o -1 si no se encuentra
     */
    private int buscarIndicePorNombre(String nombreCategoria) {
        if (nombreCategoria == null) {
            return -1;
        }
        List<Categoria> listaCategorias = empresa.getCategorias();
        for (int i = 0; i < listaCategorias.size(); i++) {
            if (listaCategorias.get(i).getNombreCategoria().equalsIgnoreCase(nombreCategoria)) {
                return i;
            }
        }
        return -1;
    }
    /**
     * Busca y retorna una categoría por índice.
     *
     * @param indice Índice de la categoría
     * @return Categoría encontrada o null si el índice no es válido
     */
    public Categoria buscarCategoria(int indice) {
        if (indice >= 0 && indice < categorias.size()) {
            return categorias.get(indice);
        }
        System.out.println("Error: Índice de categoría no válido.");
        return null;
    }
    /**
     * Verifica si una categoría ya existe en el sistema.
     *
     * @param categoria Categoría a verificar
     * @return true si ya existe, false si no
     */
    public boolean verificarCategoria(Categoria categoria) {
        if (categoria == null || categoria.getNombreCategoria() == null) {
            return false;
        }
        for (Categoria c : empresa.getCategorias()) {
            if (c.equals(categoria)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Muestra todas las categorías actualmente registradas en el sistema.
     */
    public void mostrarCategoriasDisponibles() {
        List<Categoria> listaCategorias = empresa.getCategorias();
        if (listaCategorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
            return;
        }
        System.out.println("Categorías disponibles:");
        for (Categoria c : listaCategorias) {
            System.out.println(" - " + c.getNombreCategoria() + " (" + c.getTipoMovimiento() + ")");
        }
    }
    /**
     * Método que pide al usuario ingresar datos para crear una nueva categoría y la devuelve.
     * @return La nueva categoría creada con los datos ingresados por el usuario.
     */
    public Categoria pedirOCrearCategoria() {
        String nombreCategoria;
        TipoMovimiento tipoMovimiento;

        while (true) {
            System.out.print("Ingrese el nombre de la categoría: ");
            nombreCategoria = entrada.nextLine().trim();
            if (ComprobacionMenu.validarDescripcion(nombreCategoria)) {
                if (buscarCategoriaPorNombreCategoria(nombreCategoria) == null) {
                    break;
                } else {
                    System.out.println("La categoría ya existe. Intente con otro nombre.");
                }
            } else {
                System.out.println("El nombre no puede estar vacío.");
            }
        }

        while (true) {
            System.out.println("Seleccione el tipo de movimiento:");
            TipoMovimiento[] movimientos = TipoMovimiento.values();
            for (int i = 0; i < movimientos.length; i++) {
                System.out.println((i + 1) + ". " + movimientos[i]);
            }
            System.out.print("Ingrese la opción: ");
            if (entrada.hasNextInt()) {
                int opcionMovimiento = entrada.nextInt();
                entrada.nextLine();
                if (opcionMovimiento >= 1 && opcionMovimiento <= movimientos.length) {
                    tipoMovimiento = movimientos[opcionMovimiento - 1];
                    break;
                } else {
                    System.out.println("Opción no válida, intente nuevamente.");
                }
            } else {
                System.out.println("Debe ingresar un número válido.");
                entrada.nextLine();
            }
        }

        return new Categoria(nombreCategoria, tipoMovimiento);
    }
    public void ordenarCategorias(Comparator<Categoria> comparador) {
        List<Categoria> listaCategorias = empresa.getCategorias();
        if (listaCategorias.isEmpty()) {
            System.out.println("No hay categorías para ordenar.");
            return;
        }
        listaCategorias.sort(comparador);

        System.out.println("Categorías ordenadas:");
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println("                LISTA DE CATEGORÍAS");
        System.out.println("══════════════════════════════════════════════════════");

        for (int i = 0; i < listaCategorias.size(); i++) {
            Categoria c = listaCategorias.get(i);
            String icono = c.getTipoMovimiento().toString().equals("INGRESO") ? "↗" : "↙";
            System.out.printf("║  %-7d │ %-19s │ %-15s ║\n",
                    i + 1,
                    c.getNombreCategoria().length() > 19 ? c.getNombreCategoria().substring(0, 19) : c.getNombreCategoria(),
                    c.getTipoMovimiento().toString());
        }
    }

}