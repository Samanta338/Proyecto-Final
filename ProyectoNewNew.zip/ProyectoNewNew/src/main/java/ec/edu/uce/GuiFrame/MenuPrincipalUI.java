package ec.edu.uce.GuiFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;
import ec.edu.uce.Dominio.Usuario;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import ec.edu.uce.Dominio.Empresa;
import ec.edu.uce.GuiFrame.MenuMifoUI;
public class MenuPrincipalUI extends JFrame {
    // Paleta de colores - SOLO verdes cálidos y suaves + negro
    private static final Color SOFT_GREEN = new Color(162, 194, 152);     // Verde suave principal
    private static final Color SAGE_GREEN = new Color(134, 167, 123);     // Verde salvia para botones
    private static final Color MINT_CREAM = new Color(247, 250, 245);     // Crema menta para fondo
    private static final Color DARK_GREEN = new Color(85, 107, 47);       // Verde oscuro para hover
    private static final Color LIGHT_GREEN = new Color(198, 219, 191);    // Verde claro para header
    private static final Color FOREST_GREEN = new Color(46, 84, 48);      // Verde bosque para texto
    private static final Color BLACK = new Color(0, 0, 0);               // Negro

    private JPanel mainPanel;
    private JButton crearCuentaButton;
    private JButton ingresarSistemaButton;
    private JButton salirButton;
    private Empresa empresa = Empresa.getInstance();

    public MenuPrincipalUI() {
        setTitle("MIFO - Mis Finanzas Foráneas");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Configuración responsive - TAMAÑO AJUSTADO
        setMinimumSize(new Dimension(700, 400));      // Tamaño mínimo más ancho y menos alto
        setSize(900, 600);                           // Tamaño inicial más ancho y menos alto
        setLocationRelativeTo(null);
        setResizable(true);

        // Panel principal con fondo simple
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_CREAM);

        // Crear componentes
        JPanel headerPanel = createHeaderPanel();
        JPanel buttonPanel = createButtonPanel();

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        setContentPane(mainPanel);

        // Configurar eventos de los botones
        configurarEventos();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(LIGHT_GREEN);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30)); // Reducido padding vertical

        // Título principal - TAMAÑO AJUSTADO
        JLabel mainTitle = new JLabel("BIENVENIDOS A MIFO", SwingConstants.CENTER);
        mainTitle.setFont(new Font("Arial", Font.BOLD, 32)); // Aumentado para ventana más ancha
        mainTitle.setForeground(FOREST_GREEN);
        mainTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Subtítulo - TAMAÑO AJUSTADO
        JLabel subtitle = new JLabel("Mis Finanzas Foráneas", SwingConstants.CENTER);
        subtitle.setFont(new Font("Arial", Font.PLAIN, 16)); // Aumentado
        subtitle.setForeground(DARK_GREEN);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(mainTitle);
        headerPanel.add(Box.createVerticalStrut(10));
        headerPanel.add(subtitle);

        return headerPanel;
    }

    private JPanel createButtonPanel() {
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.setBackground(MINT_CREAM);
        containerPanel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80)); // Más padding horizontal

        // Panel con GridBagLayout para mejor control responsive
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBackground(MINT_CREAM);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(15, 20, 15, 20); // Más espaciado
        gbc.weightx = 1.0;

        // URLs de iconos profesionales
        String[] iconUrls = {
                "https://cdn-icons-png.flaticon.com/512/1077/1077114.png",    // User add
                "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",    // Login
                "https://cdn-icons-png.flaticon.com/512/1828/1828490.png"     // Exit
        };

        String[] buttonTexts = {
                "1. Crear Cuenta",
                "2. Ingresar al Sistema",
                "3. Salir"
        };

        // Crear botones con iconos
        crearCuentaButton = createStyledButton(buttonTexts[0], iconUrls[0]);
        ingresarSistemaButton = createStyledButton(buttonTexts[1], iconUrls[1]);
        salirButton = createStyledButton(buttonTexts[2], iconUrls[2]);

        // Agregar botones
        JButton[] buttons = {crearCuentaButton, ingresarSistemaButton, salirButton};

        for (int i = 0; i < buttons.length; i++) {
            gbc.gridy = i;
            buttonPanel.add(buttons[i], gbc);
        }

        containerPanel.add(buttonPanel, BorderLayout.CENTER);
        return containerPanel;
    }

    private JButton createStyledButton(String text, String iconUrl) {
        JButton button = new JButton(text);

        // Cargar icono desde internet - TAMAÑO AJUSTADO
        ImageIcon icon = loadIconFromURL(iconUrl, 28); // Iconos más grandes
        if (icon != null) {
            button.setIcon(icon);
        }

        // Configuración del botón RESPONSIVE - TAMAÑOS AJUSTADOS
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 18)); // Fuente más grande
        button.setBackground(SAGE_GREEN);
        button.setForeground(BLACK);
        button.setMinimumSize(new Dimension(450, 70));    // Más ancho y alto
        button.setPreferredSize(new Dimension(600, 80));  // Más ancho y alto
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 2),
                BorderFactory.createEmptyBorder(20, 30, 20, 30) // Más padding
        ));
        button.setIconTextGap(25); // Más espacio entre icono y texto
        button.setOpaque(true);

        // Efectos hover
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(DARK_GREEN);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(SAGE_GREEN);
            }
        });

        return button;
    }

    private void configurarEventos() {
        crearCuentaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDialogoCrearCuenta();
            }
        });

        ingresarSistemaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDialogoLogin();
            }
        });

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDialogoSalida();
            }
        });
    }

    private void mostrarDialogoCrearCuenta() {
        JDialog dialog = new JDialog(this, "Crear Cuenta", true);
        dialog.setSize(500, 450); // Ligeramente más grande
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);
        dialog.setLayout(new BorderLayout());

        // Panel principal con padding
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_CREAM);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        // Panel del título
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(LIGHT_GREEN);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        JLabel titulo = new JLabel("Crear Nueva Cuenta", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 22)); // Fuente más grande
        titulo.setForeground(FOREST_GREEN);
        titlePanel.add(titulo);

        // Panel de campos con mejor spacing
        JPanel fieldsPanel = new JPanel(new GridBagLayout());
        fieldsPanel.setBackground(MINT_CREAM);
        fieldsPanel.setBorder(BorderFactory.createEmptyBorder(25, 0, 25, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 15, 12, 15); // Más espacio

        // Crear campos con mejor estilo
        JTextField nombreField = createStyledTextField();
        JPasswordField contrasenaField = createStyledPasswordField();
        JTextField correoField = createStyledTextField();

        // Crear labels con mejor estilo
        JLabel[] labels = {
                createStyledLabel("Nombre de usuario:"),
                createStyledLabel("Contraseña:"),
                createStyledLabel("Correo electrónico:")
        };

        JComponent[] fields = {nombreField, contrasenaField, correoField};

        // Agregar campos
        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.anchor = GridBagConstraints.WEST;
            fieldsPanel.add(labels[i], gbc);
            gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(fields[i], gbc);
            gbc.weightx = 0.0; gbc.fill = GridBagConstraints.NONE;
        }

        // Panel de botones mejorado
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 25));
        buttonPanel.setBackground(MINT_CREAM);

        JButton crearBtn = createDialogButton("Crear Cuenta", SAGE_GREEN, BLACK);
        JButton cancelarBtn = createDialogButton("Cancelar", DARK_GREEN, Color.BLACK);
        crearBtn.addActionListener(e -> {
            String nombre = nombreField.getText().trim();
            String contrasena = new String(contrasenaField.getPassword()).trim();
            String correo = correoField.getText().trim();

            if (procesarCreacionCuenta(nombre, contrasena, correo)) {
                JOptionPane.showMessageDialog(dialog,
                        "¡Cuenta creada exitosamente!\nYa puede ingresar al sistema.",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            }
        });

        cancelarBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(crearBtn);
        buttonPanel.add(cancelarBtn);

        // Ensamblar el diálogo
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(fieldsPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    private void mostrarDialogoLogin() {
        JDialog dialog = new JDialog(this, "Ingresar al Sistema", true);
        dialog.setSize(500, 400); // Tamaño ajustado
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);
        dialog.setLayout(new BorderLayout());

        // Panel principal con padding
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_CREAM);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // Panel del título con mejor separación
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(LIGHT_GREEN);
        titlePanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 1),
                BorderFactory.createEmptyBorder(25, 25, 25, 25)
        ));
        JLabel titulo = new JLabel("Iniciar Sesión", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24)); // Fuente más grande
        titulo.setForeground(FOREST_GREEN);
        titlePanel.add(titulo, BorderLayout.CENTER);

        // Panel de campos
        JPanel fieldsPanel = new JPanel(new GridBagLayout());
        fieldsPanel.setBackground(MINT_CREAM);
        fieldsPanel.setBorder(BorderFactory.createEmptyBorder(25, 0, 25, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15); // Más espacio

        // Crear campos
        JTextField usuarioField = createStyledTextField();
        JPasswordField passField = createStyledPasswordField();

        JLabel usuarioLabel = createStyledLabel("Nombre de usuario:");
        JLabel passLabel = createStyledLabel("Contraseña:");

        // Agregar campos
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        fieldsPanel.add(usuarioLabel, gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        fieldsPanel.add(usuarioField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0.0;
        fieldsPanel.add(passLabel, gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        fieldsPanel.add(passField, gbc);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(MINT_CREAM);

        JButton loginBtn = createDialogButton("Ingresar", SAGE_GREEN, BLACK);
        JButton cancelarBtn = createDialogButton("Cancelar", DARK_GREEN, Color.BLACK);
        loginBtn.addActionListener(e -> {
            String usuario = usuarioField.getText().trim();
            String contrasena = new String(passField.getPassword()).trim();
            if (procesarLogin(usuario, contrasena)) {
                JOptionPane.showMessageDialog(dialog,
                        "Ingreso exitoso. ¡Bienvenido, " + usuario + "!",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
                this.dispose();
                new MenuMifoUI().setVisible(true);
            }
        });

        cancelarBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(loginBtn);
        buttonPanel.add(cancelarBtn);

        // Ensamblar el diálogo
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(fieldsPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    // Métodos auxiliares para crear componentes estilizados
    private JTextField createStyledTextField() {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Arial", Font.PLAIN, 15)); // Fuente ligeramente más grande
        field.setBackground(Color.WHITE);
        field.setForeground(BLACK);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12) // Más padding
        ));
        field.setPreferredSize(new Dimension(280, 38)); // Más grande
        return field;
    }

    private JPasswordField createStyledPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setFont(new Font("Arial", Font.PLAIN, 15)); // Fuente ligeramente más grande
        field.setBackground(Color.WHITE);
        field.setForeground(BLACK);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12) // Más padding
        ));
        field.setPreferredSize(new Dimension(280, 38)); // Más grande
        return field;
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 15)); // Fuente más grande
        label.setForeground(FOREST_GREEN);
        return label;
    }

    private JButton createDialogButton(String text, Color bgColor, Color fgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 15)); // Fuente más grande
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SOFT_GREEN, 1),
                BorderFactory.createEmptyBorder(12, 25, 12, 25) // Más padding
        ));
        button.setPreferredSize(new Dimension(180, 50)); // Más grande

        // Efecto hover
        button.addMouseListener(new MouseAdapter() {
            Color originalBg = button.getBackground();

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(originalBg.darker());
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(originalBg);
            }
        });

        return button;
    }

    private void mostrarDialogoSalida() {
        int opcion = JOptionPane.showOptionDialog(this,
                "¡Gracias por haber confiado en MIFO!\n\n" +
                        "Esperamos que nuestra plataforma te haya sido de gran\n" +
                        "ayuda en tus finanzas.\n\n" +
                        "¡Hasta la próxima!",
                "Cerrando el sistema",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"Salir", "Cancelar"},
                "Salir");

        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private boolean procesarCreacionCuenta(String nombre, String contrasena, String correo) {
        StringBuilder errores = new StringBuilder();
        boolean hayErrores = false;

        // Validaciones del nombre
        if (nombre == null || nombre.trim().isEmpty()) {
            errores.append("• El nombre no puede estar vacío.\n");
            hayErrores = true;
        } else {
            // Eliminar espacios en blanco al inicio y final
            nombre = nombre.trim();

            // Verificar longitud mínima
            if (nombre.length() < 3) {
                errores.append("• El nombre debe tener al menos 3 caracteres.\n");
                hayErrores = true;
            }

            // Verificar que no contenga solo números
            if (nombre.matches("\\d+")) {
                errores.append("• El nombre no puede contener solo números.\n");
                hayErrores = true;
            }

            // Verificar que no contenga espacios en blanco
            if (nombre.contains(" ")) {
                errores.append("• El nombre no puede contener espacios en blanco.\n");
                hayErrores = true;
            }

            if (!ComprobacionMenu.validarNombreUsuario(nombre)) {
                errores.append("• Nombre de usuario inválido.\n");
                hayErrores = true;
            }
        }

        // Validaciones de contraseña
        if (!ComprobacionMenu.validarContrasena(contrasena)) {
            errores.append("• La contraseña no es válida. Debe contener al menos una letra, un dígito y tener mínimo 8 caracteres.\n");
            hayErrores = true;
        }

        // Validaciones de correo
        if (!ComprobacionMenu.validarCorreo(correo)) {
            errores.append("• Correo electrónico inválido.\n");
            hayErrores = true;
        }

        // Si hay errores, mostrarlos todos juntos
        if (hayErrores) {
            JOptionPane.showMessageDialog(this,
                    "Se encontraron los siguientes errores:\n\n" + errores.toString(),
                    "Errores de Validación",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Verificar si el usuario ya existe
        for (Usuario u : empresa.getUsuarios()) {
            if (u != null && u.getNombre().equals(nombre)) {
                JOptionPane.showMessageDialog(this, "Nombre en uso. Intente con uno diferente.", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        // Crear usuario
        try {
            String resultado = empresa.agregarUsuarioConCodigo(nombre, contrasena, correo);
            return true;
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            JOptionPane.showMessageDialog(this, "Error al crear usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    private boolean procesarLogin(String nombre, String contrasena) {
        try {
            Usuario usuarioEncontrado = buscarUsuario(nombre, contrasena);
            if (usuarioEncontrado != null) {
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Usuario encontrado, pero contraseña incorrecta.", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (ExcepcionMifo.UsuarioNoEncontradoExcepcion e) {
            JOptionPane.showMessageDialog(this, "Usuario incorrecto o no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private Usuario buscarUsuario(String nombre, String contrasena) throws ExcepcionMifo.UsuarioNoEncontradoExcepcion {
        for (Usuario u : empresa.getUsuarios()) {
            if (u != null && u.getNombre().equals(nombre)) {
                if (u.getContrasena().equals(contrasena)) {
                    return u;
                } else {
                    return null;
                }
            }
        }
        throw new ExcepcionMifo.UsuarioNoEncontradoExcepcion("Usuario '" + nombre + "' no encontrado.");
    }

    // Método para cargar iconos desde URL
    private ImageIcon loadIconFromURL(String iconUrl, int size) {
        try {
            URL url = new URL(iconUrl);
            BufferedImage img = ImageIO.read(url);

            if (img != null) {
                Image scaledImg = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
                return new ImageIcon(scaledImg);
            }
        } catch (Exception e) {
            // Crear icono simple como fallback
            BufferedImage fallbackImg = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = fallbackImg.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(FOREST_GREEN);
            g2d.fillOval(2, 2, size-4, size-4);
            g2d.dispose();
            return new ImageIcon(fallbackImg);
        }
        return null;
    }

    public static void main(String[] args) {
        // Configurar look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            MenuPrincipalUI menu = new MenuPrincipalUI();
            menu.setVisible(true);
        });
    }
}