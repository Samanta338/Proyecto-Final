package ec.edu.uce.GuiFrame;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class SubCategoriaUI extends JFrame {
        private static final Color SOFT_GREEN = new Color(162, 194, 152);
        private static final Color SAGE_GREEN = new Color(134, 167, 123);
        private static final Color MINT_CREAM = new Color(247, 250, 245);
        private static final Color DARK_GREEN = new Color(85, 107, 47);
        private static final Color LIGHT_GREEN = new Color(198, 219, 191);
        private static final Color FOREST_GREEN = new Color(46, 84, 48);
        private static final Color BLACK = new Color(0, 0, 0);

        // Componentes principales
        private JPanel mainPanel;
        private JTable categoriasTable;
        private DefaultTableModel tableModel;
        private JButton crearButton, editarButton, eliminarButton, consultarButton, ordenarButton, volverButton;

        // Datos simulados - en tu aplicación real usarías SubMenuGestionarCategoria
        private List<CategoriaData> categorias;

        // Clase interna para representar una categoría
        private static class CategoriaData {
            private int id;
            private String nombre;
            private String tipoMovimiento;

            public CategoriaData(int id, String nombre, String tipoMovimiento) {
                this.id = id;
                this.nombre = nombre;
                this.tipoMovimiento = tipoMovimiento;
            }

            // Getters
            public int getId() { return id; }
            public String getNombre() { return nombre; }
            public String getTipoMovimiento() { return tipoMovimiento; }

            // Setters
            public void setNombre(String nombre) { this.nombre = nombre; }
            public void setTipoMovimiento(String tipoMovimiento) { this.tipoMovimiento = tipoMovimiento; }
        }

        public SubCategoriaUI () {
            setTitle("MIFO - Gestionar Categorías");
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Configuración responsive
            setMinimumSize(new Dimension(900, 600));
            setSize(1200, 800);
            setLocationRelativeTo(null);
            setResizable(true);

            // Inicializar datos de prueba
            initializeTestData();

            // Crear panel principal
            mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBackground(MINT_CREAM);

            // Crear componentes
            JPanel headerPanel = createHeaderPanel();
            JPanel contentPanel = createContentPanel();
            JPanel buttonPanel = createButtonPanel();

            mainPanel.add(headerPanel, BorderLayout.NORTH);
            mainPanel.add(contentPanel, BorderLayout.CENTER);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);

            setContentPane(mainPanel);

            // Configurar eventos
            configurarEventos();
        }

        private void initializeTestData() {
            categorias = new ArrayList<>();
            categorias.add(new CategoriaData(1, "Comida", "GASTO"));
            categorias.add(new CategoriaData(2, "Transporte", "GASTO"));
            categorias.add(new CategoriaData(3, "Salario", "INGRESO"));
            categorias.add(new CategoriaData(4, "Entretenimiento", "GASTO"));
            categorias.add(new CategoriaData(5, "Inversiones", "INGRESO"));
        }

        private JPanel createHeaderPanel() {
            JPanel headerPanel = new JPanel();
            headerPanel.setBackground(LIGHT_GREEN);
            headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
            headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

            // Título principal
            JLabel mainTitle = new JLabel("GESTIÓN DE CATEGORÍAS", SwingConstants.CENTER);
            mainTitle.setFont(new Font("Arial", Font.BOLD, 28));
            mainTitle.setForeground(FOREST_GREEN);
            mainTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Subtítulo
            JLabel subtitle = new JLabel("Administra las categorías de tus movimientos financieros", SwingConstants.CENTER);
            subtitle.setFont(new Font("Arial", Font.PLAIN, 14));
            subtitle.setForeground(DARK_GREEN);
            subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

            headerPanel.add(mainTitle);
            headerPanel.add(Box.createVerticalStrut(8));
            headerPanel.add(subtitle);

            return headerPanel;
        }

        private JPanel createContentPanel() {
            JPanel contentPanel = new JPanel(new BorderLayout());
            contentPanel.setBackground(MINT_CREAM);
            contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            // Crear tabla
            String[] columnNames = {"ID", "Nombre de Categoría", "Tipo de Movimiento"};
            tableModel = new DefaultTableModel(columnNames, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Hacer tabla no editable directamente
                }
            };

            categoriasTable = new JTable(tableModel);
            configurarTabla();

            // Panel de la tabla con título
            JPanel tablePanel = new JPanel(new BorderLayout());
            tablePanel.setBackground(MINT_CREAM);

            // Título de la tabla
            TitledBorder titledBorder = BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(SOFT_GREEN, 2),
                    "Lista de Categorías",
                    TitledBorder.CENTER,
                    TitledBorder.TOP,
                    new Font("Arial", Font.BOLD, 16),
                    FOREST_GREEN
            );
            tablePanel.setBorder(titledBorder);

            JScrollPane scrollPane = new JScrollPane(categoriasTable);
            scrollPane.setBackground(Color.WHITE);
            scrollPane.getViewport().setBackground(Color.WHITE);
            scrollPane.setBorder(BorderFactory.createLineBorder(SOFT_GREEN, 1));

            tablePanel.add(scrollPane, BorderLayout.CENTER);

            // Actualizar tabla con datos iniciales
            actualizarTabla();

            contentPanel.add(tablePanel, BorderLayout.CENTER);
            return contentPanel;
        }

        private void configurarTabla() {
            // Configuración visual de la tabla
            categoriasTable.setFont(new Font("Arial", Font.PLAIN, 14));
            categoriasTable.setRowHeight(35);
            categoriasTable.setSelectionBackground(LIGHT_GREEN);
            categoriasTable.setSelectionForeground(FOREST_GREEN);
            categoriasTable.setGridColor(SOFT_GREEN);

            // Configurar header
            JTableHeader header = categoriasTable.getTableHeader();
            header.setBackground(SAGE_GREEN);
            header.setForeground(BLACK);
            header.setFont(new Font("Arial", Font.BOLD, 14));
            header.setPreferredSize(new Dimension(header.getPreferredSize().width, 40));

            // Configurar ancho de columnas
            categoriasTable.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID
            categoriasTable.getColumnModel().getColumn(1).setPreferredWidth(300); // Nombre
            categoriasTable.getColumnModel().getColumn(2).setPreferredWidth(200); // Tipo

            // Centrar contenido de las celdas
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(JLabel.CENTER);
            categoriasTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
            categoriasTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        }

        private JPanel createButtonPanel() {
            JPanel containerPanel = new JPanel(new BorderLayout());
            containerPanel.setBackground(MINT_CREAM);
            containerPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 30, 40));

            // Panel principal de botones
            JPanel buttonPanel = new JPanel(new GridBagLayout());
            buttonPanel.setBackground(MINT_CREAM);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(10, 15, 10, 15);
            gbc.weightx = 1.0;

            // URLs de iconos
            String[] iconUrls = {
                    "https://cdn-icons-png.flaticon.com/512/1828/1828817.png", // Crear
                    "https://cdn-icons-png.flaticon.com/512/1159/1159633.png", // Editar
                    "https://cdn-icons-png.flaticon.com/512/3096/3096673.png", // Eliminar
                    "https://cdn-icons-png.flaticon.com/512/709/709612.png",   // Consultar
                    "https://cdn-icons-png.flaticon.com/512/2037/2037338.png", // Ordenar
                    "https://cdn-icons-png.flaticon.com/512/2223/2223615.png"  // Volver
            };

            String[] buttonTexts = {
                    "Crear Categoría",
                    "Editar Categoría",
                    "Eliminar Categoría",
                    "Consultar Categoría",
                    "Ordenar Categorías",
                    "Volver al Menú"
            };

            // Crear botones
            crearButton = createStyledButton(buttonTexts[0], iconUrls[0]);
            editarButton = createStyledButton(buttonTexts[1], iconUrls[1]);
            eliminarButton = createStyledButton(buttonTexts[2], iconUrls[2]);
            consultarButton = createStyledButton(buttonTexts[3], iconUrls[3]);
            ordenarButton = createStyledButton(buttonTexts[4], iconUrls[4]);
            volverButton = createStyledButton(buttonTexts[5], iconUrls[5]);

            JButton[] buttons = {crearButton, editarButton, eliminarButton, consultarButton, ordenarButton, volverButton};

            // Primera fila de botones (CRUD)
            for (int i = 0; i < 4; i++) {
                gbc.gridx = i;
                gbc.gridy = 0;
                buttonPanel.add(buttons[i], gbc);
            }

            // Segunda fila de botones (Acciones adicionales)
            gbc.gridx = 1;
            gbc.gridy = 1;
            buttonPanel.add(ordenarButton, gbc);

            gbc.gridx = 2;
            gbc.gridy = 1;
            buttonPanel.add(volverButton, gbc);

            containerPanel.add(buttonPanel, BorderLayout.CENTER);
            return containerPanel;
        }

        private JButton createStyledButton(String text, String iconUrl) {
            JButton button = new JButton(text);

            // Cargar icono
            ImageIcon icon = loadIconFromURL(iconUrl, 24);
            if (icon != null) {
                button.setIcon(icon);
            }

            // Configuración del botón
            button.setFocusPainted(false);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBackground(SAGE_GREEN);
            button.setForeground(Color.BLACK);
            button.setMinimumSize(new Dimension(200, 60));
            button.setPreferredSize(new Dimension(250, 65));
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(SOFT_GREEN, 2),
                    BorderFactory.createEmptyBorder(15, 20, 15, 20)
            ));
            button.setIconTextGap(10);
            button.setOpaque(true);

            // Efectos hover
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setBackground(DARK_GREEN);
                    button.setForeground(Color.WHITE);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    button.setBackground(SAGE_GREEN);
                    button.setForeground(BLACK);
                }
            });

            return button;
        }

        private void configurarEventos() {
            crearButton.addActionListener(e -> mostrarDialogoCrearCategoria());
            editarButton.addActionListener(e -> mostrarDialogoEditarCategoria());
            eliminarButton.addActionListener(e -> eliminarCategoriaSeleccionada());
            consultarButton.addActionListener(e -> consultarCategoriaSeleccionada());
            ordenarButton.addActionListener(e -> mostrarDialogoOrdenar());
            volverButton.addActionListener(e -> {
                this.dispose();
                new MenuMifoUI().setVisible(true);
            });
        }

        private void mostrarDialogoCrearCategoria() {
            JDialog dialog = new JDialog(this, "Crear Nueva Categoría", true);
            dialog.setSize(500, 350);
            dialog.setLocationRelativeTo(this);
            dialog.setResizable(false);

            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBackground(MINT_CREAM);
            mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

            // Título
            JPanel titlePanel = new JPanel();
            titlePanel.setBackground(LIGHT_GREEN);
            titlePanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
            JLabel titulo = new JLabel("Crear Nueva Categoría", SwingConstants.CENTER);
            titulo.setFont(new Font("Arial", Font.BOLD, 20));
            titulo.setForeground(FOREST_GREEN);
            titlePanel.add(titulo);

            // Campos
            JPanel fieldsPanel = new JPanel(new GridBagLayout());
            fieldsPanel.setBackground(MINT_CREAM);
            fieldsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            JTextField nombreField = createStyledTextField();
            JComboBox<String> tipoCombo = new JComboBox<>(new String[]{"GASTO", "INGRESO"});
            tipoCombo.setFont(new Font("Arial", Font.PLAIN, 14));
            tipoCombo.setPreferredSize(new Dimension(280, 35));

            JLabel nombreLabel = createStyledLabel("Nombre de la categoría:");
            JLabel tipoLabel = createStyledLabel("Tipo de movimiento:");

            gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
            fieldsPanel.add(nombreLabel, gbc);
            gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(nombreField, gbc);

            gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0.0;
            fieldsPanel.add(tipoLabel, gbc);
            gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(tipoCombo, gbc);

            // Botones
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
            buttonPanel.setBackground(MINT_CREAM);

            JButton crearBtn = createDialogButton("Crear", SAGE_GREEN);
            JButton cancelarBtn = createDialogButton("Cancelar", DARK_GREEN);

            crearBtn.addActionListener(e -> {
                String nombre = nombreField.getText().trim();
                String tipo = (String) tipoCombo.getSelectedItem();

                if (nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Verificar si ya existe
                boolean existe = categorias.stream().anyMatch(cat -> cat.getNombre().equalsIgnoreCase(nombre));
                if (existe) {
                    JOptionPane.showMessageDialog(dialog, "Ya existe una categoría con ese nombre.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Crear nueva categoría
                int nuevoId = categorias.stream().mapToInt(CategoriaData::getId).max().orElse(0) + 1;
                categorias.add(new CategoriaData(nuevoId, nombre, tipo));
                actualizarTabla();

                JOptionPane.showMessageDialog(dialog, "¡Categoría creada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            });

            cancelarBtn.addActionListener(e -> dialog.dispose());

            buttonPanel.add(crearBtn);
            buttonPanel.add(cancelarBtn);

            mainPanel.add(titlePanel, BorderLayout.NORTH);
            mainPanel.add(fieldsPanel, BorderLayout.CENTER);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);

            dialog.add(mainPanel);
            dialog.setVisible(true);
        }

        private void mostrarDialogoEditarCategoria() {
            int selectedRow = categoriasTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Por favor, seleccione una categoría para editar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            CategoriaData categoria = categorias.get(selectedRow);

            JDialog dialog = new JDialog(this, "Editar Categoría", true);
            dialog.setSize(500, 350);
            dialog.setLocationRelativeTo(this);
            dialog.setResizable(false);

            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBackground(MINT_CREAM);
            mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

            // Título
            JPanel titlePanel = new JPanel();
            titlePanel.setBackground(LIGHT_GREEN);
            titlePanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
            JLabel titulo = new JLabel("Editar Categoría", SwingConstants.CENTER);
            titulo.setFont(new Font("Arial", Font.BOLD, 20));
            titulo.setForeground(FOREST_GREEN);
            titlePanel.add(titulo);

            // Campos
            JPanel fieldsPanel = new JPanel(new GridBagLayout());
            fieldsPanel.setBackground(MINT_CREAM);
            fieldsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            JTextField nombreField = createStyledTextField();
            nombreField.setText(categoria.getNombre());

            JComboBox<String> tipoCombo = new JComboBox<>(new String[]{"GASTO", "INGRESO"});
            tipoCombo.setSelectedItem(categoria.getTipoMovimiento());
            tipoCombo.setFont(new Font("Arial", Font.PLAIN, 14));
            tipoCombo.setPreferredSize(new Dimension(280, 35));

            JLabel nombreLabel = createStyledLabel("Nombre de la categoría:");
            JLabel tipoLabel = createStyledLabel("Tipo de movimiento:");

            gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
            fieldsPanel.add(nombreLabel, gbc);
            gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(nombreField, gbc);

            gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0.0;
            fieldsPanel.add(tipoLabel, gbc);
            gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(tipoCombo, gbc);

            // Botones
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
            buttonPanel.setBackground(MINT_CREAM);

            JButton guardarBtn = createDialogButton("Guardar", SAGE_GREEN);
            JButton cancelarBtn = createDialogButton("Cancelar", DARK_GREEN);

            guardarBtn.addActionListener(e -> {
                String nuevoNombre = nombreField.getText().trim();
                String nuevoTipo = (String) tipoCombo.getSelectedItem();

                if (nuevoNombre.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Verificar si ya existe otro con el mismo nombre
                boolean existe = categorias.stream()
                        .anyMatch(cat -> cat.getId() != categoria.getId() && cat.getNombre().equalsIgnoreCase(nuevoNombre));
                if (existe) {
                    JOptionPane.showMessageDialog(dialog, "Ya existe otra categoría con ese nombre.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Actualizar categoría
                categoria.setNombre(nuevoNombre);
                categoria.setTipoMovimiento(nuevoTipo);
                actualizarTabla();

                JOptionPane.showMessageDialog(dialog, "¡Categoría actualizada exitosamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            });

            cancelarBtn.addActionListener(e -> dialog.dispose());

            buttonPanel.add(guardarBtn);
            buttonPanel.add(cancelarBtn);

            mainPanel.add(titlePanel, BorderLayout.NORTH);
            mainPanel.add(fieldsPanel, BorderLayout.CENTER);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);

            dialog.add(mainPanel);
            dialog.setVisible(true);
        }

        private void eliminarCategoriaSeleccionada() {
            int selectedRow = categoriasTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Por favor, seleccione una categoría para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            CategoriaData categoria = categorias.get(selectedRow);

            int opcion = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro de que desea eliminar la categoría '" + categoria.getNombre() + "'?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);

            if (opcion == JOptionPane.YES_OPTION) {
                categorias.remove(selectedRow);
                actualizarTabla();
                JOptionPane.showMessageDialog(this, "Categoría eliminada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        private void consultarCategoriaSeleccionada() {
            int selectedRow = categoriasTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Por favor, seleccione una categoría para consultar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            CategoriaData categoria = categorias.get(selectedRow);

            JDialog dialog = new JDialog(this, "Información de Categoría", true);
            dialog.setSize(450, 300);
            dialog.setLocationRelativeTo(this);
            dialog.setResizable(false);

            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBackground(MINT_CREAM);
            mainPanel.setBorder(BorderFactory.createEmptyBorder(3, 25, 20, 25));

            // Título
            JPanel titlePanel = new JPanel();
            titlePanel.setBackground(LIGHT_GREEN);
            titlePanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
            JLabel titulo = new JLabel("Información de la Categoría", SwingConstants.CENTER);
            titulo.setFont(new Font("Arial", Font.BOLD, 18));
            titulo.setForeground(FOREST_GREEN);
            titlePanel.add(titulo);

            // Información
            JPanel infoPanel = new JPanel(new GridBagLayout());
            infoPanel.setBackground(MINT_CREAM);
            infoPanel.setBorder(BorderFactory.createEmptyBorder(30, 0, 30, 0));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(15, 15, 15, 15);
            gbc.anchor = GridBagConstraints.WEST;

            JLabel idLabel = createStyledLabel("ID:");
            JLabel idValue = new JLabel(String.valueOf(categoria.getId()));
            idValue.setFont(new Font("Arial", Font.PLAIN, 16));

            JLabel nombreLabel = createStyledLabel("Nombre:");
            JLabel nombreValue = new JLabel(categoria.getNombre());
            nombreValue.setFont(new Font("Arial", Font.PLAIN, 16));

            JLabel tipoLabel = createStyledLabel("Tipo de Movimiento:");
            JLabel tipoValue = new JLabel(categoria.getTipoMovimiento());
            tipoValue.setFont(new Font("Arial", Font.PLAIN, 16));

            gbc.gridx = 0; gbc.gridy = 0;
            infoPanel.add(idLabel, gbc);
            gbc.gridx = 1;
            infoPanel.add(idValue, gbc);

            gbc.gridx = 0; gbc.gridy = 1;
            infoPanel.add(nombreLabel, gbc);
            gbc.gridx = 1;
            infoPanel.add(nombreValue, gbc);

            gbc.gridx = 0; gbc.gridy = 2;
            infoPanel.add(tipoLabel, gbc);
            gbc.gridx = 1;
            infoPanel.add(tipoValue, gbc);

            // Botón
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.setBackground(MINT_CREAM);

            JButton cerrarBtn = createDialogButton("Cerrar", SAGE_GREEN);
            cerrarBtn.addActionListener(e -> dialog.dispose());
            buttonPanel.add(cerrarBtn);

            mainPanel.add(titlePanel, BorderLayout.NORTH);
            mainPanel.add(infoPanel, BorderLayout.CENTER);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);

            dialog.add(mainPanel);
            dialog.setVisible(true);
        }

        private void mostrarDialogoOrdenar() {
            String[] opciones = {"Por ID", "Por Nombre", "Cancelar"};
            int seleccion = JOptionPane.showOptionDialog(this,
                    "¿Cómo desea ordenar las categorías?",
                    "Ordenar Categorías",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]);

            switch (seleccion) {
                case 0: // Por ID
                    Collections.sort(categorias, Comparator.comparing(CategoriaData::getId));
                    actualizarTabla();
                    JOptionPane.showMessageDialog(this, "Categorías ordenadas por ID.", "Información", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 1: // Por Nombre
                    Collections.sort(categorias, Comparator.comparing(CategoriaData::getNombre, String.CASE_INSENSITIVE_ORDER));
                    actualizarTabla();
                    JOptionPane.showMessageDialog(this, "Categorías ordenadas por nombre.", "Información", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 2: // Cancelar
                    break;
            }
        }

        private void actualizarTabla() {
            tableModel.setRowCount(0);
            for (CategoriaData categoria : categorias) {
                tableModel.addRow(new Object[]{
                        categoria.getId(),
                        categoria.getNombre(),
                        categoria.getTipoMovimiento()
                });
            }
        }

        // Métodos auxiliares para crear componentes estilizados
        private JTextField createStyledTextField() {
            JTextField field = new JTextField(20);
            field.setFont(new Font("Arial", Font.PLAIN, 14));
            field.setBackground(Color.WHITE);
            field.setForeground(BLACK);
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(SOFT_GREEN, 1),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)
            ));
            field.setPreferredSize(new Dimension(280, 35));
            return field;
        }

        private JLabel createStyledLabel(String text) {
            JLabel label = new JLabel(text);
            label.setFont(new Font("Arial", Font.BOLD, 14));
            label.setForeground(FOREST_GREEN);
            return label;
        }
        private JButton createDialogButton(String text, Color bgColor) {
            JButton button = new JButton(text);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBackground(bgColor);
            button.setForeground(Color.BLACK);
            button.setPreferredSize(new Dimension(120, 40));
            button.setFocusPainted(false);
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(bgColor.darker(), 1),
                    BorderFactory.createEmptyBorder(8, 15, 8, 15)
            ));

            // Efectos hover
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setBackground(bgColor.darker());
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    button.setBackground(bgColor);
                }
            });

            return button;
        }

        private ImageIcon loadIconFromURL(String urlString, int size) {
            try {
                URL url = new URL(urlString);
                BufferedImage img = ImageIO.read(url);
                Image scaledImg = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
                return new ImageIcon(scaledImg);
            } catch (Exception e) {
                // En caso de error, devolver null (el botón se mostrará sin icono)
                System.err.println("No se pudo cargar el icono desde: " + urlString);
                return null;
            }
        }

        // Método main para probar la interfaz
        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                new SubCategoriaUI ().setVisible(true);
            });
        }
    }

