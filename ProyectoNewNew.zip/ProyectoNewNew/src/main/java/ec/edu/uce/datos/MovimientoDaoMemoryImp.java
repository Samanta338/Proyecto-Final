package ec.edu.uce.datos;
import ec.edu.uce.Dominio.Movimiento;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
public class MovimientoDaoMemoryImp {
    private static List<Movimiento> movimientos = new ArrayList<>();
    public void agregar(Movimiento movimiento) {
        movimientos.add(movimiento);
    }
    public void editar(Movimiento movimiento) {
        for (int i = 0; i < movimientos.size(); i++) {
            if (movimientos.get(i).getCodigoUnico() == movimiento.getCodigoUnico()) {
                movimientos.set(i, movimiento);
                return;
            }
        }
        System.out.println("Movimiento no encontrado para editar.");
    }
    public void eliminar(int codigo) {
        for (int i = 0; i < movimientos.size(); i++) {
            Movimiento m = movimientos.get(i);
            if (m.getCodigoUnico() == codigo) {
                movimientos.remove(i);
                return;
            }
        }
        System.out.println("Movimiento no encontrado para eliminar.");
    }
    public Movimiento buscarPorCodigo(int codigo) {
        for (Movimiento m : movimientos) {
            if (m.getCodigoUnico() == codigo) {
                return m;
            }
        }
        return null;
    }

    public List<Movimiento> consultarMovimientos() {
        return new ArrayList<>(movimientos);
    }
}
