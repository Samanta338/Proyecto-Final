package ec.edu.uce.Dominio;
import ec.edu.uce.Util.ExcepcionMifo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * Clase Gasto que representa un movimiento de tipo gasto.
 * Hereda de la clase Movimiento.
 */
public class Gasto extends Movimiento {
    /**
     * Tipo de movimiento de gasto.
     */
    private static final TipoMovimiento tipoMovimiento = TipoMovimiento.GASTO;

    /**
     * 1 Constructor por defecto.
     */
    public Gasto() {
        super("Sin descripción", 0.0, new Date(), new Categoria("Alimentación"));
    }
    /**
     * 2 Constructor principal.
     */
    public Gasto(String descripcion, double monto, Date fecha, Categoria categoria) {
        super(descripcion, monto, fecha, categoria);
    }
    // 3 Constructor con descripción y monto
    public Gasto(String descripcion, double monto) {
        super(descripcion, monto, new Date(), new Categoria("Alimentación"));
    }

    // 4 Constructor con descripción, monto y fecha
    public Gasto(String descripcion, double monto, Date fecha) {
        super(descripcion, monto, fecha, new Categoria("Alimentación"));
    }
   // 5 Constructor con descripción, categoría
   public Gasto(String descripcion, Categoria categoria) {
       super(descripcion, 0.0, new Date(), categoria);
   }

   // 6 Constructor con solo monto y categoría
   public Gasto(double monto, Categoria categoria) {
       super("Sin descripción", monto, new Date(), categoria);
   }
    /**
     * Devuelve el tipo de movimiento.
     * @return tipo de movimiento.
     */
    public TipoMovimiento getTipoMovimiento() {
        return tipoMovimiento;
    }
    /**
     * Registra el gasto validando que el monto sea válido.
     * @return true si se registra, false en caso contrario.
     */
    @Override
    public boolean registrar() {
        if (this.getMonto() <= 0.0) {
            System.out.println("Error: El monto del gasto debe ser mayor que cero.");
            return false;
        } else {
            System.out.println("Gasto registrado:");
            imprimirDetalles();
            return true;
        }
    }
    /**
     * Realiza el gasto validando el monto.
     * @throws ExcepcionMifo.MovimientoInvalidoExcepcion si el monto es inválido.
     */

    @Override
    public void realizar() throws ExcepcionMifo.MovimientoInvalidoExcepcion, ExcepcionMifo.SaldoInsuficienteExcepcion {
        if (this.getMonto() <= 0.0) {
            throw new ExcepcionMifo.MovimientoInvalidoExcepcion("El monto del gasto debe ser mayor que cero.");
        }

        if (this.getMonto() > tipoMovimiento.getLimiteMensualSugerido()) {
            System.out.println("Advertencia: Este gasto supera el límite mensual sugerido para este tipo.");
        }

        System.out.println("Realizando gasto:");
        imprimirDetalles();
    }
    private void imprimirDetalles() {
        System.out.println("Descripción: " + this.getDescripcion());
        System.out.println("Monto: " + this.getMonto());
        System.out.println("Fecha: " + this.getFecha());
        System.out.println("Categoría: " + this.getCategoria().getNombreCategoria());
        System.out.println("Código único: " + this.getCodigoUnico());
        System.out.println("Tipo de Movimiento: " + tipoMovimiento.getDescripcion());
        System.out.println("Código Movimiento: " + tipoMovimiento.getCodigo());
        System.out.println("Prioridad: " + tipoMovimiento.getPrioridad());
        System.out.println("Límite mensual sugerido: " + tipoMovimiento.getLimiteMensualSugerido());
    }
    @Override
    public boolean validarDuplicado(Movimiento otroMovimiento) {
        if (otroMovimiento instanceof Gasto) {
            return this.equals(otroMovimiento);
        }
        return false;
    }
    /**
     * Representación en texto del gasto.
     * @return información del gasto.
     */
    @Override
    public String toString() {
        return String.format("Gasto:%s\n" +
                        "\tCódigo único:            %s\n" +
                        "\tTipo de Movimiento:      %s\n" +
                        "\tCódigo Movimiento:       %s\n" +
                        "\tPrioridad:               %s\n" +
                        "\tLímite mensual sugerido: %.2f",
                super.toString(),
                this.getCodigoUnico(),
                tipoMovimiento.getDescripcion(),
                tipoMovimiento.getCodigo(),
                tipoMovimiento.getPrioridad(),
                tipoMovimiento.getLimiteMensualSugerido());
    }
}
