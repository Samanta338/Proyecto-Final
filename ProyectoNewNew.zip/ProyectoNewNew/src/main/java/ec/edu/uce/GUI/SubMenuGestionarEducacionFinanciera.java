package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.Categoria;
import ec.edu.uce.Dominio.EducacionFinanciera;
import ec.edu.uce.Dominio.Empresa;
import ec.edu.uce.Dominio.OrdenarEducacionPorDuracion;
import java.util.*;
public class SubMenuGestionarEducacionFinanciera {
    private Empresa empresa = Empresa.getInstance();
    EducacionFinanciera educacionFinanciera = new EducacionFinanciera();
    private Scanner entrada = new Scanner(System.in);
    public void menuGestionarEducacionFinanciera() {
        boolean continuar = true;
        while (continuar) {
            System.out.println();
            System.out.println("╔═══════════════════════════════════════════════╗");
            System.out.println("║        Gestionar Educación Financiera         ║");
            System.out.println("╠═══════════════════════════════════════════════╣");
            System.out.println("║                                               ║");
            System.out.println("║  1. Crear Educación Financiera                ║");
            System.out.println("║  2. Editar Educación Financiera               ║");
            System.out.println("║  3. Eliminar Educación Financiera             ║");
            System.out.println("║  4. Consultar Educación Financiera            ║");
            System.out.println("║  5. Ordenar cursos por duración               ║");
            System.out.println("║  6. Volver al menú principal                  ║");
            System.out.println("║  7. Salir del sistema                         ║");
            System.out.println("║                                               ║");
            System.out.println("╚═══════════════════════════════════════════════╝");
            System.out.println();
            System.out.print("Por favor, selecciona una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                    crearCurso();
                    break;
                case "2":
                    editarCurso();
                    break;
                case "3":
                    eliminarCurso();
                    break;
                case "4":
                    menuConsultaCursos();
                    break;
                case "5":
                    ordenarCursosPorDuracion();
                    break;
                case "6":
                    System.out.println();
                    System.out.println("Volviendo al menú principal...");
                    return;
                case "7":
                    System.out.println();
                    System.out.println("╔══════════════════════════════════════════════════════════════╗");
                    System.out.println("║                     Cerrando el sistema                      ║");
                    System.out.println("╠══════════════════════════════════════════════════════════════╣");
                    System.out.println("║                                                              ║");
                    System.out.println("║     ¡Gracias por haber confiado en MIFO!                     ║");
                    System.out.println("║                                                              ║");
                    System.out.println("║   Esperamos que nuestra plataforma te haya sido de gran      ║");
                    System.out.println("║                     ayuda en tus finanzas.                   ║");
                    System.out.println("║                                                              ║");
                    System.out.println("║              ¡Hasta la próxima!                              ║");
                    System.out.println("║                                                              ║");
                    System.out.println("╚══════════════════════════════════════════════════════════════╝");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
            System.out.println();
        }
    }
    public void crearCurso() {
        System.out.println("\n--- CREAR NUEVO CURSO ---");
        String titulo;
        do {
            System.out.print("Título: ");
            titulo = entrada.nextLine().trim();
            if (titulo.length() < 3 || titulo.length() > 50 || titulo.matches("\\d+")) {
                System.out.println("El título debe tener entre 3 y 50 caracteres y no puede ser solo números.");
            }
        } while (titulo.length() < 3 || titulo.length() > 50 || titulo.matches("\\d+"));

        // Validar descripción
        String descripcion;
        do {
            System.out.print("Descripción: ");
            descripcion = entrada.nextLine().trim();
            if (descripcion.length() < 10 || descripcion.length() > 200 || descripcion.matches("\\d+")) {
                System.out.println("La descripción debe tener entre 10 y 200 caracteres y no puede ser solo números.");
            }
        } while (descripcion.length() < 10 || descripcion.length() > 200 || descripcion.matches("\\d+"));
        // Validar duración usando el método existente
        int duracion = solicitarEnteroPositivo("Duración en semanas: ");

        // Validar nivel (solo BASICO, INTERMEDIO, AVANZADO)
        String nivel;
        while (true) {
            System.out.print("Nivel (BASICO, INTERMEDIO, AVANZADO): ");
            nivel = entrada.nextLine().trim().toUpperCase();
            if (nivel.equals("BASICO") || nivel.equals("INTERMEDIO") || nivel.equals("AVANZADO") || nivel.equals("DESCONOCIDO")) {
                break;
            } else {
                System.out.println("Nivel inválido. Debe ser BASICO, INTERMEDIO, AVANZADO");
            }
        }

        // Validar modalidad
        String modalidad;
        do {
            System.out.print("Modalidad: ");
            modalidad = entrada.nextLine().trim();
            if (modalidad.length() < 3 || modalidad.length() > 30 || modalidad.matches("\\d+(\\.\\d+)?")) {
                System.out.println("La modalidad debe tener entre 3 y 30 caracteres y no puede ser solo números o decimales.");
            }
        } while (modalidad.length() < 3 || modalidad.length() > 30 || modalidad.matches("\\d+(\\.\\d+)?"));
        // Categoría (permite cualquier texto)
        System.out.print("Nombre de la categoría: ");
        String nombreCategoria = entrada.nextLine().trim();
        Categoria categoria = new Categoria(nombreCategoria);
        Date fechaInicio = new Date();

        try {
            EducacionFinanciera curso = new EducacionFinanciera(
                    titulo, descripcion, duracion, nivel, modalidad, nombreCategoria, fechaInicio
            );
            empresa.getEducacionesFinancieras().add(curso);
            System.out.println("Curso creado exitosamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al crear el curso: " + e.getMessage());
        }
    }
    // Editar un curso
    public void editarCurso() {
        System.out.print("Ingrese el título del curso a editar: ");
        String titulo = entrada.nextLine();

        int indice = buscarCurso(titulo);
        if (indice == -1) {
            System.out.println("Curso no encontrado.");
            return;
        }
        EducacionFinanciera curso = empresa.getEducacionesFinancieras().get(indice);
        System.out.println("EDITANDO: " + curso.getTitulo());

        System.out.print("Nuevo título (Enter para mantener): ");
        String nuevoTitulo = entrada.nextLine();
        if (!nuevoTitulo.isEmpty()) {
            curso.setTitulo(nuevoTitulo);
        }

        System.out.print("Nueva descripción (Enter para mantener): ");
        String nuevaDescripcion = entrada.nextLine();
        if (!nuevaDescripcion.isEmpty()) {
            curso.setDescripcion(nuevaDescripcion);
        }

        System.out.print("Nueva duración (0 para mantener): ");
        int nuevaDuracion = Integer.parseInt(entrada.nextLine());
        if (nuevaDuracion > 0) {
            curso.setDuracionSemanas(nuevaDuracion);
        }

        System.out.print("Nuevo nivel (Enter para mantener): ");
        String nuevoNivel = entrada.nextLine();
        if (!nuevoNivel.isEmpty()) {
            curso.setNivel(nuevoNivel);
        }

        System.out.print("Nueva modalidad (Enter para mantener): ");
        String nuevaModalidad = entrada.nextLine();
        if (!nuevaModalidad.isEmpty()) {
            curso.setModalidad(nuevaModalidad);
        }

        System.out.print("Nueva categoría (Enter para mantener): ");
        String nuevaCategoria = entrada.nextLine();
        if (!nuevaCategoria.isEmpty()) {
            curso.setAreaCurso(nuevaCategoria);
        }

        System.out.println("Curso actualizado correctamente.");
    }
    public void eliminarCurso() {
        System.out.print("Ingrese el título del curso a eliminar: ");
        String titulo = entrada.nextLine().trim();
        int indice = buscarCurso(titulo);
        if (indice == -1) {
            System.out.println("Curso no encontrado.");
            return;
        }
        empresa.getEducacionesFinancieras().remove(indice);
        System.out.println("Curso eliminado exitosamente.");
    }

    private void menuConsultaCursos() {
        boolean regresar = false;
        while (!regresar) {
            System.out.println();
            System.out.println("╔═══════════════════════════════════════════════╗");
            System.out.println("║        Consultar Educación Financiera         ║");
            System.out.println("╠═══════════════════════════════════════════════╣");
            System.out.println("║                                               ║");
            System.out.println("║  1. Ver cursos disponibles                    ║");
            System.out.println("║  2. Buscar cursos por categoría               ║");
            System.out.println("║  3. Ver detalle de un curso                   ║");
            System.out.println("║  4. Inscribirse a un curso                    ║");
            System.out.println("║  5. Ver solicitudes de inscripción           ║");
            System.out.println("║  6. Volver al menú anterior                   ║");
            System.out.println("║                                               ║");
            System.out.println("╚═══════════════════════════════════════════════╝");
            System.out.println();
            System.out.print("Seleccione una opción: ");
            String opcion = entrada.nextLine();

            switch (opcion) {
                case "1":
                  consultarEducacionFinanciera();
                    break;
                case "2":
                    buscarCursosPorAreaCurso();
                    break;
                case "3":
                    verDetalleCurso();
                    break;
                case "4":
                    inscribirseCurso();
                    break;
                case "5":
                    verSolicitudesInscripcion();
                    break;
                case "6":
                    System.out.println("Regresando al menú anterior...");
                    regresar = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
            System.out.println();
        }
    }
    private void consultarEducacionFinanciera() {
        System.out.println(empresa.consultarEducacionFinanciera());
    }
    private void buscarCursosPorAreaCurso() {
        String areaCurso = solicitarCadenaNoVacia("Ingrese el área del curso a buscar: ");
        boolean encontrado = false;

        List<EducacionFinanciera> listaCursos = empresa.getEducacionesFinancieras();

        for (EducacionFinanciera curso : listaCursos) {
            if (curso.getAreaCurso() != null &&
                    curso.getAreaCurso().trim().equalsIgnoreCase(areaCurso.trim())) {
                System.out.println(curso);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron cursos en esa área.");
        }
    }
    private void verDetalleCurso() {
        System.out.print("Ingrese el título del curso para ver el detalle: ");
        String titulo = entrada.nextLine().trim();

        List<EducacionFinanciera> listaCursos = empresa.getEducacionesFinancieras();

        boolean encontrado = false;
        for (EducacionFinanciera curso : listaCursos) {
            if (curso.getTitulo() != null && curso.getTitulo().equalsIgnoreCase(titulo)) {
                System.out.println("\n╔═══════════════════════════════════════════════════════════════════════════╗");
                System.out.println("║                               DETALLE DEL CURSO                           ║");
                System.out.println("╠═══════════════════════════════════════════════════════════════════════════╣");
                System.out.println("║ Título              ║ " + String.format("%-51s", curso.getTitulo()) + " ║");
                System.out.println("║ Descripción         ║ " + String.format("%-51s", curso.getDescripcion()) + " ║");
                System.out.println("║ Duración (semanas)  ║ " + String.format("%-51s", curso.getDuracionSemanas()) + " ║");
                System.out.println("║ Nivel               ║ " + String.format("%-51s", curso.getNivel()) + " ║");
                System.out.println("║ Modalidad           ║ " + String.format("%-51s", curso.getModalidad()) + " ║");
                System.out.println("║ Área del curso      ║ " + String.format("%-51s", curso.getAreaCurso()) + " ║");
                System.out.println("║ Fecha de inicio     ║ " + String.format("%-51s", curso.getFechaInicio()) + " ║");
                System.out.println("╚═════════════════════╩═════════════════════════════════════════════════════╝\n");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("Curso no encontrado.");
        }
    }
    private void inscribirseCurso() {
        String nombre = solicitarCadenaNoVacia("Ingrese el nombre del curso al que desea inscribirse: ");
        List<EducacionFinanciera> listaCursos = empresa.getEducacionesFinancieras();

        for (EducacionFinanciera curso : listaCursos) {
            if (curso.getTitulo() != null && curso.getTitulo().equalsIgnoreCase(nombre.trim())) {
                System.out.println("\n╔═══════════════════════════════════════════════════════════════════════════════╗");
                System.out.println("║                              INSCRIPCIÓN EXITOSA                              ║");
                System.out.println("╠═══════════════════════════════════════════════════════════════════════════════╣");
                System.out.println("║                                                                               ║");
                System.out.println("║   ¡Felicitaciones! Te has inscrito exitosamente al curso:                     ║");
                System.out.println("║   " + String.format("%-75s", curso.getTitulo()) + " ║");
                System.out.println("║                                                                               ║");
                System.out.println("║   Detalles de tu inscripción:                                                 ║");
                System.out.println("║   • Fecha de inscripción: " + String.format("%-51s", new Date()) + " ║");
                System.out.println("║   • Fecha de inicio: " + String.format("%-57s", curso.getFechaInicio()) + "║");
                System.out.println("║   • Duración: " + String.format("%-62s", curso.getDuracionSemanas() + " semanas") + "  ║");
                System.out.println("║   • Modalidad: " + String.format("%-61s", curso.getModalidad()) + "  ║");
                System.out.println("║                                                                               ║");
                System.out.println("║   ¡Prepárate para comenzar tu experiencia de aprendizaje!                     ║");
                System.out.println("╚═══════════════════════════════════════════════════════════════════════════════╝\n");

                return;
            }
        }

        System.out.println("Curso no encontrado.");
    }

    private String solicitarCadenaNoVacia(String mensaje) {
        String input;
        do {
            System.out.print(mensaje);
            input = entrada.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("Entrada no puede estar vacía. Intente de nuevo.");
            }
        } while (input.isEmpty());
        return input;
    }
    private int buscarCurso(String titulo) {
        List<EducacionFinanciera> lista = empresa.getEducacionesFinancieras();
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getTitulo().equalsIgnoreCase(titulo)) {
                return i;
            }
        }
        return -1;
    }
    private int solicitarEnteroPositivo(String mensaje) {
        int valor = -1;
        do {
            System.out.print(mensaje);
            String input = entrada.nextLine().trim();
            try {
                valor = Integer.parseInt(input);
                if (valor <= 0) {
                    System.out.println("Por favor ingrese un número entero positivo.");
                    valor = -1;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }
        } while (valor <= 0);
        return valor;
    }
    private void verSolicitudesInscripcion() {
        System.out.println("┌─────────────────────────────────────────────────────────┐");
        System.out.println("│         LISTA DE SOLICITUDES DE INSCRIPCIÓN             │");
        System.out.println("└─────────────────────────────────────────────────────────┘");
        String solicitudes = educacionFinanciera.inicializarSolicitudes();
        System.out.println(solicitudes);
    }
    private void ordenarCursosPorDuracion() {
        List<EducacionFinanciera> listaCursos = empresa.getEducacionesFinancieras();

        if (listaCursos.isEmpty()) {
            System.out.println("No hay cursos para ordenar.");
            return;
        }
        listaCursos.sort(new OrdenarEducacionPorDuracion());
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println("          CURSOS ORDENADOS POR DURACIÓN");
        System.out.println("══════════════════════════════════════════════════════");
        System.out.printf("| %-30s | %-15s |\n", "TÍTULO", "DURACIÓN");
        System.out.println("+--------------------------------------------------+");
        for (EducacionFinanciera curso : listaCursos) {
            System.out.printf("| %-30s | %-15s |\n",
                    curso.getTitulo(),
                    curso.getDuracionSemanas() + " semanas");
        }
        System.out.println("+--------------------------------------------------+");
    }
}
