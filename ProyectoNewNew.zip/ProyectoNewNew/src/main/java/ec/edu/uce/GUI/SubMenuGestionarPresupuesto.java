package ec.edu.uce.GUI;
import ec.edu.uce.Dominio.Usuario;
import ec.edu.uce.Dominio.Presupuesto;
import ec.edu.uce.Util.ComprobacionMenu;
import ec.edu.uce.Util.ExcepcionMifo;
import java.util.List;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class SubMenuGestionarPresupuesto {
    Scanner entrada = new Scanner(System.in);
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    private Usuario usuario;
    public SubMenuGestionarPresupuesto(Usuario usuario) {
        this.usuario = usuario;
    }
    public void mostrarMenuGestionarPresupuesto() {
        System.out.println();
        System.out.println("╔═══════════════════════════════════════════════╗");
        System.out.println("║           Gestionar Presupuesto               ║");
        System.out.println("╠═══════════════════════════════════════════════╣");
        System.out.println("║                                               ║");
        System.out.println("║  1. Ingresar presupuesto                      ║");
        System.out.println("║  2. Editar presupuesto                        ║");
        System.out.println("║  3. Eliminar presupuesto                      ║");
        System.out.println("║  4. Consultar presupuesto                     ║");
        System.out.println("║  5. Volver al menú principal                  ║");
        System.out.println("║  6. Salir del programa                        ║");
        System.out.println("║                                               ║");
        System.out.println("╚═══════════════════════════════════════════════╝");
        System.out.println();
        System.out.print("Por favor, introduce el número correspondiente a la acción que deseas realizar: ");
    }
    public void menuGestionarPresupuesto() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        boolean continuar = true;
        while (continuar) {
            mostrarMenuGestionarPresupuesto();
            int seleccion = ComprobacionMenu.validarOpcionMenu(entrada, 6);
            switch (seleccion) {
                case 1:
                    try {
                        ingresarPresupuesto();
                    } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
                        System.out.println("Hubo un error al ingresar el presupuesto: " + e.getMessage());
                    }
                    break;
                case 2:
                    editarPresupuesto();
                    break;
                case 3:
                    eliminarPresupuesto();
                    break;
                case 4:
                    consultarPresupuesto();
                    break;
                case 5:
                    System.out.println("Volviendo al menú principal...");
                    continuar = false;
                    break;
                case 6:
                    System.out.println();
                    System.out.println("╔══════════════════════════════════════════════════════════════╗");
                    System.out.println("║                     Cerrando el sistema                      ║");
                    System.out.println("╠══════════════════════════════════════════════════════════════╣");
                    System.out.println("║                                                              ║");
                    System.out.println("║     ¡Gracias por haber confiado en MIFO!                     ║");
                    System.out.println("║                                                              ║");
                    System.out.println("║   Esperamos que nuestra plataforma te haya sido de gran      ║");
                    System.out.println("║                     ayuda en tus finanzas.                   ║");
                    System.out.println("║                                                              ║");
                    System.out.println("║              ¡Hasta la próxima!                              ║");
                    System.out.println("║                                                              ║");
                    System.out.println("╚══════════════════════════════════════════════════════════════╝");
                    System.exit(0);
                    break;
            }
            System.out.println();
        }
    }
    public void ingresarPresupuesto() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        System.out.println();
        System.out.println("    ------------------------------------------- ");
        double presupuesto = 0;
        while (presupuesto == 0) {
            System.out.print(" | Ingrese el presupuesto: ");
            presupuesto = ComprobacionMenu.validarMonto(entrada);
        }

        Date fecha = null;
        while (fecha == null) {
            System.out.println();
            System.out.print(" | Ingrese la fecha (dd/MM/yyyy): ");
            String fechaStr = entrada.nextLine();
            fecha = ComprobacionMenu.validarFecha(fechaStr);
            if (fecha == null) {
                System.out.println();
                System.out.println("Fecha inválida, no se puede crear el presupuesto.");
            }
        }

        try {
            usuario.agregarPresupuesto(presupuesto, fecha);
            System.out.println();
            System.out.println(" -> Presupuesto guardado con éxito. ");
        } catch (ExcepcionMifo.MovimientoInvalidoExcepcion e) {
            System.out.println();
            System.out.println(e.getMessage());
        }
    }

    public void editarPresupuesto() {
        System.out.println(" ----------------------------------------------");
        List<Presupuesto> presupuestos = usuario.getPresupuestos();

        if (presupuestos.isEmpty()) {
            System.out.println();
            System.out.println(" No hay presupuestos guardados para editar. ");
            return;
        }
        consultarPresupuesto();
        System.out.println();
        System.out.print(" Seleccione el índice del presupuesto a editar: ");
        int indice;
        try {
            indice = Integer.parseInt(entrada.nextLine());
        } catch (NumberFormatException e) {
            System.out.println(" Índice no válido. ");
            return;
        }

        if (indice < 0 || indice >= presupuestos.size()) {
            System.out.println(" Índice no válido. ");
            return;
        }

        boolean inputValido = false;
        while (!inputValido) {
            try {
                System.out.println();
                System.out.print(" | Ingrese el nuevo presupuesto: ");
                double presupuesto = ComprobacionMenu.validarMonto(entrada.nextLine());
                if (presupuesto == 0) {
                    System.out.println("| El monto ingresado no es válido. ");
                    continue;
                }

                System.out.print(" | Ingrese la nueva fecha (dd/MM/yyyy): ");
                String fechaStr = entrada.nextLine();
                Date fecha = dateFormat.parse(fechaStr);

                Presupuesto p = presupuestos.get(indice);
                p.setMontoPresupuesto(presupuesto);
                p.setFecha(fecha);

                System.out.println();
                System.out.println(" -> Presupuesto editado con éxito. ");
                inputValido = true;
            } catch (ParseException e) {
                System.out.println(" Error al editar presupuesto: Formato de fecha incorrecto. ");
            }
        }
    }
    public void eliminarPresupuesto() throws ExcepcionMifo.MovimientoInvalidoExcepcion {
        System.out.println("  --------------------------------------------------------");
        List<Presupuesto> presupuestos = usuario.getPresupuestos();
        if (presupuestos.isEmpty()) {
            System.out.println(" No hay presupuestos guardados para eliminar. ");
            return;
        }
        consultarPresupuesto();
        System.out.println();
        System.out.print(" ¿Está seguro de que desea eliminar un presupuesto? (s/n): ");
        String confirmacion = entrada.nextLine();

        if (confirmacion.equalsIgnoreCase("s")) {
            System.out.println();
            System.out.print(" Seleccione el índice del presupuesto a eliminar: ");
            int indice;
            try {
                indice = Integer.parseInt(entrada.nextLine());
            } catch (NumberFormatException e) {
                System.out.println();
                System.out.println("Índice no válido.");
                return;
            }
            if (indice < 0 || indice >= presupuestos.size()) {
                System.out.println(" Índice no válido.");
                return;
            }
            usuario.eliminarPresupuesto(indice); // ← asegúrate de que elimine correctamente de la lista
            System.out.println();
            System.out.println(" Presupuesto eliminado correctamente.");
        } else {
            System.out.println(" Operación cancelada.");
        }
    }
    public void consultarPresupuesto() {
        List<Presupuesto> presupuestos = usuario.getPresupuestos();
        if (presupuestos == null) {
            System.out.println(" Error: La lista de presupuestos no está inicializada.");
            return;
        }
        System.out.println("\n══════════════════════════════════════════════════════════════════════════");
        System.out.println("                       LISTA DE PRESUPUESTOS");
        System.out.println("══════════════════════════════════════════════════════════════════════════");
        System.out.println();

        if (presupuestos.isEmpty()) {
            System.out.println("  No hay presupuestos registrados.");
            System.out.println("  ¡Crea tu primer presupuesto para comenzar a gestionar tus finanzas!");
        } else {
            System.out.println("┌─────┬──────────────────────────┬────────────────────────────────────────┐");
            System.out.println("│ No. │      Monto ($)           │              Fecha                     │");
            System.out.println("├─────┼──────────────────────────┼────────────────────────────────────────┤");

            for (int i = 0; i < presupuestos.size(); i++) {
                Presupuesto p = presupuestos.get(i);
                System.out.println(String.format("│ %-3d │ %,20.2f     │ %-38s │",
                        i + 1,
                        p.getMontoPresupuesto(),
                        dateFormat.format(p.getFecha())));
            }
            System.out.println("└─────┴──────────────────────────┴────────────────────────────────────────┘");
            System.out.println();
            System.out.println("  Total de presupuestos: " + presupuestos.size());
            double montoTotal = presupuestos.stream()
                    .mapToDouble(Presupuesto::getMontoPresupuesto)
                    .sum();
            System.out.println("  Monto total acumulado: $" + String.format("%,.2f", montoTotal));
        }
        System.out.println("══════════════════════════════════════════════════════════════════════════\n");
    }
}
